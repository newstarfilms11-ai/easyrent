#!/usr/bin/env python3
"""
EasyRent - Terms & Conditions PDF Generator
Google Play Policy + Indian Law Compliant
"""

import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.lib import colors
from reportlab.lib.units import inch, cm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, PageBreak,
    Table, TableStyle, KeepTogether, HRFlowable
)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase.pdfmetrics import registerFontFamily

# ━━ Font Registration ━━
pdfmetrics.registerFont(TTFont('LiberationSerif', '/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf'))
pdfmetrics.registerFont(TTFont('LiberationSerif-Bold', '/usr/share/fonts/truetype/liberation/LiberationSerif-Bold.ttf'))
pdfmetrics.registerFont(TTFont('LiberationSans', '/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf'))
pdfmetrics.registerFont(TTFont('LiberationSans-Bold', '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf'))
pdfmetrics.registerFont(TTFont('DejaVuSans', '/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'))

registerFontFamily('LiberationSerif', normal='LiberationSerif', bold='LiberationSerif-Bold')
registerFontFamily('LiberationSans', normal='LiberationSans', bold='LiberationSans-Bold')
registerFontFamily('DejaVuSans', normal='DejaVuSans', bold='DejaVuSans')

# ━━ Color Palette (auto-generated) ━━
ACCENT       = colors.HexColor('#26728c')
TEXT_PRIMARY  = colors.HexColor('#22201e')
TEXT_MUTED    = colors.HexColor('#827e76')
BG_SURFACE   = colors.HexColor('#dddad5')
BG_PAGE      = colors.HexColor('#efeeec')

TABLE_HEADER_COLOR = ACCENT
TABLE_HEADER_TEXT  = colors.white
TABLE_ROW_EVEN     = colors.white
TABLE_ROW_ODD      = BG_SURFACE

# ━━ Output path ━━
OUTPUT_PDF = '/home/z/my-project/download/EasyRent_Terms_and_Conditions.pdf'

# ━━ Page dimensions ━━
PAGE_W, PAGE_H = A4
LEFT_MARGIN = 1.0 * inch
RIGHT_MARGIN = 1.0 * inch
TOP_MARGIN = 0.8 * inch
BOTTOM_MARGIN = 0.8 * inch

# ━━ Styles ━━
title_style = ParagraphStyle(
    name='DocTitle',
    fontName='LiberationSerif',
    fontSize=28,
    leading=36,
    alignment=TA_CENTER,
    textColor=ACCENT,
    spaceBefore=40,
    spaceAfter=12,
)

subtitle_style = ParagraphStyle(
    name='DocSubtitle',
    fontName='LiberationSerif',
    fontSize=13,
    leading=20,
    alignment=TA_CENTER,
    textColor=TEXT_MUTED,
    spaceBefore=0,
    spaceAfter=30,
)

h1_style = ParagraphStyle(
    name='H1',
    fontName='LiberationSerif',
    fontSize=16,
    leading=24,
    textColor=ACCENT,
    spaceBefore=18,
    spaceAfter=8,
)

h2_style = ParagraphStyle(
    name='H2',
    fontName='LiberationSerif',
    fontSize=12,
    leading=18,
    textColor=TEXT_PRIMARY,
    spaceBefore=10,
    spaceAfter=4,
)

body_style = ParagraphStyle(
    name='Body',
    fontName='LiberationSerif',
    fontSize=10.5,
    leading=17,
    alignment=TA_JUSTIFY,
    textColor=TEXT_PRIMARY,
    spaceBefore=0,
    spaceAfter=6,
)

bullet_style = ParagraphStyle(
    name='Bullet',
    fontName='LiberationSerif',
    fontSize=10.5,
    leading=17,
    alignment=TA_LEFT,
    textColor=TEXT_PRIMARY,
    leftIndent=24,
    spaceBefore=2,
    spaceAfter=2,
)

sub_bullet_style = ParagraphStyle(
    name='SubBullet',
    fontName='LiberationSerif',
    fontSize=10,
    leading=16,
    alignment=TA_LEFT,
    textColor=TEXT_MUTED,
    leftIndent=44,
    spaceBefore=1,
    spaceAfter=1,
)

footer_style = ParagraphStyle(
    name='Footer',
    fontName='LiberationSerif',
    fontSize=9,
    leading=14,
    alignment=TA_CENTER,
    textColor=TEXT_MUTED,
    spaceBefore=20,
    spaceAfter=0,
)

consent_style = ParagraphStyle(
    name='Consent',
    fontName='LiberationSerif',
    fontSize=12,
    leading=20,
    alignment=TA_CENTER,
    textColor=ACCENT,
    spaceBefore=20,
    spaceAfter=10,
)

# ━━ Page number handler ━━
def add_page_number(canvas, doc):
    canvas.saveState()
    # Page number
    page_num = canvas.getPageNumber()
    if page_num > 1:  # Skip page number on cover page
        text = f"Page {page_num}"
        canvas.setFont('LiberationSerif', 8)
        canvas.setFillColor(TEXT_MUTED)
        canvas.drawCentredString(PAGE_W / 2, 0.4 * inch, text)
        # Footer line
        canvas.setStrokeColor(BG_SURFACE)
        canvas.setLineWidth(0.5)
        canvas.line(LEFT_MARGIN, 0.55 * inch, PAGE_W - RIGHT_MARGIN, 0.55 * inch)
        # Header line
        canvas.line(LEFT_MARGIN, PAGE_H - 0.55 * inch, PAGE_W - RIGHT_MARGIN, PAGE_H - 0.55 * inch)
    canvas.restoreState()

# ━━ Build Document ━━
doc = SimpleDocTemplate(
    OUTPUT_PDF,
    pagesize=A4,
    leftMargin=LEFT_MARGIN,
    rightMargin=RIGHT_MARGIN,
    topMargin=TOP_MARGIN,
    bottomMargin=BOTTOM_MARGIN,
    title='EasyRent - Terms and Conditions',
    author='EasyRent',
    creator='Z.ai',
    subject='Terms and Conditions for EasyRent Mobile Application',
)

story = []

# ━━ COVER / TITLE PAGE ━━
story.append(Spacer(1, 100))

# Decorative line
story.append(HRFlowable(width="60%", thickness=2, color=ACCENT, spaceAfter=20, spaceBefore=0))

story.append(Paragraph('<b>EasyRent</b>', title_style))
story.append(Paragraph('Terms &amp; Conditions', ParagraphStyle(
    name='TCSubtitle',
    fontName='LiberationSerif',
    fontSize=20,
    leading=28,
    alignment=TA_CENTER,
    textColor=TEXT_PRIMARY,
    spaceBefore=8,
    spaceAfter=12,
)))

story.append(HRFlowable(width="60%", thickness=2, color=ACCENT, spaceAfter=30, spaceBefore=10))

story.append(Paragraph('Google Play Policy + Indian Law Friendly Draft', subtitle_style))

story.append(Paragraph('Last Updated: May 2026', ParagraphStyle(
    name='DateLine',
    fontName='LiberationSerif',
    fontSize=11,
    leading=16,
    alignment=TA_CENTER,
    textColor=TEXT_MUTED,
    spaceBefore=20,
    spaceAfter=30,
)))

# Intro block
story.append(Paragraph(
    'Welcome to EasyRent. By using the EasyRent mobile application, website, or services, '
    'you agree to the following Terms &amp; Conditions. Please read them carefully before using our platform.',
    ParagraphStyle(
        name='IntroBlock',
        fontName='LiberationSerif',
        fontSize=11,
        leading=18,
        alignment=TA_CENTER,
        textColor=TEXT_PRIMARY,
        spaceBefore=20,
        spaceAfter=0,
    )
))

story.append(PageBreak())

# ━━ SECTION 1: About EasyRent ━━
story.append(Paragraph('<b>1. About EasyRent</b>', h1_style))
story.append(Paragraph(
    'EasyRent is an online rental listing platform that helps users find or post various types of '
    'rental properties across India. The platform serves as a digital marketplace connecting property '
    'owners, brokers, and tenants, enabling them to discover, list, and engage with rental opportunities '
    'in a streamlined and efficient manner. EasyRent covers a wide range of property categories to cater '
    'to diverse rental needs, from students looking for affordable rooms to businesses seeking commercial spaces.',
    body_style
))
story.append(Paragraph('EasyRent allows users to find or post listings for:', body_style))
for item in ['Rooms', 'PGs (Paying Guest Accommodations)', 'Houses', 'Shops', 'Offices', 'Garages', 'Commercial Properties']:
    story.append(Paragraph(f'&#8226; {item}', bullet_style))
story.append(Spacer(1, 6))
story.append(Paragraph(
    'EasyRent only provides a digital marketplace and does not own, rent, sell, or manage listed '
    'properties directly. The platform acts solely as an intermediary that facilitates connections '
    'between property owners and potential tenants. All transactions, agreements, and arrangements '
    'made between users are independent of EasyRent, and the platform bears no responsibility for '
    'the outcome of such interactions. Users are strongly advised to conduct their own due diligence '
    'before entering into any rental agreements.',
    body_style
))

# ━━ SECTION 2: User Eligibility ━━
story.append(Spacer(1, 12))
story.append(Paragraph('<b>2. User Eligibility</b>', h1_style))
story.append(Paragraph(
    'By using EasyRent, you confirm and warrant that you meet the following eligibility requirements. '
    'These requirements are in place to ensure the safety and legality of all transactions and '
    'interactions on the platform. Failure to meet these criteria may result in immediate suspension '
    'or termination of your account without prior notice.',
    body_style
))
story.append(Paragraph('By using EasyRent, you confirm that:', body_style))
for item in [
    'You are at least 18 years of age. Users below this age are not permitted to create accounts or engage in any transactions on the platform, as legally binding agreements in India require the parties to be of legal age.',
    'You can legally enter into agreements under Indian law. This includes having the legal capacity to contract as defined by the Indian Contract Act, 1872, and not being disqualified from entering into contracts by any court order or legal provision.',
    'The information provided by you is accurate and genuine. Providing false, misleading, or fraudulent information constitutes a violation of these Terms and may result in account suspension, legal action, and reporting to relevant authorities as required by the Information Technology Act, 2000.',
]:
    story.append(Paragraph(f'&#8226; {item}', bullet_style))

# ━━ SECTION 3: User Accounts ━━
story.append(Spacer(1, 12))
story.append(Paragraph('<b>3. User Accounts</b>', h1_style))
story.append(Paragraph(
    'Creating an account on EasyRent is essential for accessing the full range of features offered by '
    'the platform, including posting property listings, contacting property owners, saving favorite '
    'properties, and managing subscriptions. The account creation process is designed to be simple '
    'and secure while maintaining the integrity of the platform.',
    body_style
))

story.append(Paragraph('<b>3.1 Registration Methods</b>', h2_style))
story.append(Paragraph('Users may register using the following methods:', body_style))
for item in [
    'Mobile Number with OTP verification - This is the primary and recommended method for Indian users. OTP verification ensures that the mobile number belongs to the registrant and provides an additional layer of security.',
    'Email address with password - Users can register using a valid email address and create a secure password. Email verification may be required to activate the account fully.',
    'Google Sign-In - For convenience, users may authenticate using their existing Google account credentials. This method is secure and eliminates the need to remember additional passwords.',
]:
    story.append(Paragraph(f'&#8226; {item}', bullet_style))

story.append(Paragraph('<b>3.2 Account Responsibility</b>', h2_style))
story.append(Paragraph('You are solely responsible for:', body_style))
for item in [
    'Maintaining the security of your account credentials, including passwords and OTPs. Never share your login details with any third party.',
    'Keeping your login details confidential and not permitting any other person or entity to access your account.',
    'All activities performed through your account, whether authorized by you or not. If you suspect unauthorized access, you must notify EasyRent support immediately.',
]:
    story.append(Paragraph(f'&#8226; {item}', bullet_style))

story.append(Paragraph('<b>3.3 Account Suspension</b>', h2_style))
story.append(Paragraph(
    'EasyRent reserves the right to suspend or terminate accounts that are found to be involved in '
    'any of the following activities. Such actions are taken to protect the community and maintain '
    'the trustworthiness of the platform:',
    body_style
))
for item in ['Fraud or deceptive practices', 'Fake or misleading property listings', 'Illegal activity of any nature', 'Abuse, harassment, or spam behavior towards other users']:
    story.append(Paragraph(f'&#8226; {item}', bullet_style))

# ━━ SECTION 4: Property Listings ━━
story.append(Spacer(1, 12))
story.append(Paragraph('<b>4. Property Listings</b>', h1_style))
story.append(Paragraph(
    'Property listings are the core feature of EasyRent. They allow property owners and authorized '
    'brokers to showcase their rental properties to a wide audience of potential tenants. Maintaining '
    'the accuracy and authenticity of listings is critical to the trust and functionality of the platform.',
    body_style
))

story.append(Paragraph('<b>4.1 Listing Requirements</b>', h2_style))
story.append(Paragraph('Users posting properties must ensure:', body_style))
for item in [
    'Property information is accurate and up-to-date, including rent amount, area, furnishing status, and availability dates.',
    'Images uploaded are real, authorized, and representative of the actual property being listed. Using stock images or images of other properties is strictly prohibited.',
    'They have legal rights to post the property, meaning they are either the owner, an authorized representative, or a licensed broker with permission from the owner.',
]:
    story.append(Paragraph(f'&#8226; {item}', bullet_style))

story.append(Paragraph('<b>4.2 Prohibited Content</b>', h2_style))
story.append(Paragraph('The following are strictly prohibited on the platform:', body_style))
for item in [
    'Fake or non-existent property listings',
    'Misleading information about property features, rent, or availability',
    'Listings for illegal or unauthorized properties',
    'Adult content or explicit material',
    'Hate speech, discriminatory language, or offensive content',
    'Copyright violations, including unauthorized use of images or content',
]:
    story.append(Paragraph(f'&#8226; {item}', bullet_style))
story.append(Spacer(1, 4))
story.append(Paragraph(
    'EasyRent reserves the right to remove any listing without prior notice if it is found to violate '
    'these guidelines. Repeated violations may result in permanent account suspension and reporting '
    'to relevant authorities as required by Indian law.',
    body_style
))

# ━━ SECTION 5: Payments & Subscriptions ━━
story.append(Spacer(1, 12))
story.append(Paragraph('<b>5. Payments &amp; Subscriptions</b>', h1_style))
story.append(Paragraph(
    'EasyRent offers both free and premium features. While basic property listing and browsing '
    'remain free for all users, certain advanced features require payment. These paid features are '
    'designed to enhance visibility and provide additional tools for property owners and brokers.',
    body_style
))

story.append(Paragraph('<b>5.1 Paid Features</b>', h2_style))
story.append(Paragraph('Certain features may require payment, including:', body_style))
for item in [
    'Featured Listings - Boost your property to the top of search results for increased visibility',
    'Premium Ads with enhanced placement and longer duration',
    'Broker Subscription Plans - Basic (Rs. 499/month) and Pro (Rs. 1,499/month) with unlimited listings, WhatsApp leads, verified badge, and priority support',
    'Promotional Services - Special placement during peak rental seasons',
]:
    story.append(Paragraph(f'&#8226; {item}', bullet_style))

story.append(Paragraph('<b>5.2 Payment Terms</b>', h2_style))
story.append(Paragraph('All payments are:', body_style))
for item in [
    'Non-refundable unless required by applicable law. Users are encouraged to review their selections carefully before completing a purchase.',
    'Processed through secure third-party payment gateways including UPI, Razorpay, and other approved methods. EasyRent does not store payment card details on its servers.',
]:
    story.append(Paragraph(f'&#8226; {item}', bullet_style))
story.append(Spacer(1, 4))
story.append(Paragraph(
    'EasyRent is not responsible for bank or payment gateway failures, delays, or technical issues '
    'that may occur during the payment process. In case of a failed transaction where the amount '
    'has been debited, users should contact their bank or payment provider for resolution.',
    body_style
))

# ━━ SECTION 6: Google Play Compliance ━━
story.append(Spacer(1, 12))
story.append(Paragraph('<b>6. Google Play Compliance</b>', h1_style))
story.append(Paragraph(
    'EasyRent follows Google Play Developer Policies to ensure the application meets all requirements '
    'set forth by Google for applications distributed through the Google Play Store. Compliance with '
    'these policies is mandatory for maintaining the application on the Play Store and providing '
    'a safe experience for all users.',
    body_style
))

story.append(Paragraph('<b>6.1 App Compliance</b>', h2_style))
story.append(Paragraph('The app:', body_style))
for item in [
    'Does not sell illegal products or services of any kind',
    'Does not allow deceptive behavior, including fake reviews, click manipulation, or misleading claims',
    'Does not collect sensitive user data without explicit consent as required by the IT Act, 2000 and Google Play policies',
    'Uses secure authentication methods and encrypts sensitive data in transit and at rest',
]:
    story.append(Paragraph(f'&#8226; {item}', bullet_style))

story.append(Paragraph('<b>6.2 User Responsibilities</b>', h2_style))
story.append(Paragraph('Users must not:', body_style))
for item in [
    'Reverse engineer, decompile, or disassemble the application',
    'Abuse platform systems, including automated scripts, bots, or scraping tools',
    'Upload malicious content, including malware, viruses, or code designed to disrupt the platform',
]:
    story.append(Paragraph(f'&#8226; {item}', bullet_style))

# ━━ SECTION 7: Privacy & Data Usage ━━
story.append(Spacer(1, 12))
story.append(Paragraph('<b>7. Privacy &amp; Data Usage</b>', h1_style))
story.append(Paragraph(
    'EasyRent is committed to protecting the privacy and personal data of its users in compliance '
    'with the Information Technology Act, 2000, the IT (Reasonable Security Practices and Procedures '
    'and Sensitive Personal Data or Information) Rules, 2011, and the Digital Personal Data Protection '
    'Act, 2023. This section outlines the types of data collected and the purposes for which it is used.',
    body_style
))

story.append(Paragraph('<b>7.1 Data Collection</b>', h2_style))
story.append(Paragraph('EasyRent may collect:', body_style))
for item in [
    'Name, mobile number, and email address for account creation and verification',
    'Location data to provide nearby rental recommendations and improve search relevance',
    'Device information including model, OS version, and unique identifiers for security and analytics',
    'Uploaded property details including images, descriptions, and contact preferences',
]:
    story.append(Paragraph(f'&#8226; {item}', bullet_style))

story.append(Paragraph('<b>7.2 Data Usage</b>', h2_style))
story.append(Paragraph('Collected data is used for:', body_style))
for item in [
    'Account verification and authentication',
    'Property recommendations based on user preferences and location',
    'Customer support and issue resolution',
    'Fraud prevention, security monitoring, and compliance with legal requirements',
]:
    story.append(Paragraph(f'&#8226; {item}', bullet_style))
story.append(Spacer(1, 4))
story.append(Paragraph(
    'We do not sell personal user data to third parties under any circumstances. Data may be shared '
    'with law enforcement agencies only when required by law or court order.',
    body_style
))

# ━━ SECTION 8: Location Services ━━
story.append(Spacer(1, 12))
story.append(Paragraph('<b>8. Location Services</b>', h1_style))
story.append(Paragraph(
    'EasyRent may request access to the device location to enhance the user experience and provide '
    'more relevant search results. Location services are optional and are used solely to improve the '
    'functionality of the platform. Users retain full control over location permissions and can modify '
    'them at any time through their device settings.',
    body_style
))
story.append(Paragraph('EasyRent may use device location to:', body_style))
for item in [
    'Show nearby rental properties based on the user\'s current position, making it easier to find accommodations close to their preferred area',
    'Improve search results by prioritizing properties in the user\'s vicinity and providing accurate distance information',
]:
    story.append(Paragraph(f'&#8226; {item}', bullet_style))
story.append(Spacer(1, 4))
story.append(Paragraph(
    'Users can disable location access at any time through their device settings. Disabling location '
    'access will not affect the core functionality of the app but may reduce the relevance of certain '
    'location-based features such as nearby property suggestions and distance calculations.',
    body_style
))

# ━━ SECTION 9: Third-Party Services ━━
story.append(Spacer(1, 12))
story.append(Paragraph('<b>9. Third-Party Services</b>', h1_style))
story.append(Paragraph(
    'EasyRent integrates with various third-party services to enhance the functionality and user '
    'experience of the platform. These integrations are carefully selected and monitored to ensure '
    'they meet our standards for security, reliability, and user privacy. However, each third-party '
    'service operates under its own terms and conditions.',
    body_style
))
story.append(Paragraph('EasyRent may integrate:', body_style))
for item in [
    'Google Maps - For location display, property mapping, and navigation features',
    'Firebase - For analytics, push notifications, crash reporting, and cloud infrastructure',
    'Razorpay / PhonePe / UPI payment gateways - For secure processing of subscription and feature payments',
    'AdMob advertisements - For displaying relevant advertisements within the application',
]:
    story.append(Paragraph(f'&#8226; {item}', bullet_style))
story.append(Spacer(1, 4))
story.append(Paragraph(
    'These services may have separate privacy policies and terms of use. EasyRent is not responsible '
    'for the practices of these third-party services. Users are encouraged to review the terms and '
    'privacy policies of each service independently.',
    body_style
))

# ━━ SECTION 10: Limitation of Liability ━━
story.append(Spacer(1, 12))
story.append(Paragraph('<b>10. Limitation of Liability</b>', h1_style))
story.append(Paragraph(
    'EasyRent is only a platform provider and does not participate in any transactions between users. '
    'The platform provides the technology and infrastructure for users to connect, but all rental '
    'agreements, financial transactions, and interactions between property owners and tenants are '
    'solely the responsibility of the involved parties.',
    body_style
))
story.append(Paragraph('We are not responsible for:', body_style))
for item in [
    'Property disputes between owners and tenants, including disputes over deposit refunds, maintenance responsibilities, or lease terms',
    'Fraud by owners or tenants, including misrepresentation of property conditions, fake identities, or financial scams',
    'Rental agreements between users, including the terms, enforcement, and compliance of such agreements',
    'Financial losses incurred through transactions initiated via the platform',
    'Damages caused by third parties, including but not limited to service providers, advertisers, or payment processors',
]:
    story.append(Paragraph(f'&#8226; {item}', bullet_style))
story.append(Spacer(1, 4))
story.append(Paragraph(
    'Users should independently verify property details, conduct background checks, and exercise '
    'due diligence before making payments or entering into rental agreements. EasyRent recommends '
    'that users visit properties in person, verify ownership documents, and execute proper rental '
    'agreements before making any financial commitments.',
    body_style
))

# ━━ SECTION 11: Intellectual Property ━━
story.append(Spacer(1, 12))
story.append(Paragraph('<b>11. Intellectual Property</b>', h1_style))
story.append(Paragraph(
    'All content within the EasyRent application, including but not limited to the logo, design, '
    'branding, text, features, and overall user interface, is the intellectual property of EasyRent '
    'unless otherwise stated. This intellectual property is protected under the Copyright Act, 1957 '
    'and applicable international copyright laws.',
    body_style
))
story.append(Paragraph('The following are protected:', body_style))
for item in [
    'The EasyRent logo, brand identity, and visual design elements',
    'The application design, user interface, and user experience patterns',
    'All original text content, documentation, and help materials',
    'Software features, algorithms, and technical implementations',
]:
    story.append(Paragraph(f'&#8226; {item}', bullet_style))
story.append(Spacer(1, 4))
story.append(Paragraph(
    'Unauthorized copying, reproduction, distribution, or modification of any intellectual property '
    'belonging to EasyRent is strictly prohibited and may result in legal action. Users who post '
    'property listings retain ownership of their content but grant EasyRent a non-exclusive license '
    'to display and distribute that content on the platform.',
    body_style
))

# ━━ SECTION 12: Termination ━━
story.append(Spacer(1, 12))
story.append(Paragraph('<b>12. Termination</b>', h1_style))
story.append(Paragraph(
    'EasyRent may suspend or terminate user accounts that violate the platform policies, engage in '
    'illegal activities, or harm the reputation and functioning of the platform. Termination may be '
    'temporary or permanent depending on the severity and frequency of violations.',
    body_style
))
story.append(Paragraph('EasyRent may suspend or terminate accounts that:', body_style))
for item in [
    'Violate Indian laws, including but not limited to the Information Technology Act, 2000, the Indian Penal Code, and the Real Estate (Regulation and Development) Act, 2016',
    'Violate platform policies as outlined in these Terms and Conditions',
    'Harm other users or the platform\'s reputation through fraudulent, abusive, or deceptive behavior',
]:
    story.append(Paragraph(f'&#8226; {item}', bullet_style))
story.append(Spacer(1, 4))
story.append(Paragraph(
    'Upon termination, users will lose access to their accounts, listings, and any active subscriptions. '
    'No refunds will be provided for unused subscription periods or featured listing fees. EasyRent '
    'reserves the right to pursue legal action against users whose violations result in financial '
    'loss or damage to the platform or its users.',
    body_style
))

# ━━ SECTION 13: Governing Law ━━
story.append(Spacer(1, 12))
story.append(Paragraph('<b>13. Governing Law</b>', h1_style))
story.append(Paragraph(
    'These Terms and Conditions shall be governed by and construed in accordance with the laws of '
    'India. The platform operates within the legal framework established by the Constitution of India '
    'and applicable central and state legislation.',
    body_style
))
story.append(Paragraph('These Terms shall be governed under:', body_style))
for item in [
    'Laws of India, including all applicable central and state legislation',
    'The Information Technology Act, 2000, and rules made thereunder, including the IT (Intermediary Guidelines and Digital Media Ethics Code) Rules, 2021',
    'The Digital Personal Data Protection Act, 2023, for matters related to personal data processing and privacy',
]:
    story.append(Paragraph(f'&#8226; {item}', bullet_style))
story.append(Spacer(1, 4))
story.append(Paragraph(
    'Any disputes arising out of or in connection with these Terms shall fall under the exclusive '
    'jurisdiction of the competent courts in India. Users agree to submit to the jurisdiction of '
    'Indian courts and waive any objection based on inconvenient forum or lack of personal jurisdiction.',
    body_style
))

# ━━ SECTION 14: Changes to Terms ━━
story.append(Spacer(1, 12))
story.append(Paragraph('<b>14. Changes to Terms</b>', h1_style))
story.append(Paragraph(
    'EasyRent reserves the right to update, modify, or amend these Terms and Conditions at any time '
    'without prior individual notice to users. Changes may be necessitated by updates to Google Play '
    'policies, amendments to Indian law, improvements to platform features, or changes in business practices.',
    body_style
))
story.append(Paragraph(
    'Continued use of the platform after any changes have been made constitutes acceptance of the '
    'updated Terms and Conditions. Users are encouraged to review these Terms periodically to stay '
    'informed of any changes. Material changes may be communicated through in-app notifications, '
    'email alerts, or prominent notices on the EasyRent website. If you do not agree with the '
    'modified Terms, you must discontinue use of the platform immediately.',
    body_style
))

# ━━ SECTION 15: Contact Information ━━
story.append(Spacer(1, 12))
story.append(Paragraph('<b>15. Contact Information</b>', h1_style))
story.append(Paragraph(
    'For support, legal concerns, or any questions regarding these Terms and Conditions, users can '
    'reach out to the EasyRent support team through the following channels. Our team is committed '
    'to responding to all inquiries in a timely and professional manner.',
    body_style
))

# Contact table
contact_data = [
    [Paragraph('<b>Contact Method</b>', ParagraphStyle(name='CH1', fontName='LiberationSerif', fontSize=10.5, textColor=colors.white, alignment=TA_CENTER)),
     Paragraph('<b>Details</b>', ParagraphStyle(name='CH2', fontName='LiberationSerif', fontSize=10.5, textColor=colors.white, alignment=TA_CENTER))],
    [Paragraph('Email', ParagraphStyle(name='CD1', fontName='LiberationSerif', fontSize=10, textColor=TEXT_PRIMARY, alignment=TA_CENTER)),
     Paragraph('support@easyrent.in', ParagraphStyle(name='CD2', fontName='LiberationSerif', fontSize=10, textColor=ACCENT, alignment=TA_CENTER))],
    [Paragraph('Website', ParagraphStyle(name='CD3', fontName='LiberationSerif', fontSize=10, textColor=TEXT_PRIMARY, alignment=TA_CENTER)),
     Paragraph('www.easyrent.in', ParagraphStyle(name='CD4', fontName='LiberationSerif', fontSize=10, textColor=ACCENT, alignment=TA_CENTER))],
]

available_width = PAGE_W - LEFT_MARGIN - RIGHT_MARGIN
contact_table = Table(contact_data, colWidths=[available_width * 0.4, available_width * 0.6], hAlign='CENTER')
contact_table.setStyle(TableStyle([
    ('BACKGROUND', (0, 0), (-1, 0), TABLE_HEADER_COLOR),
    ('TEXTCOLOR', (0, 0), (-1, 0), TABLE_HEADER_TEXT),
    ('BACKGROUND', (0, 1), (-1, 1), TABLE_ROW_EVEN),
    ('BACKGROUND', (0, 2), (-1, 2), TABLE_ROW_ODD),
    ('GRID', (0, 0), (-1, -1), 0.5, TEXT_MUTED),
    ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
    ('LEFTPADDING', (0, 0), (-1, -1), 12),
    ('RIGHTPADDING', (0, 0), (-1, -1), 12),
    ('TOPPADDING', (0, 0), (-1, -1), 8),
    ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
]))

story.append(Spacer(1, 12))
story.append(contact_table)

# ━━ USER CONSENT ━━
story.append(Spacer(1, 30))
story.append(HRFlowable(width="40%", thickness=1, color=ACCENT, spaceAfter=16, spaceBefore=0))

story.append(Paragraph('<b>User Consent</b>', ParagraphStyle(
    name='ConsentTitle',
    fontName='LiberationSerif',
    fontSize=14,
    leading=20,
    alignment=TA_CENTER,
    textColor=ACCENT,
    spaceBefore=8,
    spaceAfter=10,
)))

story.append(Paragraph('By using EasyRent, you agree to:', body_style))
for item in [
    'These Terms &amp; Conditions in their entirety',
    'The EasyRent Privacy Policy as published on the website and within the application',
    'Community Guidelines governing user behavior and content standards',
]:
    story.append(Paragraph(f'&#8226; {item}', bullet_style))

story.append(Spacer(1, 20))
story.append(Paragraph(
    '<b>I Agree to the Terms &amp; Conditions of EasyRent.</b>',
    consent_style
))

story.append(Spacer(1, 40))
story.append(HRFlowable(width="60%", thickness=1, color=BG_SURFACE, spaceAfter=10, spaceBefore=0))
story.append(Paragraph(
    'This document is effective as of May 2026 and supersedes all previous versions.',
    footer_style
))

# ━━ Build ━━
doc.build(story, onFirstPage=add_page_number, onLaterPages=add_page_number)
print(f"PDF generated successfully: {OUTPUT_PDF}")
