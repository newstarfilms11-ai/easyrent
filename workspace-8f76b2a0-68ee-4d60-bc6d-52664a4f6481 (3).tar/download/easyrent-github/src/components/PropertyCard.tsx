'use client'

import { useState } from 'react'
import { Property } from './store'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Star, MapPin, IndianRupee, Building2, Home, Store, Bed, Warehouse, ImageIcon, Shield, Crown, Zap, Award } from 'lucide-react'

const typeLabels: Record<string, string> = {
  ROOM: 'Room',
  PG: 'PG',
  HOUSE: 'House',
  SHOP: 'Shop',
  GARAGE: 'Garage',
}

const typeColors: Record<string, string> = {
  ROOM: 'bg-blue-100 text-blue-700',
  PG: 'bg-purple-100 text-purple-700',
  HOUSE: 'bg-emerald-100 text-emerald-700',
  SHOP: 'bg-amber-100 text-amber-700',
  GARAGE: 'bg-stone-100 text-stone-700',
}

const typeIcons: Record<string, React.ElementType> = {
  ROOM: Bed,
  PG: Building2,
  HOUSE: Home,
  SHOP: Store,
  GARAGE: Warehouse,
}

interface PropertyCardProps {
  property: Property
  onClick: (id: string) => void
}

export default function PropertyCard({ property, onClick }: PropertyCardProps) {
  const [imgError, setImgError] = useState(false)
  const [imgLoaded, setImgLoaded] = useState(false)

  const images: string[] = (() => {
    try {
      const parsed = JSON.parse(property.images)
      return Array.isArray(parsed) ? parsed.filter((img: string) => img && img.length > 10) : []
    } catch { return [] }
  })()

  const hasValidImage = images.length > 0 && !imgError
  const TypeIcon = typeIcons[property.type] || Building2

  const isFeatured = property.isFeatured || property.adType === 'FEATURED' || property.adType === 'TOP_LISTING'
  const isTopListing = property.adType === 'TOP_LISTING'
  const isVerified = property.isVerified

  return (
    <Card
      className={`overflow-hidden cursor-pointer hover:shadow-lg transition-all duration-300 hover:-translate-y-1 group ${
        isTopListing ? 'ring-2 ring-amber-400' : isFeatured ? 'ring-1 ring-emerald-300' : ''
      }`}
      onClick={() => onClick(property.id)}
    >
      <div className="relative aspect-[4/3] overflow-hidden bg-gray-100">
        {hasValidImage ? (
          <>
            {/* Shimmer while image loads */}
            {!imgLoaded && (
              <div className="absolute inset-0 bg-gradient-to-r from-gray-200 via-gray-100 to-gray-200 animate-[shimmer_1.5s_infinite]" style={{ backgroundSize: '200% 100%' }} />
            )}
            <img
              src={images[0]}
              alt={property.title}
              className={`w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 ${imgLoaded ? 'opacity-100' : 'opacity-0'}`}
              onLoad={() => setImgLoaded(true)}
              onError={() => setImgError(true)}
              loading="lazy"
            />
          </>
        ) : (
          /* Colored placeholder with icon */
          <div className={`w-full h-full flex flex-col items-center justify-center gap-2 ${
            property.type === 'ROOM' ? 'bg-blue-50' :
            property.type === 'PG' ? 'bg-purple-50' :
            property.type === 'HOUSE' ? 'bg-emerald-50' :
            property.type === 'SHOP' ? 'bg-amber-50' :
            'bg-stone-50'
          }`}>
            <TypeIcon className={`w-10 h-10 ${
              property.type === 'ROOM' ? 'text-blue-300' :
              property.type === 'PG' ? 'text-purple-300' :
              property.type === 'HOUSE' ? 'text-emerald-300' :
              property.type === 'SHOP' ? 'text-amber-300' :
              'text-stone-300'
            }`} />
            <span className="text-sm font-medium text-gray-400">{property.city || typeLabels[property.type] || 'Property'}</span>
          </div>
        )}

        {/* Top Badges Row */}
        <div className="absolute top-2 left-2 right-2 flex items-start justify-between">
          <div className="flex flex-wrap gap-1">
            {/* Type Badge */}
            <Badge className={`${typeColors[property.type] || 'bg-gray-100 text-gray-700'} text-[10px] px-1.5 py-0`}>
              {typeLabels[property.type] || property.type}
            </Badge>
            {/* Top Listing Badge */}
            {isTopListing && (
              <Badge className="bg-amber-500 text-white text-[10px] px-1.5 py-0 gap-0.5">
                <Crown className="w-2.5 h-2.5" /> Top
              </Badge>
            )}
            {/* Featured Badge */}
            {isFeatured && !isTopListing && (
              <Badge className="bg-emerald-500 text-white text-[10px] px-1.5 py-0 gap-0.5">
                <Zap className="w-2.5 h-2.5" /> Featured
              </Badge>
            )}
          </div>
          {/* Verified Badge */}
          {isVerified && (
            <div className="w-6 h-6 rounded-full bg-emerald-500 flex items-center justify-center shadow-md">
              <Shield className="w-3.5 h-3.5 text-white" />
            </div>
          )}
        </div>

        {/* Image count indicator */}
        {images.length > 1 && hasValidImage && (
          <div className="absolute bottom-2 right-2 bg-black/60 text-white text-xs px-2 py-0.5 rounded-full flex items-center gap-1">
            <ImageIcon className="w-3 h-3" /> {images.length}
          </div>
        )}

        {/* Featured gradient overlay at bottom */}
        {isFeatured && (
          <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-black/20 to-transparent" />
        )}
      </div>

      <CardContent className="p-3 sm:p-4">
        <h3 className="font-semibold text-gray-900 line-clamp-1 mb-1 text-xs sm:text-base">
          {property.title}
        </h3>

        <div className="flex items-center gap-1 text-gray-500 text-[11px] sm:text-sm mb-2">
          <MapPin className="w-3 h-3 flex-shrink-0" />
          <span className="line-clamp-1">{property.city}, {property.state}</span>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-0.5 text-emerald-700 font-bold text-xs sm:text-base">
            <IndianRupee className="w-3.5 h-3.5" />
            <span>{property.rent.toLocaleString('en-IN')}</span>
            <span className="text-gray-400 font-normal text-xs">/mo</span>
          </div>

          {property.avgRating !== undefined && property.avgRating > 0 && (
            <div className="flex items-center gap-0.5">
              <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
              <span className="text-xs font-medium text-gray-600">
                {property.avgRating}
              </span>
              {property.reviewCount !== undefined && property.reviewCount > 0 && (
                <span className="text-[10px] text-gray-400">({property.reviewCount})</span>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
