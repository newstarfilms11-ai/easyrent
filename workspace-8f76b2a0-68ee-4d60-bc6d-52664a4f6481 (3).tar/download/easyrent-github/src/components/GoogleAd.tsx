'use client'

export default function GoogleAd({ slot = 'vertical' }: { slot?: string }) {
  return (
    <div
      className={`w-full bg-gradient-to-r from-gray-50 to-gray-100 border border-dashed border-gray-300 rounded-lg flex items-center justify-center text-gray-400 relative overflow-hidden ${
        slot === 'horizontal'
          ? 'h-[90px] py-4'
          : 'h-[250px] py-6'
      }`}
    >
      <div className="text-center">
        <div className="text-xs uppercase tracking-wider mb-1 font-medium">Advertisement</div>
        <div className="text-xs text-gray-300">Google AdMob</div>
        <div className="text-[10px] text-gray-300 mt-0.5">
          {slot === 'horizontal' ? 'Banner Ad (320×50)' : 'Medium Rectangle (300×250)'}
        </div>
      </div>
      {/* Ad format indicator */}
      <div className="absolute top-1 right-2 text-[9px] text-gray-300 font-mono">
        ca-app-pub-XXXXXXX
      </div>
      {/* Simulated ad visual elements */}
      {slot === 'horizontal' && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-10">
          <div className="flex gap-4 items-center">
            <div className="w-16 h-12 bg-gray-300 rounded" />
            <div className="space-y-1">
              <div className="w-32 h-2 bg-gray-300 rounded" />
              <div className="w-24 h-2 bg-gray-300 rounded" />
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
