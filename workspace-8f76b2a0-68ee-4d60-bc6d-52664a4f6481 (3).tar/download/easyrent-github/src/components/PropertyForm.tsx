'use client'

import { useState, useCallback } from 'react'
import { useStore, Property } from './store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Upload, X, MapPin, ImagePlus, Video, IndianRupee, Zap, Crown, Star, Gift, Check } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

const adTypes = [
  { id: 'FREE', name: 'Free Ad', price: 0, description: 'Pehla ad free!', badge: 'Free', icon: Gift },
  { id: 'BASIC', name: 'Basic Ad', price: 49, description: '15 days visibility', badge: '₹49', icon: Star },
  { id: 'FEATURED', name: 'Featured Ad', price: 99, description: '30 days + Featured badge', badge: '₹99', icon: Zap },
  { id: 'TOP_LISTING', name: 'Top Listing', price: 299, description: '60 days + Top position', badge: '₹299', icon: Crown },
]

interface PropertyFormProps {
  editProperty?: Property | null
}

export default function PropertyForm({ editProperty }: PropertyFormProps) {
  const { currentUser, setCurrentView, setEditingProperty } = useStore()
  const { toast } = useToast()

  const [loading, setLoading] = useState(false)
  const [title, setTitle] = useState(editProperty?.title || '')
  const [description, setDescription] = useState(editProperty?.description || '')
  const [type, setType] = useState(editProperty?.type || '')
  const [rent, setRent] = useState(editProperty?.rent?.toString() || '')
  const [deposit, setDeposit] = useState(editProperty?.deposit?.toString() || '')
  const [address, setAddress] = useState(editProperty?.address || '')
  const [city, setCity] = useState(editProperty?.city || '')
  const [state, setState] = useState(editProperty?.state || '')
  const [lat, setLat] = useState(editProperty?.lat?.toString() || '')
  const [lng, setLng] = useState(editProperty?.lng?.toString() || '')
  const [availableFrom, setAvailableFrom] = useState(editProperty?.availableFrom || '')
  const [availableTo, setAvailableTo] = useState(editProperty?.availableTo || '')
  const [images, setImages] = useState<string[]>(() => {
    if (editProperty?.images) {
      try { return JSON.parse(editProperty.images) } catch { return [] }
    }
    return []
  })
  const [videoUrl, setVideoUrl] = useState(editProperty?.video || '')
  const [uploading, setUploading] = useState(false)
  const [adType, setAdType] = useState(editProperty?.adType || 'FREE')
  const [showPayment, setShowPayment] = useState(false)
  const [upiId, setUpiId] = useState('')
  const [paymentProcessing, setPaymentProcessing] = useState(false)

  const freeAdsUsed = currentUser?.freeAdsUsed || 0
  const isFirstAd = freeAdsUsed === 0
  const isPaidAd = adType !== 'FREE'
  const selectedAdPrice = adTypes.find(a => a.id === adType)?.price || 0

  const handleFileUpload = useCallback(async (files: FileList, type: 'image' | 'video') => {
    setUploading(true)
    for (let i = 0; i < files.length; i++) {
      const file = files[i]
      if (file.size > 10 * 1024 * 1024) {
        toast({ title: 'File bahut badi hai', description: 'Max 10MB per file', variant: 'destructive' })
        continue
      }

      try {
        // Convert to base64 directly on client side
        const dataUrl = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader()
          reader.onload = () => resolve(reader.result as string)
          reader.onerror = reject
          reader.readAsDataURL(file)
        })

        if (type === 'image') {
          setImages((prev) => [...prev, dataUrl])
        } else {
          setVideoUrl(dataUrl)
        }
        toast({ title: type === 'image' ? 'Photo add ho gayi!' : 'Video add ho gaya!' })
      } catch {
        toast({ title: 'Upload fail ho gaya', variant: 'destructive' })
      }
    }
    setUploading(false)
  }, [toast])

  const handleAdPostingPayment = async (propertyId: string) => {
    if (!isPaidAd || !currentUser) return
    setPaymentProcessing(true)
    try {
      const res = await fetch('/api/monetization/ad-posting', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          propertyId,
          adType,
          upiId,
          userId: currentUser.id,
        }),
      })
      const data = await res.json()
      if (res.ok && data.success) {
        toast({ title: data.message })
      } else {
        toast({ title: data.error || 'Payment fail ho gaya', variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Payment fail ho gaya', variant: 'destructive' })
    } finally {
      setPaymentProcessing(false)
    }
  }

  const handleSubmit = async () => {
    if (!currentUser) {
      toast({ title: 'Pehle login karein!', description: 'Property add karne ke liye login zaroori hai', variant: 'destructive' })
      setCurrentView('login')
      return
    }

    if (!title || !type || !rent || !deposit || !address || !city || !state || !availableFrom) {
      toast({ title: 'Sab required fields bharein!', description: 'Title, Type, Rent, Deposit, Address, City, State, Available From - yeh sab zaroori hai', variant: 'destructive' })
      return
    }

    // For paid ads, show payment first
    if (isPaidAd && !showPayment && !editProperty) {
      setShowPayment(true)
      return
    }

    // For paid ads, UPI ID is required
    if (isPaidAd && !upiId.includes('@')) {
      toast({ title: 'UPI ID daalein payment ke liye!', variant: 'destructive' })
      return
    }

    const rentNum = parseInt(rent)
    const depositNum = parseInt(deposit)

    if (isNaN(rentNum) || rentNum <= 0) {
      toast({ title: 'Sahi rent amount daalein!', variant: 'destructive' })
      return
    }
    if (isNaN(depositNum) || depositNum <= 0) {
      toast({ title: 'Sahi deposit amount daalein!', variant: 'destructive' })
      return
    }

    setLoading(true)
    try {
      const payload = {
        title,
        description: description || '',
        type,
        rent: rentNum,
        deposit: depositNum,
        address,
        city,
        state,
        lat: lat ? parseFloat(lat) : null,
        lng: lng ? parseFloat(lng) : null,
        images: JSON.stringify(images),
        video: videoUrl || null,
        availableFrom,
        availableTo: availableTo || null,
        ownerId: currentUser.id,
        adType,
      }

      if (editProperty) {
        const res = await fetch(`/api/properties/${editProperty.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...payload, userId: currentUser.id }),
        })
        const data = await res.json()
        if (res.ok) {
          toast({ title: 'Property update ho gayi! ✅', description: 'Aapki property successfully update ho gayi hai' })
          setEditingProperty(null)
          setCurrentView('dashboard')
        } else {
          toast({ title: 'Update nahi hui!', description: data.error || 'Kuch gadbad ho gayi', variant: 'destructive' })
        }
      } else {
        const res = await fetch('/api/properties', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        })
        const data = await res.json()
        if (res.ok) {
          // Handle ad posting payment for paid ads
          if (isPaidAd && data.property?.id) {
            await handleAdPostingPayment(data.property.id)
          }
          toast({ title: 'Property add ho gayi! ✅', description: 'Admin approval ke baad listing dikhegi. Dashboard mein dekhein.' })
          setCurrentView('dashboard')
        } else {
          console.error('Property creation error:', data)
          toast({ title: 'Property add nahi hui!', description: data.error || 'Kuch gadbad ho gayi', variant: 'destructive' })
        }
      }
    } catch (error) {
      console.error('Submit error:', error)
      toast({ title: 'Kuch gadbad ho gayi!', description: 'Dubara try karein', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-6 pb-24 md:pb-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-xl text-emerald-700">
            {editProperty ? '✏️ Edit Property' : '🏠 Post New Property'}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-5">
          {/* Ad Type Selector */}
          {!editProperty && (
            <div>
              <Label className="text-base font-semibold mb-2 block">📢 Choose Ad Type</Label>
              {isFirstAd && (
                <Card className="mb-3 bg-emerald-50 border-emerald-200">
                  <CardContent className="p-3 flex items-center gap-2">
                    <Gift className="w-5 h-5 text-emerald-600" />
                    <span className="text-sm text-emerald-700 font-medium">🎉 Pehla ad bilkul FREE! Koi charge nahi hoga.</span>
                  </CardContent>
                </Card>
              )}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {adTypes.map((at) => {
                  const Icon = at.icon
                  const isSelected = adType === at.id
                  const isDisabled = at.id === 'FREE' && !isFirstAd
                  return (
                    <button
                      key={at.id}
                      onClick={() => !isDisabled && setAdType(at.id)}
                      disabled={isDisabled}
                      className={`relative p-3 rounded-xl border-2 text-center transition-all ${
                        isSelected
                          ? 'border-emerald-500 bg-emerald-50 shadow-md'
                          : isDisabled
                          ? 'border-gray-100 bg-gray-50 opacity-50 cursor-not-allowed'
                          : 'border-gray-200 hover:border-emerald-300 hover:bg-emerald-50/50'
                      }`}
                    >
                      <Icon className={`w-5 h-5 mx-auto mb-1 ${isSelected ? 'text-emerald-600' : 'text-gray-400'}`} />
                      <p className={`text-sm font-semibold ${isSelected ? 'text-emerald-700' : 'text-gray-700'}`}>{at.name}</p>
                      <p className="text-xs text-gray-500">{at.description}</p>
                      <Badge className={`mt-1 ${at.id === 'TOP_LISTING' ? 'bg-amber-500' : at.id === 'FEATURED' ? 'bg-emerald-500' : at.id === 'BASIC' ? 'bg-blue-500' : 'bg-gray-500'} text-white`}>
                        {at.badge}
                      </Badge>
                      {isSelected && (
                        <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center">
                          <Check className="w-3 h-3" />
                        </div>
                      )}
                    </button>
                  )
                })}
              </div>
            </div>
          )}

          {/* Payment Section for Paid Ads */}
          {isPaidAd && showPayment && !editProperty && (
            <Card className="border-emerald-200 bg-emerald-50/50">
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-semibold text-emerald-700 flex items-center gap-1">
                    <IndianRupee className="w-4 h-4" /> Payment Required
                  </h4>
                  <Badge className="bg-emerald-600 text-white">₹{selectedAdPrice}</Badge>
                </div>
                <p className="text-xs text-gray-500">Demo mode: Payment simulate hoga (90% success rate)</p>
                <div>
                  <Label>UPI ID *</Label>
                  <Input
                    placeholder="yourname@upi"
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value)}
                  />
                </div>
              </CardContent>
            </Card>
          )}

          {/* Title */}
          <div>
            <Label htmlFor="title">Title *</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Spacious AC Room near Metro"
            />
          </div>

          {/* Description */}
          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe your property..."
              rows={4}
            />
          </div>

          {/* Type & Rent */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <Label>Type *</Label>
              <Select value={type} onValueChange={setType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ROOM">कमरा / Room</SelectItem>
                  <SelectItem value="PG">PG / Paying Guest</SelectItem>
                  <SelectItem value="HOUSE">मकान / House</SelectItem>
                  <SelectItem value="SHOP">दुकान / Shop</SelectItem>
                  <SelectItem value="GARAGE">गैराज / Garage</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="rent">Rent (₹/month) *</Label>
              <Input
                id="rent"
                type="number"
                value={rent}
                onChange={(e) => setRent(e.target.value)}
                placeholder="8000"
              />
            </div>
            <div>
              <Label htmlFor="deposit">Deposit (₹) *</Label>
              <Input
                id="deposit"
                type="number"
                value={deposit}
                onChange={(e) => setDeposit(e.target.value)}
                placeholder="16000"
              />
            </div>
          </div>

          {/* Address */}
          <div>
            <Label htmlFor="address">Address *</Label>
            <Input
              id="address"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Full address"
            />
          </div>

          {/* City & State */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="city">City *</Label>
              <Input
                id="city"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="e.g., Mumbai"
              />
            </div>
            <div>
              <Label htmlFor="state">State *</Label>
              <Input
                id="state"
                value={state}
                onChange={(e) => setState(e.target.value)}
                placeholder="e.g., Maharashtra"
              />
            </div>
          </div>

          {/* Lat/Lng */}
          <div>
            <Label className="flex items-center gap-1">
              <MapPin className="w-4 h-4" /> Location Coordinates
            </Label>
            <div className="grid grid-cols-2 gap-4 mt-1">
              <Input
                placeholder="Latitude (e.g., 28.6139)"
                value={lat}
                onChange={(e) => setLat(e.target.value)}
              />
              <Input
                placeholder="Longitude (e.g., 77.2090)"
                value={lng}
                onChange={(e) => setLng(e.target.value)}
              />
            </div>
          </div>

          {/* Dates */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="availableFrom">Available From *</Label>
              <Input
                id="availableFrom"
                type="date"
                value={availableFrom}
                onChange={(e) => setAvailableFrom(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="availableTo">Available To</Label>
              <Input
                id="availableTo"
                type="date"
                value={availableTo}
                onChange={(e) => setAvailableTo(e.target.value)}
              />
            </div>
          </div>

          {/* Image Upload */}
          <div>
            <Label className="text-base font-semibold">📸 Photos</Label>
            <p className="text-xs text-gray-500 mb-2">Camera se photo lein ya gallery se choose karein</p>
            <div className="mt-2 grid grid-cols-2 sm:grid-cols-3 gap-3">
              {images.map((img, i) => (
                <div key={i} className="relative group aspect-square rounded-lg overflow-hidden border">
                  <img src={img} alt={`Photo ${i + 1}`} className="w-full h-full object-cover" />
                  <button
                    onClick={() => setImages(images.filter((_, idx) => idx !== i))}
                    className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1.5 shadow-md opacity-100 group-hover:opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
              {uploading && (
                <div className="aspect-square rounded-lg border-2 border-dashed border-emerald-400 bg-emerald-50 flex flex-col items-center justify-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600" />
                  <span className="text-xs text-emerald-600 mt-2">Uploading...</span>
                </div>
              )}
              {/* Camera Button */}
              <label className="aspect-square rounded-lg border-2 border-dashed border-gray-300 flex flex-col items-center justify-center cursor-pointer hover:border-emerald-400 hover:bg-emerald-50 transition-colors">
                <ImagePlus className="w-6 h-6 text-gray-400 mb-1" />
                <span className="text-xs text-gray-500">Camera</span>
                <input
                  type="file"
                  accept="image/*"
                  capture="environment"
                  className="hidden"
                  onChange={(e) => e.target.files && handleFileUpload(e.target.files, 'image')}
                />
              </label>
              {/* Gallery Button */}
              <label className="aspect-square rounded-lg border-2 border-dashed border-gray-300 flex flex-col items-center justify-center cursor-pointer hover:border-emerald-400 hover:bg-emerald-50 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6 text-gray-400 mb-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg>
                <span className="text-xs text-gray-500">Gallery</span>
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  className="hidden"
                  onChange={(e) => e.target.files && handleFileUpload(e.target.files, 'image')}
                />
              </label>
            </div>
          </div>

          {/* Video Upload */}
          <div>
            <Label className="text-base font-semibold">🎥 Video</Label>
            <p className="text-xs text-gray-500 mb-2">Camera se video lein ya gallery se choose karein</p>
            <div className="mt-2">
              {videoUrl ? (
                <div className="relative rounded-lg overflow-hidden border">
                  <video src={videoUrl} controls className="w-full max-h-48" />
                  <button
                    onClick={() => setVideoUrl('')}
                    className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1.5 shadow-md"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div className="flex gap-3">
                  <label className="flex-1 flex items-center justify-center gap-2 p-4 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-emerald-400 hover:bg-emerald-50 transition-colors">
                    <Video className="w-5 h-5 text-gray-400" />
                    <span className="text-sm text-gray-500">Camera Video</span>
                    <input
                      type="file"
                      accept="video/*"
                      capture="environment"
                      className="hidden"
                      onChange={(e) => e.target.files && handleFileUpload(e.target.files, 'video')}
                    />
                  </label>
                  <label className="flex-1 flex items-center justify-center gap-2 p-4 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-emerald-400 hover:bg-emerald-50 transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5 text-gray-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg>
                    <span className="text-sm text-gray-500">Gallery Video</span>
                    <input
                      type="file"
                      accept="video/*"
                      className="hidden"
                      onChange={(e) => e.target.files && handleFileUpload(e.target.files, 'video')}
                    />
                  </label>
                </div>
              )}
            </div>
          </div>

          {/* Submit */}
          <div className="flex gap-3 pt-2">
            <Button
              onClick={handleSubmit}
              disabled={loading || paymentProcessing}
              className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white"
            >
              {loading || paymentProcessing ? (
                <span className="flex items-center gap-2">
                  <Upload className="w-4 h-4 animate-bounce" /> {paymentProcessing ? 'Processing Payment...' : 'Submitting...'}
                </span>
              ) : editProperty ? (
                'Update Property'
              ) : isPaidAd && !showPayment ? (
                `Continue to Pay ₹${selectedAdPrice}`
              ) : (
                'Post Property'
              )}
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                setEditingProperty(null)
                setCurrentView('home')
              }}
            >
              Cancel
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
