'use client'

import { useState, useEffect } from 'react'
import { useStore, Property, Review } from './store'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Star, MapPin, IndianRupee, Phone, Mail, Calendar, ChevronLeft, ChevronRight,
  Home, Shield, User, CheckCircle2, XCircle, Clock, Zap, Crown, ShieldCheck,
  Rocket, Award,
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import ReviewSection from './ReviewSection'

const typeLabels: Record<string, string> = {
  ROOM: 'कमरा / Room',
  PG: 'PG / Paying Guest',
  HOUSE: 'मकान / House',
  SHOP: 'दुकान / Shop',
  GARAGE: 'गैराज / Garage',
}

const boostOptions = [
  { id: '3_DAY', name: '3 Days Boost', price: 99, days: 3 },
  { id: '7_DAY', name: '7 Days Boost', price: 199, days: 7 },
  { id: '30_DAY', name: '30 Days Premium', price: 599, days: 30 },
]

export default function PropertyDetail() {
  const { selectedPropertyId, currentUser, setCurrentView, setEditingProperty } = useStore()
  const { toast } = useToast()

  const [property, setProperty] = useState<Property | null>(null)
  const [loading, setLoading] = useState(true)
  const [currentImageIdx, setCurrentImageIdx] = useState(0)
  const [showApplyForm, setShowApplyForm] = useState(false)
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')
  const [upiId, setUpiId] = useState('')
  const [applyLoading, setApplyLoading] = useState(false)
  const [showBoostDialog, setShowBoostDialog] = useState(false)
  const [selectedBoost, setSelectedBoost] = useState('7_DAY')
  const [boostUpiId, setBoostUpiId] = useState('')
  const [boostLoading, setBoostLoading] = useState(false)

  useEffect(() => {
    if (selectedPropertyId) {
      fetchProperty()
    }
  }, [selectedPropertyId])

  const fetchProperty = async () => {
    setLoading(true)
    try {
      const res = await fetch(`/api/properties/${selectedPropertyId}`)
      const data = await res.json()
      if (res.ok) {
        setProperty(data.property)
      }
    } catch {
      toast({ title: 'Failed to load property', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  const handleBoost = async () => {
    if (!boostUpiId.includes('@')) {
      toast({ title: 'Sahi UPI ID daalein!', variant: 'destructive' })
      return
    }
    setBoostLoading(true)
    try {
      const res = await fetch('/api/monetization/boost', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          propertyId: property?.id,
          boostType: selectedBoost,
          upiId: boostUpiId,
          userId: currentUser?.id,
        }),
      })
      const data = await res.json()
      if (res.ok && data.success) {
        toast({ title: data.message })
        setShowBoostDialog(false)
        setBoostUpiId('')
        fetchProperty()
      } else {
        toast({ title: data.error || data.message || 'Boost fail ho gaya!', variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Boost fail ho gaya!', variant: 'destructive' })
    } finally {
      setBoostLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600" />
      </div>
    )
  }

  if (!property) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <p className="text-gray-500">Property not found</p>
      </div>
    )
  }

  const images: string[] = (() => {
    try { return JSON.parse(property.images) } catch { return [] }
  })()

  const isOwner = currentUser && (currentUser.id === property.ownerId || currentUser.role === 'ADMIN')
  const isFeatured = property.isFeatured || property.adType === 'FEATURED'
  const isTopListing = property.adType === 'TOP_LISTING'
  const isVerified = property.isVerified
  const isBoosted = property.featuredUntil && new Date(property.featuredUntil) > new Date()

  const handleApply = async () => {
    if (!currentUser) {
      toast({ title: 'Please login first', variant: 'destructive' })
      setCurrentView('login')
      return
    }
    if (!startDate || !endDate || !upiId) {
      toast({ title: 'Please fill all fields', variant: 'destructive' })
      return
    }

    setApplyLoading(true)
    try {
      const rentalRes = await fetch('/api/rentals', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          propertyId: property.id,
          tenantId: currentUser.id,
          startDate,
          endDate,
        }),
      })
      const rentalData = await rentalRes.json()

      if (!rentalRes.ok) {
        toast({ title: rentalData.error || 'Failed to apply', variant: 'destructive' })
        return
      }

      const paymentRes = await fetch('/api/payments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rentalId: rentalData.rental.id,
          amount: property.deposit,
          upiId,
        }),
      })
      const paymentData = await paymentRes.json()

      if (paymentData.payment?.status === 'COMPLETED') {
        toast({ title: '🎉 Rental application submitted & payment successful!' })
      } else {
        toast({ title: 'Application submitted, but payment failed. Try again.', variant: 'destructive' })
      }

      setShowApplyForm(false)
      setCurrentView('my-rentals')
    } catch {
      toast({ title: 'Something went wrong', variant: 'destructive' })
    } finally {
      setApplyLoading(false)
    }
  }

  const handleEdit = () => {
    setEditingProperty(property)
    setCurrentView('edit-property')
  }

  const handleDelete = async () => {
    if (!confirm('Are you sure you want to delete this property?')) return
    try {
      const res = await fetch(`/api/properties/${property.id}?userId=${currentUser?.id}&role=${currentUser?.role}`, {
        method: 'DELETE',
      })
      if (res.ok) {
        toast({ title: 'Property deleted' })
        setCurrentView('dashboard')
      }
    } catch {
      toast({ title: 'Delete failed', variant: 'destructive' })
    }
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-6 pb-24 md:pb-6">
      {/* Back button */}
      <button
        onClick={() => setCurrentView('listings')}
        className="flex items-center gap-1 text-emerald-600 hover:text-emerald-700 mb-4 text-sm font-medium"
      >
        <ChevronLeft className="w-4 h-4" /> Back to Listings
      </button>

      {/* Image Gallery */}
      <div className="relative rounded-xl overflow-hidden bg-gray-100 aspect-video mb-6">
        {images.length > 0 ? (
          <>
            <img
              src={images[currentImageIdx]}
              alt={property.title}
              className="w-full h-full object-cover"
            />
            {images.length > 1 && (
              <>
                <button
                  onClick={() => setCurrentImageIdx((currentImageIdx - 1 + images.length) % images.length)}
                  className="absolute left-2 top-1/2 -translate-y-1/2 bg-white/80 rounded-full p-2 shadow hover:bg-white"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setCurrentImageIdx((currentImageIdx + 1) % images.length)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/80 rounded-full p-2 shadow hover:bg-white"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
                <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
                  {images.map((_, i) => (
                    <button
                      key={i}
                      onClick={() => setCurrentImageIdx(i)}
                      className={`w-2 h-2 rounded-full transition-colors ${
                        i === currentImageIdx ? 'bg-white' : 'bg-white/50'
                      }`}
                    />
                  ))}
                </div>
              </>
            )}
          </>
        ) : (
          <div className="w-full h-full flex items-center justify-center text-gray-400">
            No images available
          </div>
        )}
        <Badge className="absolute top-3 left-3 bg-emerald-600 text-white">
          {typeLabels[property.type] || property.type}
        </Badge>

        {/* Top Listing Badge */}
        {isTopListing && (
          <Badge className="absolute top-3 right-3 bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0 gap-1">
            <Crown className="w-3 h-3" /> Top Listing
          </Badge>
        )}

        {/* Featured Badge */}
        {isFeatured && !isTopListing && (
          <Badge className="absolute top-3 right-3 bg-gradient-to-r from-emerald-500 to-teal-500 text-white border-0 gap-1">
            <Zap className="w-3 h-3" /> Featured
          </Badge>
        )}
      </div>

      {/* Video */}
      {property.video && (
        <div className="mb-6 rounded-xl overflow-hidden border">
          <video src={property.video} controls className="w-full" />
        </div>
      )}

      {/* Thumbnail strip */}
      {images.length > 1 && (
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {images.map((img, i) => (
            <button
              key={i}
              onClick={() => setCurrentImageIdx(i)}
              className={`flex-shrink-0 w-20 h-14 rounded-lg overflow-hidden border-2 ${
                i === currentImageIdx ? 'border-emerald-500' : 'border-transparent'
              }`}
            >
              <img src={img} alt="" className="w-full h-full object-cover" />
            </button>
          ))}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main content */}
        <div className="lg:col-span-2 space-y-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <h1 className="text-2xl font-bold text-gray-900">{property.title}</h1>
              {isVerified && (
                <Badge className="bg-green-100 text-green-700 border-green-200 gap-1">
                  <ShieldCheck className="w-3 h-3" /> Verified
                </Badge>
              )}
            </div>
            <div className="flex flex-wrap items-center gap-3 text-sm text-gray-500 mb-3">
              <span className="flex items-center gap-1">
                <MapPin className="w-4 h-4" /> {property.address}, {property.city}, {property.state}
              </span>
              {property.avgRating !== undefined && property.avgRating > 0 && (
                <span className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-amber-400 text-amber-400" /> {property.avgRating}
                </span>
              )}
              {isBoosted && (
                <span className="flex items-center gap-1 text-emerald-600">
                  <Rocket className="w-4 h-4" /> Boosted
                </span>
              )}
            </div>
          </div>

          <Separator />

          {/* Key details */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <Card className="p-3 text-center">
              <IndianRupee className="w-5 h-5 text-emerald-600 mx-auto mb-1" />
              <div className="font-bold text-lg text-emerald-700">₹{property.rent.toLocaleString('en-IN')}</div>
              <div className="text-xs text-gray-500">Monthly Rent</div>
            </Card>
            <Card className="p-3 text-center">
              <Shield className="w-5 h-5 text-emerald-600 mx-auto mb-1" />
              <div className="font-bold text-lg text-emerald-700">₹{property.deposit.toLocaleString('en-IN')}</div>
              <div className="text-xs text-gray-500">Security Deposit</div>
            </Card>
            <Card className="p-3 text-center">
              <Calendar className="w-5 h-5 text-emerald-600 mx-auto mb-1" />
              <div className="font-bold text-sm text-emerald-700">{property.availableFrom}</div>
              <div className="text-xs text-gray-500">Available From</div>
            </Card>
            <Card className="p-3 text-center">
              <Home className="w-5 h-5 text-emerald-600 mx-auto mb-1" />
              <div className="font-bold text-sm text-emerald-700">{typeLabels[property.type]}</div>
              <div className="text-xs text-gray-500">Property Type</div>
            </Card>
          </div>

          {/* Description */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Description</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 whitespace-pre-wrap">{property.description || 'No description provided.'}</p>
            </CardContent>
          </Card>

          {/* Map */}
          {property.lat && property.lng && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-emerald-600" /> Location
                </CardTitle>
              </CardHeader>
              <CardContent>
                <iframe
                  src={`https://maps.google.com/maps?q=${property.lat},${property.lng}&z=15&output=embed`}
                  className="w-full h-64 rounded-lg border"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  title="Property Location"
                />
              </CardContent>
            </Card>
          )}

          {/* Reviews */}
          <ReviewSection propertyId={property.id} reviews={property.reviews || []} onReviewAdded={fetchProperty} />
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          {/* Monetization Badges Card */}
          {(isFeatured || isVerified || isTopListing || isBoosted) && (
            <Card className="bg-gradient-to-br from-emerald-50 to-teal-50 border-emerald-200">
              <CardContent className="p-4 space-y-2">
                <h4 className="font-semibold text-emerald-700 text-sm">Listing Highlights</h4>
                {isTopListing && (
                  <div className="flex items-center gap-2 text-sm text-amber-700">
                    <Crown className="w-4 h-4" /> Top Listing
                  </div>
                )}
                {isFeatured && (
                  <div className="flex items-center gap-2 text-sm text-emerald-700">
                    <Zap className="w-4 h-4" /> Featured
                  </div>
                )}
                {isVerified && (
                  <div className="flex items-center gap-2 text-sm text-green-700">
                    <ShieldCheck className="w-4 h-4" /> Verified Property
                  </div>
                )}
                {isBoosted && (
                  <div className="flex items-center gap-2 text-sm text-teal-700">
                    <Rocket className="w-4 h-4" /> Boosted until {new Date(property.featuredUntil!).toLocaleDateString('en-IN')}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Owner Card */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Owner Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center">
                  <User className="w-6 h-6 text-emerald-600" />
                </div>
                <div>
                  <div className="font-semibold">{property.owner?.name || 'Owner'}</div>
                  <div className="text-xs text-gray-500">Property Owner</div>
                </div>
              </div>
              <Separator />
              <div className="flex items-center gap-2 text-sm">
                <Phone className="w-4 h-4 text-emerald-600" />
                <span>{property.owner?.phone || 'N/A'}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Mail className="w-4 h-4 text-emerald-600" />
                <span>{property.owner?.email || 'N/A'}</span>
              </div>
            </CardContent>
          </Card>

          {/* EasyRent Office WhatsApp Support */}
          <a
            href="https://wa.me/918968541628?text=Hi%20EasyRent!%20I%20am%20interested%20in%20a%20property.%20Please%20help%20me."
            target="_blank"
            rel="noopener noreferrer"
            className="block bg-gradient-to-r from-green-500 to-green-600 text-white rounded-xl p-4 hover:shadow-lg hover:scale-[1.01] transition-all group"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center group-hover:bg-white/30 transition-colors flex-shrink-0">
                <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-sm">EasyRent Office WhatsApp</h4>
                <p className="text-green-100 text-xs">89685-41628 — Koi sawal ho? Abhi message karein!</p>
              </div>
            </div>
          </a>

          {/* Boost this listing (for owners) */}
          {isOwner && (
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="p-4">
                <h4 className="font-semibold text-amber-700 flex items-center gap-1 mb-2">
                  <Rocket className="w-4 h-4" /> Boost This Listing
                </h4>
                <p className="text-xs text-gray-500 mb-3">
                  Apni listing ko top par laayein aur zyada leads paayein!
                </p>
                <Button
                  onClick={() => {
                    if (!currentUser) {
                      setCurrentView('login')
                      return
                    }
                    setShowBoostDialog(true)
                  }}
                  className="w-full bg-amber-500 hover:bg-amber-600 text-white"
                >
                  <Rocket className="w-4 h-4 mr-1" /> Boost Now
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Get Verified (for owners) */}
          {isOwner && !isVerified && (
            <Card className="border-green-200 bg-green-50/50">
              <CardContent className="p-4">
                <h4 className="font-semibold text-green-700 flex items-center gap-1 mb-2">
                  <ShieldCheck className="w-4 h-4" /> Get Verified
                </h4>
                <p className="text-xs text-gray-500 mb-3">
                  Verified properties ko 3x zyada leads milte hain!
                </p>
                <Button
                  onClick={() => setCurrentView('pricing')}
                  className="w-full bg-green-600 hover:bg-green-700 text-white"
                >
                  <Shield className="w-4 h-4 mr-1" /> Get Verified
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Apply for Rent */}
          <Card>
            <CardContent className="p-4">
              {!showApplyForm ? (
                <Button
                  onClick={() => {
                    if (!currentUser) {
                      setCurrentView('login')
                      return
                    }
                    setShowApplyForm(true)
                  }}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white text-lg py-6"
                >
                  Apply for Rent
                </Button>
              ) : (
                <div className="space-y-3">
                  <h4 className="font-semibold text-emerald-700">Apply for Rent</h4>
                  <div>
                    <Label>Start Date *</Label>
                    <Input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
                  </div>
                  <div>
                    <Label>End Date *</Label>
                    <Input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
                  </div>
                  <div>
                    <Label>UPI ID *</Label>
                    <Input
                      placeholder="yourname@upi"
                      value={upiId}
                      onChange={(e) => setUpiId(e.target.value)}
                    />
                  </div>
                  <div className="text-sm text-gray-500">
                    Deposit: ₹{property.deposit.toLocaleString('en-IN')} will be charged
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={handleApply}
                      disabled={applyLoading}
                      className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white"
                    >
                      {applyLoading ? 'Processing...' : 'Pay & Apply'}
                    </Button>
                    <Button variant="outline" onClick={() => setShowApplyForm(false)}>Cancel</Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Owner actions */}
          {isOwner && (
            <Card>
              <CardContent className="p-4 flex gap-2">
                <Button onClick={handleEdit} variant="outline" className="flex-1">
                  Edit
                </Button>
                <Button onClick={handleDelete} variant="destructive" className="flex-1">
                  Delete
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Status */}
          {property.status !== 'APPROVED' && (
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="p-4 flex items-center gap-2">
                {property.status === 'PENDING' ? (
                  <>
                    <Clock className="w-5 h-5 text-amber-600" />
                    <span className="text-amber-700 text-sm font-medium">Pending Approval</span>
                  </>
                ) : (
                  <>
                    <XCircle className="w-5 h-5 text-red-600" />
                    <span className="text-red-700 text-sm font-medium">Rejected</span>
                  </>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Boost Dialog */}
      <Dialog open={showBoostDialog} onOpenChange={setShowBoostDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Rocket className="w-5 h-5 text-amber-500" /> Boost Your Listing
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="mb-2 block">Select Boost Plan</Label>
              <div className="space-y-2">
                {boostOptions.map((b) => (
                  <button
                    key={b.id}
                    onClick={() => setSelectedBoost(b.id)}
                    className={`w-full flex items-center justify-between p-3 rounded-lg border-2 transition-all ${
                      selectedBoost === b.id
                        ? 'border-emerald-500 bg-emerald-50'
                        : 'border-gray-200 hover:border-emerald-300'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Rocket className={`w-5 h-5 ${selectedBoost === b.id ? 'text-emerald-600' : 'text-gray-400'}`} />
                      <div className="text-left">
                        <p className="font-medium text-sm">{b.name}</p>
                        <p className="text-xs text-gray-500">{b.days} days active</p>
                      </div>
                    </div>
                    <Badge className="bg-emerald-600 text-white">₹{b.price}</Badge>
                  </button>
                ))}
              </div>
            </div>
            <div>
              <Label>UPI ID *</Label>
              <Input
                placeholder="yourname@upi"
                value={boostUpiId}
                onChange={(e) => setBoostUpiId(e.target.value)}
              />
              <p className="text-xs text-gray-400 mt-1">Demo mode: 90% success rate</p>
            </div>
            <Button
              onClick={handleBoost}
              disabled={boostLoading}
              className="w-full bg-amber-500 hover:bg-amber-600 text-white py-5"
            >
              {boostLoading ? (
                <span className="flex items-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                  Processing...
                </span>
              ) : (
                <>
                  <Rocket className="w-4 h-4 mr-1" /> Boost for ₹{boostOptions.find(b => b.id === selectedBoost)?.price}
                </>
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
