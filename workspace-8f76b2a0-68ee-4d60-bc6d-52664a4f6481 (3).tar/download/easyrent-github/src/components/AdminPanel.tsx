'use client'

import { useState, useEffect, useCallback } from 'react'
import { useStore, Property, Rental } from './store'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Checkbox } from '@/components/ui/checkbox'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Users, Building2, CalendarRange, IndianRupee, CheckCircle2, XCircle,
  Clock, Shield, Eye, Trash2, Search, CreditCard, Star, AlertCircle,
  RefreshCw, UserCheck, UserX, Crown, BarChart3, Activity,
  Image as ImageIcon, Video, TrendingUp, TrendingDown, MapPin,
  Download, Settings, Bell, MessageSquare, ChevronRight,
  Home, Store, Bed, Warehouse, Rocket, Zap, ShieldCheck, Award,
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

// ===== INTERFACES =====
interface AdminStats {
  totalUsers: number
  totalProperties: number
  pendingProperties: number
  approvedProperties: number
  rejectedProperties: number
  activeRentals: number
  totalRentals: number
  revenue: number
  totalPayments: number
  completedPayments: number
}

interface AdminUser {
  id: string
  name: string
  email: string
  phone: string
  aadharNo?: string | null
  aadharVerified: boolean
  role: string
  createdAt: string
  _count?: {
    properties: number
    reviews: number
    rentalsAsTenant: number
  }
}

interface AdminReview {
  id: string
  rating: number
  comment: string
  createdAt: string
  user: { id: string; name: string; email: string }
  property: { id: string; title: string; city: string; status: string }
}

interface Analytics {
  typeDistribution: Record<string, number>
  cityDistribution: { city: string; count: number }[]
  statusDistribution: Record<string, number>
  avgRentByType: Record<string, number>
  monthlyData: Record<string, { properties: number; rentals: number }>
  activity: {
    type: 'property' | 'user' | 'rental'
    title: string
    subtitle: string
    user: string
    time: string
  }[]
  userStats: { total: number; verified: number; admins: number }
}

const typeLabels: Record<string, string> = {
  ROOM: 'Room',
  PG: 'PG',
  HOUSE: 'House',
  SHOP: 'Shop',
  GARAGE: 'Garage',
}

const typeIcons: Record<string, React.ElementType> = {
  ROOM: Bed,
  PG: Building2,
  HOUSE: Home,
  SHOP: Store,
  GARAGE: Warehouse,
}

const typeColors: Record<string, string> = {
  ROOM: 'bg-blue-500',
  PG: 'bg-purple-500',
  HOUSE: 'bg-emerald-500',
  SHOP: 'bg-amber-500',
  GARAGE: 'bg-gray-500',
}

const statusColors: Record<string, string> = {
  PENDING: 'bg-amber-100 text-amber-700 border-amber-200',
  APPROVED: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  REJECTED: 'bg-red-100 text-red-700 border-red-200',
  ACTIVE: 'bg-green-100 text-green-700 border-green-200',
  COMPLETED: 'bg-gray-100 text-gray-700 border-gray-200',
  CANCELLED: 'bg-red-100 text-red-700 border-red-200',
}

// ===== MINI BAR CHART COMPONENT =====
function MiniBarChart({ data, maxValue, color = 'bg-emerald-500' }: { data: number; maxValue: number; color?: string }) {
  const height = maxValue > 0 ? Math.max((data / maxValue) * 100, 4) : 4
  return (
    <div className="flex items-end h-16 w-full">
      <div
        className={`${color} rounded-t-sm w-full transition-all duration-500`}
        style={{ height: `${height}%` }}
      />
    </div>
  )
}

// ===== DONUT CHART COMPONENT =====
function SimpleDonutChart({ segments }: { segments: { label: string; value: number; color: string }[] }) {
  const total = segments.reduce((s, seg) => s + seg.value, 0)
  if (total === 0) return <div className="w-32 h-32 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 text-xs">No data</div>

  const cumulativePercents: number[] = []
  segments.reduce((acc, seg) => {
    const next = acc + (seg.value / total) * 100
    cumulativePercents.push(next)
    return next
  }, 0)
  const gradientStops = segments.map((seg, i) => {
    const startPercent = i === 0 ? 0 : cumulativePercents[i - 1]
    const endPercent = cumulativePercents[i]
    return `${seg.color} ${startPercent}% ${endPercent}%`
  }).join(', ')

  return (
    <div className="relative">
      <div
        className="w-32 h-32 rounded-full"
        style={{ background: `conic-gradient(${gradientStops})` }}
      />
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center">
          <span className="text-xs font-bold text-gray-700">{total}</span>
        </div>
      </div>
    </div>
  )
}

// ===== ACTIVITY ITEM =====
function ActivityItem({ item }: { item: Analytics['activity'][0] }) {
  const iconMap = {
    property: Building2,
    user: Users,
    rental: CalendarRange,
  }
  const colorMap = {
    property: 'text-emerald-600 bg-emerald-100',
    user: 'text-blue-600 bg-blue-100',
    rental: 'text-purple-600 bg-purple-100',
  }
  const Icon = iconMap[item.type]
  const timeAgo = getTimeAgo(new Date(item.time))

  return (
    <div className="flex items-start gap-3 py-2">
      <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${colorMap[item.type]}`}>
        <Icon className="w-4 h-4" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-gray-900 truncate">{item.title}</p>
        <p className="text-xs text-gray-500 truncate">{item.subtitle}</p>
      </div>
      <span className="text-xs text-gray-400 flex-shrink-0">{timeAgo}</span>
    </div>
  )
}

function getTimeAgo(date: Date): string {
  const now = new Date()
  const diffMs = now.getTime() - date.getTime()
  const diffMins = Math.floor(diffMs / 60000)
  if (diffMins < 1) return 'Just now'
  if (diffMins < 60) return `${diffMins}m ago`
  const diffHours = Math.floor(diffMins / 60)
  if (diffHours < 24) return `${diffHours}h ago`
  const diffDays = Math.floor(diffHours / 24)
  if (diffDays < 7) return `${diffDays}d ago`
  return date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })
}

// ===== MONETIZATION TAB COMPONENT =====
function MonetizationTab() {
  const [monoStats, setMonoStats] = useState<{
    totalRevenue: number
    completedOrders: number
    activeSubscriptions: number
    activeBoosts: number
    verificationCount: number
    revenueByType: Record<string, { amount: number; count: number }>
  } | null>(null)
  const [recentOrders, setRecentOrders] = useState<unknown[]>([])
  const [loadingMono, setLoadingMono] = useState(true)

  useEffect(() => {
    fetchMonoStats()
  }, [])

  const fetchMonoStats = async () => {
    setLoadingMono(true)
    try {
      const res = await fetch('/api/monetization/stats?admin=true')
      const data = await res.json()
      if (res.ok) {
        setMonoStats(data.stats)
        setRecentOrders(data.recentOrders || [])
      }
    } catch {
      // ignore
    } finally {
      setLoadingMono(false)
    }
  }

  if (loadingMono) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600" />
      </div>
    )
  }

  if (!monoStats) {
    return (
      <Card className="p-8 text-center">
        <p className="text-gray-500">Monetization data load nahi hua</p>
      </Card>
    )
  }

  const orderTypeLabels: Record<string, string> = {
    AD_POSTING: 'Ad Posting',
    BOOST: 'Boost',
    SUBSCRIPTION: 'Subscription',
    VERIFICATION: 'Verification',
    LEAD: 'Lead',
  }

  const orderTypeColors: Record<string, string> = {
    AD_POSTING: 'bg-emerald-500',
    BOOST: 'bg-amber-500',
    SUBSCRIPTION: 'bg-purple-500',
    VERIFICATION: 'bg-blue-500',
    LEAD: 'bg-teal-500',
  }

  const totalRevenue = monoStats.totalRevenue
  const revByType = monoStats.revenueByType
  const maxTypeRevenue = Math.max(...Object.values(revByType).map((v: { amount: number }) => v.amount), 1)

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <Card className="bg-gradient-to-br from-emerald-50 to-emerald-100 border-emerald-200">
          <CardContent className="p-3 text-center">
            <IndianRupee className="w-5 h-5 text-emerald-600 mx-auto mb-1" />
            <div className="text-xl font-bold text-emerald-700">₹{totalRevenue.toLocaleString('en-IN')}</div>
            <div className="text-xs text-emerald-600">Total Revenue</div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
          <CardContent className="p-3 text-center">
            <CreditCard className="w-5 h-5 text-blue-600 mx-auto mb-1" />
            <div className="text-xl font-bold text-blue-700">{monoStats.completedOrders}</div>
            <div className="text-xs text-blue-600">Total Orders</div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
          <CardContent className="p-3 text-center">
            <Crown className="w-5 h-5 text-purple-600 mx-auto mb-1" />
            <div className="text-xl font-bold text-purple-700">{monoStats.activeSubscriptions}</div>
            <div className="text-xs text-purple-600">Subscriptions</div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-amber-50 to-amber-100 border-amber-200">
          <CardContent className="p-3 text-center">
            <Rocket className="w-5 h-5 text-amber-600 mx-auto mb-1" />
            <div className="text-xl font-bold text-amber-700">{monoStats.activeBoosts}</div>
            <div className="text-xs text-amber-600">Active Boosts</div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
          <CardContent className="p-3 text-center">
            <ShieldCheck className="w-5 h-5 text-green-600 mx-auto mb-1" />
            <div className="text-xl font-bold text-green-700">{monoStats.verificationCount}</div>
            <div className="text-xs text-green-600">Verifications</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue by Type */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-emerald-600" /> Revenue by Type
            </CardTitle>
          </CardHeader>
          <CardContent>
            {Object.keys(revByType).length > 0 ? (
              <div className="space-y-4">
                {Object.entries(revByType).map(([type, data]) => {
                  const typedData = data as { amount: number; count: number }
                  const pct = (typedData.amount / maxTypeRevenue) * 100
                  return (
                    <div key={type}>
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-2">
                          <div className={`w-3 h-3 rounded-full ${orderTypeColors[type] || 'bg-gray-400'}`} />
                          <span className="text-sm font-medium">{orderTypeLabels[type] || type}</span>
                          <span className="text-xs text-gray-400">({typedData.count} orders)</span>
                        </div>
                        <span className="text-sm font-bold text-emerald-700">₹{typedData.amount.toLocaleString('en-IN')}</span>
                      </div>
                      <div className="bg-gray-100 rounded-full h-3">
                        <div
                          className={`${orderTypeColors[type] || 'bg-gray-400'} rounded-full h-3 transition-all duration-500`}
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  )
                })}
              </div>
            ) : (
              <p className="text-gray-400 text-sm">No revenue data</p>
            )}
          </CardContent>
        </Card>

        {/* Revenue Distribution Donut */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-600" /> Revenue Distribution
            </CardTitle>
          </CardHeader>
          <CardContent>
            {Object.keys(revByType).length > 0 ? (
              <div className="flex items-center gap-6">
                <SimpleDonutChart
                  segments={Object.entries(revByType).map(([type, data]) => ({
                    label: orderTypeLabels[type] || type,
                    value: (data as { amount: number }).amount,
                    color: orderTypeColors[type] || 'bg-gray-400',
                  }))}
                />
                <div className="space-y-2 flex-1">
                  {Object.entries(revByType).map(([type, data]) => {
                    const typedData = data as { amount: number; count: number }
                    const pct = totalRevenue > 0 ? Math.round((typedData.amount / totalRevenue) * 100) : 0
                    return (
                      <div key={type} className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full ${orderTypeColors[type] || 'bg-gray-400'}`} />
                          <span>{orderTypeLabels[type] || type}</span>
                        </div>
                        <span className="font-bold">{pct}%</span>
                      </div>
                    )
                  })}
                </div>
              </div>
            ) : (
              <p className="text-gray-400 text-sm">No data</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Orders */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-blue-600" /> Recent Monetization Orders
            </CardTitle>
            <Button variant="outline" size="sm" onClick={fetchMonoStats} className="gap-1">
              <RefreshCw className="w-3 h-3" /> Refresh
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {recentOrders.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Type</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>User</TableHead>
                    <TableHead>Property</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {(recentOrders as Record<string, unknown>[]).map((order, i) => {
                    const user = order.user as Record<string, string> | undefined
                    const prop = order.property as Record<string, string> | undefined
                    return (
                      <TableRow key={i}>
                        <TableCell>
                          <Badge className={`${orderTypeColors[String(order.orderType)] || 'bg-gray-400'} text-white text-[10px]`}>
                            {orderTypeLabels[String(order.orderType)] || String(order.orderType)}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-semibold text-emerald-700">
                          ₹{Number(order.amount || 0).toLocaleString('en-IN')}
                        </TableCell>
                        <TableCell className="text-xs">{user?.name || 'N/A'}</TableCell>
                        <TableCell className="text-xs truncate max-w-32">{prop?.title || '-'}</TableCell>
                        <TableCell>
                          <Badge className={statusColors[String(order.status)] || ''} variant="outline">
                            {String(order.status)}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs text-gray-500">
                          {new Date(String(order.createdAt)).toLocaleDateString('en-IN')}
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </div>
          ) : (
            <p className="text-gray-400 text-sm text-center py-4">No monetization orders yet</p>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

// ===== MAIN ADMIN PANEL =====
export default function AdminPanel() {
  const { currentUser, setCurrentView, setSelectedPropertyId } = useStore()
  const { toast } = useToast()

  const [stats, setStats] = useState<AdminStats | null>(null)
  const [analytics, setAnalytics] = useState<Analytics | null>(null)
  const [pendingProperties, setPendingProperties] = useState<Property[]>([])
  const [allProperties, setAllProperties] = useState<Property[]>([])
  const [users, setUsers] = useState<AdminUser[]>([])
  const [rentals, setRentals] = useState<Rental[]>([])
  const [payments, setPayments] = useState<unknown[]>([])
  const [reviews, setReviews] = useState<AdminReview[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('overview')
  const [searchQuery, setSearchQuery] = useState('')
  const [propertyFilter, setPropertyFilter] = useState('ALL')
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null)
  const [showPropertyDialog, setShowPropertyDialog] = useState(false)
  const [selectedProperties, setSelectedProperties] = useState<Set<string>>(new Set())
  const [bulkAction, setBulkAction] = useState('')

  const fetchAdminData = useCallback(async () => {
    setLoading(true)
    try {
      const [statsRes, dataRes, analyticsRes, reviewsRes] = await Promise.all([
        fetch('/api/admin'),
        fetch('/api/admin/properties'),
        fetch('/api/admin/analytics'),
        fetch('/api/admin/reviews'),
      ])

      const statsData = await statsRes.json()
      const adminData = await dataRes.json()
      const analyticsData = await analyticsRes.json()
      const reviewsData = await reviewsRes.json()

      if (statsRes.ok) setStats(statsData.stats)
      if (dataRes.ok) {
        setPendingProperties(adminData.properties?.filter((p: Property) => p.status === 'PENDING') || [])
        setAllProperties(adminData.properties || [])
        setUsers(adminData.users || [])
        setRentals(adminData.rentals || [])
        setPayments(adminData.payments || [])
      }
      if (analyticsRes.ok) setAnalytics(analyticsData.analytics)
      if (reviewsRes.ok) setReviews(reviewsData.reviews || [])
    } catch {
      toast({ title: 'Admin data load nahi hua', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }, [toast])

  useEffect(() => {
    if (currentUser?.role === 'ADMIN') {
      fetchAdminData()
    }
  }, [currentUser, fetchAdminData])

  // ===== ACCESS GUARD =====
  if (currentUser?.role !== 'ADMIN') {
    return (
      <div className="flex items-center justify-center min-h-[60vh] px-4">
        <Card className="p-8 text-center max-w-sm">
          <Shield className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-gray-700">Admin Access Chahiye</h2>
          <p className="text-gray-500 mt-2 text-sm">Admin panel dekhne ke liye admin account se login karein.</p>
          <Button onClick={() => setCurrentView('login')} className="mt-4 bg-emerald-600 hover:bg-emerald-700 text-white">
            Login karein
          </Button>
        </Card>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600 mx-auto mb-3" />
          <p className="text-gray-500 text-sm">Admin data load ho raha hai...</p>
        </div>
      </div>
    )
  }

  // ===== ACTION HANDLERS =====
  const handlePropertyAction = async (propertyId: string, status: string) => {
    try {
      const res = await fetch('/api/admin/properties', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ propertyId, status, role: currentUser?.role }),
      })
      if (res.ok) {
        toast({
          title: status === 'APPROVED' ? 'Property Approve ho gayi!' : 'Property Reject ho gayi',
          description: status === 'APPROVED' ? 'Ab yeh listing sab ko dikhegi' : 'Owner ko notification bhej diya gaya hai'
        })
        fetchAdminData()
      } else {
        toast({ title: 'Action fail ho gaya', variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Action fail ho gaya', variant: 'destructive' })
    }
  }

  const handleBulkAction = async () => {
    if (!bulkAction || selectedProperties.size === 0) return
    const action = bulkAction
    const ids = Array.from(selectedProperties)
    const status = action === 'approve' ? 'APPROVED' : action === 'reject' ? 'REJECTED' : null

    if (!status) {
      // Delete
      if (!confirm(`${ids.length} properties delete karein?`)) return
      for (const id of ids) {
        await fetch(`/api/properties/${id}?userId=${currentUser?.id}&role=ADMIN`, { method: 'DELETE' })
      }
      toast({ title: `${ids.length} properties delete ho gayi` })
    } else {
      for (const id of ids) {
        await handlePropertyAction(id, status)
      }
    }
    setSelectedProperties(new Set())
    setBulkAction('')
    fetchAdminData()
  }

  const handleDeleteProperty = async (propertyId: string) => {
    if (!confirm('Kya aap yeh property delete karna chahte hain? Yeh wapas nahi aayegi.')) return
    try {
      const res = await fetch(`/api/properties/${propertyId}?userId=${currentUser?.id}&role=ADMIN`, { method: 'DELETE' })
      if (res.ok) {
        toast({ title: 'Property delete ho gayi' })
        fetchAdminData()
      }
    } catch {
      toast({ title: 'Delete nahi ho payi', variant: 'destructive' })
    }
  }

  const handleUserAction = async (userId: string, action: string, extra?: Record<string, unknown>) => {
    try {
      const res = await fetch('/api/admin/users', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, action, ...extra }),
      })
      const data = await res.json()
      if (res.ok) {
        const actionLabels: Record<string, string> = {
          VERIFY_AADHAR: 'Aadhar Verify ho gaya',
          UNVERIFY_AADHAR: 'Aadhar Unverify ho gaya',
          CHANGE_ROLE: `Role change ho gaya - ${extra?.role || ''}`,
          DELETE: 'User delete ho gaya',
        }
        toast({ title: actionLabels[action] || 'Action successful' })
        fetchAdminData()
      } else {
        toast({ title: data.error || 'Action fail ho gaya', variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Action fail ho gaya', variant: 'destructive' })
    }
  }

  const handleRentalAction = async (rentalId: string, status: string) => {
    try {
      const res = await fetch(`/api/rentals/${rentalId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, role: 'ADMIN' }),
      })
      if (res.ok) {
        toast({ title: `Rental ${status} ho gaya` })
        fetchAdminData()
      }
    } catch {
      toast({ title: 'Action fail ho gaya', variant: 'destructive' })
    }
  }

  const handleDeleteReview = async (reviewId: string) => {
    if (!confirm('Yeh review delete karein?')) return
    try {
      const res = await fetch('/api/admin/reviews', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reviewId, action: 'DELETE' }),
      })
      if (res.ok) {
        toast({ title: 'Review delete ho gaya' })
        fetchAdminData()
      }
    } catch {
      toast({ title: 'Delete nahi hua', variant: 'destructive' })
    }
  }

  const togglePropertySelect = (id: string) => {
    const newSet = new Set(selectedProperties)
    if (newSet.has(id)) newSet.delete(id)
    else newSet.add(id)
    setSelectedProperties(newSet)
  }

  const selectAllProperties = () => {
    if (selectedProperties.size === filteredProperties.length) {
      setSelectedProperties(new Set())
    } else {
      setSelectedProperties(new Set(filteredProperties.map(p => p.id)))
    }
  }

  // ===== FILTERS =====
  const filteredProperties = allProperties.filter((p) => {
    const matchesSearch = !searchQuery ||
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.owner?.name?.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesFilter = propertyFilter === 'ALL' || p.status === propertyFilter
    return matchesSearch && matchesFilter
  })

  const filteredUsers = users.filter((u) => {
    return !searchQuery ||
      u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.phone.includes(searchQuery)
  })

  const openPropertyDetail = (property: Property) => {
    setSelectedProperty(property)
    setShowPropertyDialog(true)
  }

  const getPropertyImages = (images: string): string[] => {
    try { return JSON.parse(images) } catch { return [] }
  }

  // ===== EXPORT CSV =====
  const exportCSV = (data: Record<string, unknown>[], filename: string) => {
    if (data.length === 0) return
    const headers = Object.keys(data[0])
    const csv = [
      headers.join(','),
      ...data.map(row => headers.map(h => {
        const val = String(row[h] ?? '')
        return val.includes(',') ? `"${val}"` : val
      }).join(','))
    ].join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${filename}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  // ===== RENDER =====
  return (
    <div className="max-w-7xl mx-auto px-4 py-6 pb-24 md:pb-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Shield className="w-7 h-7 text-emerald-600" /> Admin Dashboard
          </h1>
          <p className="text-gray-500 text-sm mt-1">EasyRent ka poora control yahan hai</p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={fetchAdminData}
            variant="outline"
            size="sm"
            className="gap-1 border-emerald-200 text-emerald-700 hover:bg-emerald-50"
          >
            <RefreshCw className="w-4 h-4" /> Refresh
          </Button>
        </div>
      </div>

      {/* Stats Cards - Enhanced */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 mb-8">
        <Card className="bg-gradient-to-br from-emerald-50 to-emerald-100 border-emerald-200">
          <CardContent className="p-3 text-center">
            <Users className="w-5 h-5 text-emerald-600 mx-auto mb-1" />
            <div className="text-xl font-bold text-emerald-700">{stats?.totalUsers || 0}</div>
            <div className="text-xs text-emerald-600">Users</div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-teal-50 to-teal-100 border-teal-200">
          <CardContent className="p-3 text-center">
            <Building2 className="w-5 h-5 text-teal-600 mx-auto mb-1" />
            <div className="text-xl font-bold text-teal-700">{stats?.totalProperties || 0}</div>
            <div className="text-xs text-teal-600">Properties</div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-amber-50 to-amber-100 border-amber-200">
          <CardContent className="p-3 text-center">
            <Clock className="w-5 h-5 text-amber-600 mx-auto mb-1" />
            <div className="text-xl font-bold text-amber-700">{stats?.pendingProperties || 0}</div>
            <div className="text-xs text-amber-600">Pending</div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
          <CardContent className="p-3 text-center">
            <CheckCircle2 className="w-5 h-5 text-green-600 mx-auto mb-1" />
            <div className="text-xl font-bold text-green-700">{stats?.approvedProperties || 0}</div>
            <div className="text-xs text-green-600">Approved</div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-red-50 to-red-100 border-red-200">
          <CardContent className="p-3 text-center">
            <XCircle className="w-5 h-5 text-red-600 mx-auto mb-1" />
            <div className="text-xl font-bold text-red-700">{stats?.rejectedProperties || 0}</div>
            <div className="text-xs text-red-600">Rejected</div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
          <CardContent className="p-3 text-center">
            <CalendarRange className="w-5 h-5 text-blue-600 mx-auto mb-1" />
            <div className="text-xl font-bold text-blue-700">{stats?.activeRentals || 0}</div>
            <div className="text-xs text-blue-600">Rentals</div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
          <CardContent className="p-3 text-center">
            <IndianRupee className="w-5 h-5 text-purple-600 mx-auto mb-1" />
            <div className="text-xl font-bold text-purple-700">{((stats?.revenue || 0) / 1000).toFixed(1)}K</div>
            <div className="text-xs text-purple-600">Revenue</div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-indigo-50 to-indigo-100 border-indigo-200">
          <CardContent className="p-3 text-center">
            <Star className="w-5 h-5 text-indigo-600 mx-auto mb-1" />
            <div className="text-xl font-bold text-indigo-700">{reviews.length}</div>
            <div className="text-xs text-indigo-600">Reviews</div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs - Enhanced with 8 tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <div className="overflow-x-auto">
          <TabsList className="grid w-full grid-cols-8 min-w-[800px]">
            <TabsTrigger value="overview" className="text-xs sm:text-sm gap-1">
              <BarChart3 className="w-4 h-4 hidden sm:block" /> Overview
            </TabsTrigger>
            <TabsTrigger value="pending" className="text-xs sm:text-sm">
              Pending ({pendingProperties.length})
            </TabsTrigger>
            <TabsTrigger value="properties" className="text-xs sm:text-sm">
              Properties
            </TabsTrigger>
            <TabsTrigger value="users" className="text-xs sm:text-sm">
              Users ({users.length})
            </TabsTrigger>
            <TabsTrigger value="rentals" className="text-xs sm:text-sm">
              Rentals
            </TabsTrigger>
            <TabsTrigger value="reviews" className="text-xs sm:text-sm">
              Reviews
            </TabsTrigger>
            <TabsTrigger value="monetization" className="text-xs sm:text-sm gap-1">
              <Crown className="w-4 h-4 hidden sm:block" /> Monetization
            </TabsTrigger>
            <TabsTrigger value="payments" className="text-xs sm:text-sm">
              Payments
            </TabsTrigger>
          </TabsList>
        </div>

        {/* ===== OVERVIEW / ANALYTICS TAB ===== */}
        <TabsContent value="overview" className="mt-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Property Types Distribution */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-semibold flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-emerald-600" /> Property Types
                </CardTitle>
              </CardHeader>
              <CardContent>
                {analytics ? (
                  <div className="flex items-center gap-4">
                    <SimpleDonutChart
                      segments={Object.entries(analytics.typeDistribution).map(([type, count]) => ({
                        label: typeLabels[type] || type,
                        value: count,
                        color: typeColors[type] || 'bg-gray-400',
                      }))}
                    />
                    <div className="space-y-2 flex-1">
                      {Object.entries(analytics.typeDistribution).map(([type, count]) => {
                        const Icon = typeIcons[type] || Building2
                        const total = Object.values(analytics.typeDistribution).reduce((a, b) => a + b, 0)
                        const pct = total > 0 ? Math.round((count / total) * 100) : 0
                        return (
                          <div key={type} className="flex items-center gap-2">
                            <Icon className="w-4 h-4 text-gray-500" />
                            <span className="text-xs font-medium w-12">{typeLabels[type]}</span>
                            <div className="flex-1 bg-gray-100 rounded-full h-2">
                              <div
                                className={`${typeColors[type]} rounded-full h-2 transition-all duration-500`}
                                style={{ width: `${pct}%` }}
                              />
                            </div>
                            <span className="text-xs text-gray-600 w-8 text-right">{count}</span>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                ) : (
                  <p className="text-gray-400 text-sm">No analytics data</p>
                )}
              </CardContent>
            </Card>

            {/* Top Cities */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-semibold flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-blue-600" /> Top Cities
                </CardTitle>
              </CardHeader>
              <CardContent>
                {analytics && analytics.cityDistribution.length > 0 ? (
                  <div className="space-y-3">
                    {analytics.cityDistribution.map((city, i) => {
                      const maxCount = analytics.cityDistribution[0]?.count || 1
                      return (
                        <div key={city.city} className="flex items-center gap-2">
                          <span className="text-xs font-bold text-gray-400 w-5">#{i + 1}</span>
                          <span className="text-xs font-medium w-20 truncate">{city.city}</span>
                          <div className="flex-1 bg-gray-100 rounded-full h-3">
                            <div
                              className="bg-blue-500 rounded-full h-3 transition-all duration-500"
                              style={{ width: `${(city.count / maxCount) * 100}%` }}
                            />
                          </div>
                          <span className="text-xs font-bold text-gray-600 w-6 text-right">{city.count}</span>
                        </div>
                      )
                    })}
                  </div>
                ) : (
                  <p className="text-gray-400 text-sm">No city data</p>
                )}
              </CardContent>
            </Card>

            {/* Average Rent by Type */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-semibold flex items-center gap-2">
                  <IndianRupee className="w-4 h-4 text-purple-600" /> Avg Rent by Type
                </CardTitle>
              </CardHeader>
              <CardContent>
                {analytics && Object.keys(analytics.avgRentByType).length > 0 ? (
                  <div className="space-y-3">
                    {Object.entries(analytics.avgRentByType).map(([type, avg]) => {
                      const Icon = typeIcons[type] || Building2
                      const maxAvg = Math.max(...Object.values(analytics.avgRentByType))
                      return (
                        <div key={type} className="flex items-center gap-2">
                          <Icon className="w-4 h-4 text-gray-500" />
                          <span className="text-xs font-medium w-12">{typeLabels[type]}</span>
                          <div className="flex-1 bg-gray-100 rounded-full h-3">
                            <div
                              className="bg-purple-500 rounded-full h-3 transition-all duration-500"
                              style={{ width: `${(avg / maxAvg) * 100}%` }}
                            />
                          </div>
                          <span className="text-xs font-bold text-gray-600">{avg.toLocaleString('en-IN')}</span>
                        </div>
                      )
                    })}
                  </div>
                ) : (
                  <p className="text-gray-400 text-sm">No rent data</p>
                )}
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card className="lg:col-span-2">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-semibold flex items-center gap-2">
                  <Activity className="w-4 h-4 text-amber-600" /> Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent>
                {analytics && analytics.activity.length > 0 ? (
                  <div className="divide-y divide-gray-100 max-h-64 overflow-y-auto">
                    {analytics.activity.map((item, i) => (
                      <ActivityItem key={i} item={item} />
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-400 text-sm">No recent activity</p>
                )}
              </CardContent>
            </Card>

            {/* Status Overview */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-semibold flex items-center gap-2">
                  <Shield className="w-4 h-4 text-emerald-600" /> Status Overview
                </CardTitle>
              </CardHeader>
              <CardContent>
                {analytics ? (
                  <div className="space-y-4">
                    {/* Property Status */}
                    <div>
                      <p className="text-xs font-medium text-gray-500 mb-2">Property Status</p>
                      <div className="space-y-2">
                        {Object.entries(analytics.statusDistribution).map(([status, count]) => (
                          <div key={status} className="flex items-center justify-between">
                            <Badge className={statusColors[status] || ''} variant="outline">{status}</Badge>
                            <span className="text-sm font-bold">{count}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    {/* User Stats */}
                    <div className="pt-2 border-t">
                      <p className="text-xs font-medium text-gray-500 mb-2">User Stats</p>
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-gray-600">Total Users</span>
                          <span className="font-bold">{analytics.userStats.total}</span>
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-gray-600">Aadhar Verified</span>
                          <span className="font-bold text-emerald-600">{analytics.userStats.verified}</span>
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-gray-600">Admins</span>
                          <span className="font-bold text-purple-600">{analytics.userStats.admins}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <p className="text-gray-400 text-sm">No data</p>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* ===== PENDING PROPERTIES TAB ===== */}
        <TabsContent value="pending" className="mt-4">
          {pendingProperties.length === 0 ? (
            <Card className="p-8 text-center">
              <CheckCircle2 className="w-16 h-16 text-emerald-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-700">Sab theek hai!</h3>
              <p className="text-gray-500 text-sm mt-1">Koi pending property nahi hai approval ke liye</p>
            </Card>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-amber-500" />
                  <span className="text-sm font-medium text-amber-700">
                    {pendingProperties.length} properties approval ka wait kar rahi hain
                  </span>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    className="bg-emerald-600 hover:bg-emerald-700 text-white"
                    onClick={async () => {
                      if (!confirm(`Sabhi ${pendingProperties.length} properties approve karein?`)) return
                      for (const p of pendingProperties) {
                        await handlePropertyAction(p.id, 'APPROVED')
                      }
                    }}
                  >
                    <CheckCircle2 className="w-4 h-4 mr-1" /> Approve All
                  </Button>
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={async () => {
                      if (!confirm(`Sabhi ${pendingProperties.length} properties reject karein?`)) return
                      for (const p of pendingProperties) {
                        await handlePropertyAction(p.id, 'REJECTED')
                      }
                    }}
                  >
                    <XCircle className="w-4 h-4 mr-1" /> Reject All
                  </Button>
                </div>
              </div>
              {pendingProperties.map((p) => {
                const images = getPropertyImages(p.images)
                return (
                  <Card key={p.id} className="border-amber-200 hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex flex-col sm:flex-row gap-4">
                        {/* Property Image */}
                        <div className="w-full sm:w-40 h-28 rounded-lg overflow-hidden bg-gray-100 flex-shrink-0">
                          {images.length > 0 ? (
                            <img src={images[0]} alt={p.title} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-gray-400">
                              <ImageIcon className="w-8 h-8" />
                            </div>
                          )}
                        </div>

                        {/* Property Info */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <h3 className="font-semibold text-gray-900 truncate">{p.title}</h3>
                              <p className="text-sm text-gray-500 mt-0.5">{p.address}, {p.city}, {p.state}</p>
                            </div>
                            <Badge className={statusColors[p.status] || ''}>{p.status}</Badge>
                          </div>

                          <div className="flex flex-wrap gap-3 mt-2 text-sm">
                            <span className="text-emerald-700 font-semibold">₹{p.rent.toLocaleString('en-IN')}/mo</span>
                            <span className="text-gray-500">Deposit: ₹{p.deposit.toLocaleString('en-IN')}</span>
                            <Badge variant="outline" className="text-xs">{typeLabels[p.type] || p.type}</Badge>
                          </div>

                          {p.description && (
                            <p className="text-xs text-gray-500 mt-1 line-clamp-2">{p.description}</p>
                          )}

                          <div className="flex items-center gap-3 mt-2 text-xs text-gray-400">
                            <span>Owner: {p.owner?.name || 'Unknown'}</span>
                            <span>Ph: {p.owner?.phone || 'N/A'}</span>
                            <span>{p.owner?.email || 'N/A'}</span>
                          </div>

                          {p.availableTo && (
                            <div className="text-xs text-blue-500 mt-1">
                              Available: {p.availableFrom} to {p.availableTo}
                            </div>
                          )}

                          {images.length > 1 && (
                            <p className="text-xs text-gray-400 mt-1">{images.length} photos {p.video ? '| Video attached' : ''}</p>
                          )}
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex flex-wrap gap-2 mt-4 pt-3 border-t">
                        <Button
                          size="sm"
                          onClick={() => handlePropertyAction(p.id, 'APPROVED')}
                          className="bg-emerald-600 hover:bg-emerald-700 text-white"
                        >
                          <CheckCircle2 className="w-4 h-4 mr-1" /> Approve
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handlePropertyAction(p.id, 'REJECTED')}
                        >
                          <XCircle className="w-4 h-4 mr-1" /> Reject
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => openPropertyDetail(p)}
                        >
                          <Eye className="w-4 h-4 mr-1" /> Detail
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-red-500 hover:text-red-600"
                          onClick={() => handleDeleteProperty(p.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          )}
        </TabsContent>

        {/* ===== ALL PROPERTIES TAB ===== */}
        <TabsContent value="properties" className="mt-4">
          {/* Filters & Bulk Actions */}
          <div className="flex flex-col sm:flex-row gap-3 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search by title, city, owner..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={propertyFilter} onValueChange={setPropertyFilter}>
              <SelectTrigger className="w-36">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Status</SelectItem>
                <SelectItem value="PENDING">Pending</SelectItem>
                <SelectItem value="APPROVED">Approved</SelectItem>
                <SelectItem value="REJECTED">Rejected</SelectItem>
              </SelectContent>
            </Select>
            <Button
              variant="outline"
              size="sm"
              onClick={() => exportCSV(
                filteredProperties.map(p => ({
                  title: p.title,
                  type: p.type,
                  city: p.city,
                  state: p.state,
                  rent: p.rent,
                  deposit: p.deposit,
                  status: p.status,
                  owner: p.owner?.name || '',
                  date: new Date(p.createdAt).toLocaleDateString('en-IN'),
                })),
                'easyrent-properties'
              )}
              className="gap-1"
            >
              <Download className="w-4 h-4" /> CSV
            </Button>
          </div>

          {/* Bulk Actions Bar */}
          {selectedProperties.size > 0 && (
            <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 mb-4 flex items-center gap-3 flex-wrap">
              <span className="text-sm font-medium text-emerald-700">
                {selectedProperties.size} selected
              </span>
              <Button size="sm" onClick={() => { setBulkAction('approve'); handleBulkAction() }} className="bg-emerald-600 hover:bg-emerald-700 text-white h-7">
                <CheckCircle2 className="w-3 h-3 mr-1" /> Approve
              </Button>
              <Button size="sm" variant="destructive" onClick={() => { setBulkAction('reject'); handleBulkAction() }} className="h-7">
                <XCircle className="w-3 h-3 mr-1" /> Reject
              </Button>
              <Button size="sm" variant="outline" onClick={() => { setBulkAction('delete'); handleBulkAction() }} className="text-red-600 border-red-200 h-7">
                <Trash2 className="w-3 h-3 mr-1" /> Delete
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setSelectedProperties(new Set())} className="h-7">
                Clear
              </Button>
            </div>
          )}

          <div className="space-y-3 max-h-[600px] overflow-y-auto">
            {/* Select All Checkbox */}
            <div className="flex items-center gap-2 px-1">
              <Checkbox
                checked={selectedProperties.size === filteredProperties.length && filteredProperties.length > 0}
                onCheckedChange={selectAllProperties}
              />
              <span className="text-xs text-gray-500">Select All ({filteredProperties.length})</span>
            </div>

            {filteredProperties.length === 0 ? (
              <Card className="p-8 text-center text-gray-500">
                <Building2 className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p>Koi property nahi mili</p>
              </Card>
            ) : (
              filteredProperties.map((p) => {
                const images = getPropertyImages(p.images)
                return (
                  <Card key={p.id} className={`hover:shadow-sm transition-shadow ${selectedProperties.has(p.id) ? 'ring-2 ring-emerald-400' : ''}`}>
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <Checkbox
                          checked={selectedProperties.has(p.id)}
                          onCheckedChange={() => togglePropertySelect(p.id)}
                          className="mt-1"
                        />
                        <div className="w-16 h-12 rounded-lg overflow-hidden bg-gray-100 flex-shrink-0">
                          {images.length > 0 ? (
                            <img src={images[0]} alt="" className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              <Home className="w-5 h-5 text-gray-400" />
                            </div>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold truncate">{p.title}</h3>
                            <Badge className={statusColors[p.status] || ''} variant="outline">
                              {p.status}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-500">{p.city}, {p.state} | ₹{p.rent.toLocaleString('en-IN')}/mo | {typeLabels[p.type] || p.type}</p>
                          <p className="text-xs text-gray-400">Owner: {p.owner?.name} | {new Date(p.createdAt).toLocaleDateString('en-IN')}</p>
                        </div>
                        <div className="flex gap-1 flex-shrink-0">
                          {p.status !== 'APPROVED' && (
                            <Button size="sm" variant="ghost" onClick={() => handlePropertyAction(p.id, 'APPROVED')} className="text-emerald-600">
                              <CheckCircle2 className="w-4 h-4" />
                            </Button>
                          )}
                          {p.status !== 'REJECTED' && p.status !== 'APPROVED' && (
                            <Button size="sm" variant="ghost" onClick={() => handlePropertyAction(p.id, 'REJECTED')} className="text-red-500">
                              <XCircle className="w-4 h-4" />
                            </Button>
                          )}
                          <Button size="sm" variant="ghost" onClick={() => { setSelectedPropertyId(p.id); setCurrentView('detail') }}>
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button size="sm" variant="ghost" className="text-red-500" onClick={() => handleDeleteProperty(p.id)}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )
              })
            )}
          </div>
        </TabsContent>

        {/* ===== USERS TAB ===== */}
        <TabsContent value="users" className="mt-4">
          <div className="flex gap-3 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search by name, email, phone..."
                value={activeTab === 'users' ? searchQuery : ''}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => exportCSV(
                filteredUsers.map(u => ({
                  name: u.name,
                  email: u.email,
                  phone: u.phone,
                  aadharVerified: u.aadharVerified ? 'Yes' : 'No',
                  role: u.role,
                  properties: u._count?.properties || 0,
                  joined: new Date(u.createdAt).toLocaleDateString('en-IN'),
                })),
                'easyrent-users'
              )}
              className="gap-1"
            >
              <Download className="w-4 h-4" /> CSV
            </Button>
          </div>

          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead>Aadhar</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Properties</TableHead>
                  <TableHead>Joined</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.map((u) => (
                  <TableRow key={u.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 font-bold text-sm">
                          {u.name.charAt(0)}
                        </div>
                        <div>
                          <div className="font-medium text-sm">{u.name}</div>
                          <div className="text-xs text-gray-500">{u.email}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm">{u.phone}</TableCell>
                    <TableCell>
                      {u.aadharNo ? (
                        <div className="flex items-center gap-1">
                          <CreditCard className="w-3 h-3" />
                          <span className="text-xs">{u.aadharNo.slice(0, 4)}****{u.aadharNo.slice(-4)}</span>
                          {u.aadharVerified ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          ) : (
                            <Clock className="w-4 h-4 text-amber-500" />
                          )}
                        </div>
                      ) : (
                        <span className="text-gray-400 text-xs">N/A</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge variant={u.role === 'ADMIN' ? 'default' : 'secondary'}>
                        {u.role === 'ADMIN' && <Crown className="w-3 h-3 mr-1" />}
                        {u.role}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm">{u._count?.properties || 0}</TableCell>
                    <TableCell className="text-xs text-gray-500">
                      {new Date(u.createdAt).toLocaleDateString('en-IN')}
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        {u.aadharNo && !u.aadharVerified && (
                          <Button size="sm" variant="ghost" className="text-emerald-600 h-7 w-7 p-0" onClick={() => handleUserAction(u.id, 'VERIFY_AADHAR')} title="Verify Aadhar">
                            <UserCheck className="w-4 h-4" />
                          </Button>
                        )}
                        {u.aadharNo && u.aadharVerified && (
                          <Button size="sm" variant="ghost" className="text-amber-500 h-7 w-7 p-0" onClick={() => handleUserAction(u.id, 'UNVERIFY_AADHAR')} title="Unverify Aadhar">
                            <UserX className="w-4 h-4" />
                          </Button>
                        )}
                        {u.role !== 'ADMIN' ? (
                          <Button size="sm" variant="ghost" className="text-purple-600 h-7 w-7 p-0" onClick={() => handleUserAction(u.id, 'CHANGE_ROLE', { role: 'ADMIN' })} title="Make Admin">
                            <Crown className="w-4 h-4" />
                          </Button>
                        ) : u.id !== currentUser?.id ? (
                          <Button size="sm" variant="ghost" className="text-gray-500 h-7 w-7 p-0" onClick={() => handleUserAction(u.id, 'CHANGE_ROLE', { role: 'USER' })} title="Remove Admin">
                            <Users className="w-4 h-4" />
                          </Button>
                        ) : null}
                        {u.id !== currentUser?.id && (
                          <Button size="sm" variant="ghost" className="text-red-500 h-7 w-7 p-0" onClick={() => { if (confirm(`${u.name} ko delete karein?`)) handleUserAction(u.id, 'DELETE') }} title="Delete User">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        {/* ===== RENTALS TAB ===== */}
        <TabsContent value="rentals" className="mt-4">
          {rentals.length === 0 ? (
            <Card className="p-8 text-center">
              <CalendarRange className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">Abhi koi rental nahi hai</p>
            </Card>
          ) : (
            <div className="space-y-3 max-h-[600px] overflow-y-auto">
              {rentals.map((r) => (
                <Card key={r.id} className="hover:shadow-sm transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold truncate">
                            {((r as Record<string, unknown>).property as Record<string, unknown>)?.title as string || 'Property'}
                          </h3>
                          <Badge className={statusColors[r.status] || ''} variant="outline">
                            {r.status}
                          </Badge>
                        </div>
                        <div className="text-sm text-gray-500 mt-1">
                          <span className="flex items-center gap-1">
                            <Users className="w-3.5 h-3.5" />
                            Tenant: {(((r as Record<string, unknown>).tenant as Record<string, unknown>)?.name as string) || 'N/A'}
                          </span>
                        </div>
                        <div className="flex items-center gap-3 mt-1 text-sm">
                          <span className="flex items-center gap-1 text-gray-500">
                            <CalendarRange className="w-3.5 h-3.5" />
                            {r.startDate} to {r.endDate}
                          </span>
                        </div>
                      </div>

                      <div className="flex gap-1 flex-shrink-0">
                        {r.status === 'PENDING' && (
                          <>
                            <Button size="sm" onClick={() => handleRentalAction(r.id, 'ACTIVE')} className="bg-emerald-600 hover:bg-emerald-700 text-white h-7 text-xs">
                              <CheckCircle2 className="w-3 h-3 mr-1" /> Approve
                            </Button>
                            <Button size="sm" variant="destructive" onClick={() => handleRentalAction(r.id, 'CANCELLED')} className="h-7 text-xs">
                              <XCircle className="w-3 h-3 mr-1" /> Reject
                            </Button>
                          </>
                        )}
                        {r.status === 'ACTIVE' && (
                          <Button size="sm" variant="outline" onClick={() => handleRentalAction(r.id, 'COMPLETED')} className="h-7 text-xs">
                            Mark Complete
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* ===== REVIEWS TAB ===== */}
        <TabsContent value="reviews" className="mt-4">
          {reviews.length === 0 ? (
            <Card className="p-8 text-center">
              <MessageSquare className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">Abhi koi review nahi hai</p>
            </Card>
          ) : (
            <div className="space-y-3 max-h-[600px] overflow-y-auto">
              {reviews.map((r) => (
                <Card key={r.id} className="hover:shadow-sm transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <div className="flex">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star
                                key={star}
                                className={`w-4 h-4 ${star <= r.rating ? 'fill-amber-400 text-amber-400' : 'text-gray-200'}`}
                              />
                            ))}
                          </div>
                          <span className="text-xs text-gray-400">{new Date(r.createdAt).toLocaleDateString('en-IN')}</span>
                        </div>
                        <p className="text-sm text-gray-700">{r.comment}</p>
                        <div className="flex items-center gap-2 mt-2 text-xs text-gray-400">
                          <span>By: {r.user.name}</span>
                          <span>|</span>
                          <span>Property: {r.property.title} ({r.property.city})</span>
                          <Badge className={statusColors[r.property.status] || ''} variant="outline">
                            {r.property.status}
                          </Badge>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-red-500 hover:text-red-600 flex-shrink-0 h-7 w-7 p-0"
                        onClick={() => handleDeleteReview(r.id)}
                        title="Delete Review"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* ===== MONETIZATION TAB ===== */}
        <TabsContent value="monetization" className="mt-4">
          <MonetizationTab />
        </TabsContent>

        <TabsContent value="payments" className="mt-4">
          {(payments as Record<string, unknown>[]).length === 0 ? (
            <Card className="p-8 text-center">
              <IndianRupee className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">Abhi koi payment nahi hai</p>
            </Card>
          ) : (
            <div>
              <div className="flex justify-end mb-3">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => exportCSV(
                    (payments as Record<string, unknown>[]).map(p => ({
                      rentalId: String(p.rentalId || '').slice(-8),
                      amount: Number(p.amount || 0),
                      upiId: String(p.upiId || ''),
                      status: String(p.status || ''),
                      transactionId: String(p.transactionId || ''),
                      date: new Date(String(p.createdAt)).toLocaleDateString('en-IN'),
                    })),
                    'easyrent-payments'
                  )}
                  className="gap-1"
                >
                  <Download className="w-4 h-4" /> Export CSV
                </Button>
              </div>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Rental ID</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>UPI ID</TableHead>
                      <TableHead>Transaction ID</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Date</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {(payments as Record<string, unknown>[]).map((p, i) => (
                      <TableRow key={i}>
                        <TableCell className="text-sm font-mono">{String(p.rentalId || '').slice(-8)}</TableCell>
                        <TableCell className="font-semibold text-emerald-700">₹{Number(p.amount || 0).toLocaleString('en-IN')}</TableCell>
                        <TableCell className="text-sm">{String(p.upiId || 'N/A')}</TableCell>
                        <TableCell className="text-sm font-mono">{String(p.transactionId || '-')}</TableCell>
                        <TableCell>
                          <Badge className={statusColors[String(p.status)] || ''} variant="outline">
                            {String(p.status)}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs text-gray-500">
                          {new Date(String(p.createdAt)).toLocaleDateString('en-IN')}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Property Detail Dialog */}
      <Dialog open={showPropertyDialog} onOpenChange={setShowPropertyDialog}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{selectedProperty?.title}</DialogTitle>
          </DialogHeader>
          {selectedProperty && (
            <div className="space-y-4">
              {/* Images */}
              {(() => {
                const imgs = getPropertyImages(selectedProperty.images)
                return imgs.length > 0 ? (
                  <div className="grid grid-cols-3 gap-2">
                    {imgs.slice(0, 6).map((img: string, i: number) => (
                      <div key={i} className="aspect-square rounded-lg overflow-hidden bg-gray-100">
                        <img src={img} alt="" className="w-full h-full object-cover" />
                      </div>
                    ))}
                  </div>
                ) : <p className="text-gray-500 text-sm">No photos</p>
              })()}

              {/* Video */}
              {selectedProperty.video && (
                <div className="bg-gray-900 rounded-lg overflow-hidden aspect-video">
                  <video src={selectedProperty.video} controls className="w-full h-full" />
                </div>
              )}

              {/* Details */}
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div><span className="text-gray-500">Type:</span> <span className="font-medium">{typeLabels[selectedProperty.type]}</span></div>
                <div><span className="text-gray-500">Rent:</span> <span className="font-medium text-emerald-700">₹{selectedProperty.rent.toLocaleString('en-IN')}/mo</span></div>
                <div><span className="text-gray-500">Deposit:</span> <span className="font-medium">₹{selectedProperty.deposit.toLocaleString('en-IN')}</span></div>
                <div><span className="text-gray-500">City:</span> <span className="font-medium">{selectedProperty.city}, {selectedProperty.state}</span></div>
                <div><span className="text-gray-500">Available:</span> <span className="font-medium">{selectedProperty.availableFrom} {selectedProperty.availableTo ? `to ${selectedProperty.availableTo}` : 'onwards'}</span></div>
                <div><span className="text-gray-500">Status:</span> <Badge className={statusColors[selectedProperty.status]} variant="outline">{selectedProperty.status}</Badge></div>
                <div><span className="text-gray-500">Owner:</span> <span className="font-medium">{selectedProperty.owner?.name}</span></div>
                <div><span className="text-gray-500">Phone:</span> <span className="font-medium">{selectedProperty.owner?.phone}</span></div>
              </div>

              {selectedProperty.description && (
                <div>
                  <p className="text-gray-500 text-sm mb-1">Description:</p>
                  <p className="text-sm text-gray-700">{selectedProperty.description}</p>
                </div>
              )}

              {/* Map Link */}
              {selectedProperty.lat && selectedProperty.lng && (
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-emerald-600" />
                  <a
                    href={`https://www.google.com/maps?q=${selectedProperty.lat},${selectedProperty.lng}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-emerald-600 hover:underline"
                  >
                    View on Google Maps
                  </a>
                </div>
              )}

              {/* Dialog Actions */}
              <div className="flex gap-2 pt-2 border-t">
                <Button
                  onClick={() => { handlePropertyAction(selectedProperty.id, 'APPROVED'); setShowPropertyDialog(false) }}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white flex-1"
                >
                  <CheckCircle2 className="w-4 h-4 mr-1" /> Approve
                </Button>
                <Button
                  variant="destructive"
                  onClick={() => { handlePropertyAction(selectedProperty.id, 'REJECTED'); setShowPropertyDialog(false) }}
                  className="flex-1"
                >
                  <XCircle className="w-4 h-4 mr-1" /> Reject
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
