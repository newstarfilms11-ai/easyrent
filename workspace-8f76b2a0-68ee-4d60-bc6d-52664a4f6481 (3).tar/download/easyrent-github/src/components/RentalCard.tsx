'use client'

import { Rental } from './store'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Calendar, IndianRupee, Home, User, CheckCircle2, XCircle, Clock, AlertCircle } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

const statusConfig: Record<string, { color: string; icon: React.ElementType; label: string }> = {
  PENDING: { color: 'bg-amber-100 text-amber-700', icon: Clock, label: 'Pending' },
  ACTIVE: { color: 'bg-emerald-100 text-emerald-700', icon: CheckCircle2, label: 'Active' },
  COMPLETED: { color: 'bg-gray-100 text-gray-700', icon: CheckCircle2, label: 'Completed' },
  CANCELLED: { color: 'bg-red-100 text-red-700', icon: XCircle, label: 'Cancelled' },
}

interface RentalCardProps {
  rental: Rental
  isOwner?: boolean
  onStatusUpdate?: (rentalId: string, status: string) => void
}

export default function RentalCard({ rental, isOwner, onStatusUpdate }: RentalCardProps) {
  const { toast } = useToast()
  const config = statusConfig[rental.status] || statusConfig.PENDING
  const StatusIcon = config.icon

  const handleStatusChange = async (status: string) => {
    try {
      const res = await fetch(`/api/rentals/${rental.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      })

      if (res.ok) {
        toast({ title: `Rental ${status.toLowerCase()}` })
        onStatusUpdate?.(rental.id, status)
      } else {
        toast({ title: 'Failed to update', variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Error updating rental', variant: 'destructive' })
    }
  }

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-gray-900 truncate">
              {rental.property?.title || 'Property'}
            </h3>
            <div className="flex items-center gap-2 text-sm text-gray-500 mt-1">
              <Home className="w-3.5 h-3.5" />
              <span>{rental.property?.city || 'N/A'}</span>
            </div>

            {isOwner && rental.tenant && (
              <div className="flex items-center gap-2 text-sm text-gray-500 mt-1">
                <User className="w-3.5 h-3.5" />
                <span>Tenant: {rental.tenant.name}</span>
              </div>
            )}

            <div className="flex items-center gap-4 mt-2 text-sm">
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                {rental.startDate} → {rental.endDate}
              </span>
              {rental.property?.rent && (
                <span className="flex items-center gap-1 text-emerald-700 font-medium">
                  <IndianRupee className="w-3.5 h-3.5" />
                  {rental.property.rent.toLocaleString('en-IN')}/mo
                </span>
              )}
            </div>
          </div>

          <Badge className={`${config.color} flex items-center gap-1`}>
            <StatusIcon className="w-3 h-3" />
            {config.label}
          </Badge>
        </div>

        {/* Actions */}
        {isOwner && rental.status === 'PENDING' && (
          <div className="flex gap-2 mt-3 pt-3 border-t">
            <Button
              size="sm"
              onClick={() => handleStatusChange('ACTIVE')}
              className="bg-emerald-600 hover:bg-emerald-700 text-white"
            >
              <CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Approve
            </Button>
            <Button
              size="sm"
              variant="destructive"
              onClick={() => handleStatusChange('CANCELLED')}
            >
              <XCircle className="w-3.5 h-3.5 mr-1" /> Reject
            </Button>
          </div>
        )}

        {!isOwner && rental.status === 'ACTIVE' && (
          <div className="flex gap-2 mt-3 pt-3 border-t">
            <Button
              size="sm"
              variant="outline"
              onClick={() => handleStatusChange('COMPLETED')}
            >
              Mark Completed
            </Button>
            <Button
              size="sm"
              variant="ghost"
              className="text-red-600 hover:text-red-700"
              onClick={() => handleStatusChange('CANCELLED')}
            >
              Cancel Rental
            </Button>
          </div>
        )}

        {!rental.paymentId && rental.status === 'PENDING' && (
          <div className="mt-3 pt-3 border-t">
            <p className="text-xs text-amber-600 flex items-center gap-1">
              <AlertCircle className="w-3.5 h-3.5" /> Payment pending
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
