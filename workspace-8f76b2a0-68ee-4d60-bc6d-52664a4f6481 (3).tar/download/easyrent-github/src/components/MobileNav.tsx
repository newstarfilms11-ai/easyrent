'use client'

import { useStore, ViewType } from './store'
import { Home, Building2, Plus, CalendarRange, User, CreditCard } from 'lucide-react'

const navItems: { view: ViewType; label: string; icon: React.ElementType }[] = [
  { view: 'home', label: 'Home', icon: Home },
  { view: 'listings', label: 'Listings', icon: Building2 },
  { view: 'add-property', label: 'Post Ad', icon: Plus },
  { view: 'my-rentals', label: 'Rentals', icon: CalendarRange },
  { view: 'dashboard', label: 'Profile', icon: User },
]

export default function MobileNav() {
  const { currentView, setCurrentView, currentUser } = useStore()

  const handleClick = (view: ViewType) => {
    if ((view === 'add-property' || view === 'my-rentals' || view === 'dashboard') && !currentUser) {
      setCurrentView('login')
      return
    }
    setCurrentView(view)
  }

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-200 md:hidden safe-area-bottom">
      <div className="flex items-end justify-around h-16 px-2">
        {navItems.map((item) => {
          const isActive = currentView === item.view
          const Icon = item.icon
          const isPostAd = item.view === 'add-property'

          return (
            <button
              key={item.view}
              onClick={() => handleClick(item.view)}
              className={`flex flex-col items-center justify-center gap-0.5 py-1 px-2 transition-colors relative ${
                isActive && !isPostAd
                  ? 'text-emerald-600'
                  : !isPostAd
                  ? 'text-gray-400 hover:text-gray-600'
                  : ''
              }`}
            >
              {isPostAd ? (
                /* Big attractive Post Ad button with glow effect */
                <div className="absolute -top-6 left-1/2 -translate-x-1/2">
                  <div
                    className={`w-16 h-16 rounded-full flex items-center justify-center shadow-xl transition-all duration-200 ${
                      isActive
                        ? 'bg-emerald-700 shadow-emerald-400 scale-110'
                        : 'bg-gradient-to-br from-emerald-400 via-emerald-500 to-teal-600 hover:scale-110 hover:shadow-emerald-300'
                    }`}
                    style={!isActive ? { boxShadow: '0 0 20px rgba(16, 185, 129, 0.4), 0 4px 12px rgba(0,0,0,0.15)' } : {}}
                  >
                    <Plus className="w-8 h-8 text-white" />
                  </div>
                </div>
              ) : (
                <Icon className="w-5 h-5" />
              )}
              <span className={`text-[10px] font-bold ${isPostAd ? 'mt-9' : ''} ${isPostAd && isActive ? 'text-emerald-700' : isPostAd ? 'text-emerald-600' : ''}`}>
                {item.label}
              </span>
            </button>
          )
        })}
      </div>
    </nav>
  )
}
