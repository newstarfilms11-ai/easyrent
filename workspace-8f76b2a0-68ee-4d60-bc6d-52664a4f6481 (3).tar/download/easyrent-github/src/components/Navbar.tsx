'use client'

import { useStore } from './store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Home,
  Search,
  Plus,
  User,
  LogOut,
  Shield,
  Building2,
  Menu,
  X,
  CreditCard,
} from 'lucide-react'
import { useState } from 'react'

export default function Navbar() {
  const { currentUser, setCurrentView, logout, searchFilters, setSearchFilters } = useStore()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState(searchFilters.city)

  const handleSearch = () => {
    setSearchFilters({ city: searchQuery })
    setCurrentView('listings')
  }

  return (
    <nav className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <button
            onClick={() => setCurrentView('home')}
            className="flex items-center gap-2 cursor-pointer"
          >
            <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
              <Building2 className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-emerald-700">EasyRent</span>
          </button>

          {/* Desktop Search */}
          <div className="hidden md:flex items-center gap-2 flex-1 max-w-md mx-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search by city..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                className="pl-9 bg-gray-50 border-gray-200 focus:border-emerald-500"
              />
            </div>
            <Button
              onClick={handleSearch}
              className="bg-emerald-600 hover:bg-emerald-700 text-white"
            >
              Search
            </Button>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-2">
            <Button
              variant="ghost"
              onClick={() => setCurrentView('listings')}
              className="text-gray-600 hover:text-emerald-600"
            >
              Listings
            </Button>

            <Button
              variant="ghost"
              onClick={() => setCurrentView('pricing')}
              className="text-gray-600 hover:text-emerald-600 gap-1"
            >
              <CreditCard className="w-4 h-4" /> Pricing
            </Button>

            {currentUser ? (
              <>
                <Button
                  variant="ghost"
                  onClick={() => setCurrentView('add-property')}
                  className="text-gray-600 hover:text-emerald-600 gap-1"
                >
                  <Plus className="w-4 h-4" /> Post Ad
                </Button>

                {currentUser.role === 'ADMIN' && (
                  <Button
                    variant="ghost"
                    onClick={() => setCurrentView('admin')}
                    className="text-gray-600 hover:text-emerald-600 gap-1"
                  >
                    <Shield className="w-4 h-4" /> Admin
                  </Button>
                )}

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" className="gap-2 border-emerald-200">
                      <div className="w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center">
                        <User className="w-4 h-4 text-emerald-600" />
                      </div>
                      <span className="max-w-24 truncate">{currentUser.name}</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48">
                    <DropdownMenuItem onClick={() => setCurrentView('dashboard')}>
                      <Building2 className="w-4 h-4 mr-2" /> My Listings
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setCurrentView('my-rentals')}>
                      <Home className="w-4 h-4 mr-2" /> My Rentals
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setCurrentView('pricing')}>
                      <CreditCard className="w-4 h-4 mr-2" /> Pricing & Plans
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={logout} className="text-red-600">
                      <LogOut className="w-4 h-4 mr-2" /> Logout
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <div className="flex gap-2">
                <Button
                  variant="ghost"
                  onClick={() => setCurrentView('login')}
                  className="text-emerald-600"
                >
                  Login
                </Button>
                <Button
                  onClick={() => setCurrentView('register')}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white"
                >
                  Register
                </Button>
              </div>
            )}
          </div>

          {/* Mobile menu toggle */}
          <button
            className="md:hidden p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden pb-4 border-t border-gray-100 pt-3 space-y-3">
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search by city..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleSearch()
                    setMobileMenuOpen(false)
                  }}
                  className="pl-9"
                />
              </div>
              <Button onClick={handleSearch} className="bg-emerald-600 hover:bg-emerald-700 text-white">
                Go
              </Button>
            </div>

            <button
              onClick={() => { setCurrentView('pricing'); setMobileMenuOpen(false) }}
              className="w-full text-left px-3 py-2 rounded-md hover:bg-gray-100 flex items-center gap-2"
            >
              <CreditCard className="w-4 h-4" /> Pricing & Plans
            </button>

            {currentUser ? (
              <div className="space-y-1">
                <button
                  onClick={() => { setCurrentView('dashboard'); setMobileMenuOpen(false) }}
                  className="w-full text-left px-3 py-2 rounded-md hover:bg-gray-100 flex items-center gap-2"
                >
                  <Building2 className="w-4 h-4" /> My Listings
                </button>
                <button
                  onClick={() => { setCurrentView('my-rentals'); setMobileMenuOpen(false) }}
                  className="w-full text-left px-3 py-2 rounded-md hover:bg-gray-100 flex items-center gap-2"
                >
                  <Home className="w-4 h-4" /> My Rentals
                </button>
                {currentUser.role === 'ADMIN' && (
                  <button
                    onClick={() => { setCurrentView('admin'); setMobileMenuOpen(false) }}
                    className="w-full text-left px-3 py-2 rounded-md hover:bg-gray-100 flex items-center gap-2"
                  >
                    <Shield className="w-4 h-4" /> Admin Panel
                  </button>
                )}
                <button
                  onClick={() => { logout(); setMobileMenuOpen(false) }}
                  className="w-full text-left px-3 py-2 rounded-md hover:bg-gray-100 text-red-600 flex items-center gap-2"
                >
                  <LogOut className="w-4 h-4" /> Logout
                </button>
              </div>
            ) : (
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => { setCurrentView('login'); setMobileMenuOpen(false) }}
                  className="flex-1 border-emerald-600 text-emerald-600"
                >
                  Login
                </Button>
                <Button
                  onClick={() => { setCurrentView('register'); setMobileMenuOpen(false) }}
                  className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white"
                >
                  Register
                </Button>
              </div>
            )}
          </div>
        )}
      </div>
    </nav>
  )
}
