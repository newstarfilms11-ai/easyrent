'use client'

import { useState, useEffect } from 'react'
import { useStore } from './store'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  ArrowLeft, Star, Zap, Crown, Shield, Check, Building2,
  TrendingUp, Rocket, Video, FileText, IndianRupee, Loader2,
  Sparkles, Award, ChevronRight,
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface PricingData {
  adPosting: AdPostingPlan[]
  boosts: BoostPlan[]
  subscriptions: SubscriptionPlan[]
  verification: VerificationPlan[]
}

interface AdPostingPlan {
  id: string
  name: string
  price: number
  description: string
  features: string[]
  highlight: boolean
}

interface BoostPlan {
  id: string
  name: string
  price: number
  days: number
  description: string
  highlight?: boolean
}

interface SubscriptionPlan {
  id: string
  name: string
  price: number
  period: string
  features: string[]
  highlight: boolean
}

interface VerificationPlan {
  id: string
  name: string
  price: number
  description: string
  icon: string
}

export default function PricingPage() {
  const { currentUser, setCurrentView } = useStore()
  const { toast } = useToast()
  const [pricing, setPricing] = useState<PricingData | null>(null)
  const [activeTab, setActiveTab] = useState<'ads' | 'boost' | 'broker' | 'verify'>('ads')
  const [paymentDialog, setPaymentDialog] = useState<{
    open: boolean
    type: string
    title: string
    amount: number
    upiId: string
    loading: boolean
    extra?: Record<string, string>
  }>({ open: false, type: '', title: '', amount: 0, upiId: '', loading: false })

  useEffect(() => {
    fetchPricing()
  }, [])

  const fetchPricing = async () => {
    try {
      const res = await fetch('/api/monetization/pricing')
      const data = await res.json()
      setPricing(data)
    } catch {
      // ignore
    }
  }

  const handlePayment = async () => {
    if (!currentUser) {
      setCurrentView('login')
      return
    }

    setPaymentDialog((prev) => ({ ...prev, loading: true }))

    try {
      let endpoint = ''
      let body: Record<string, unknown> = { upiId: paymentDialog.upiId, userId: currentUser.id }

      switch (paymentDialog.type) {
        case 'subscribe':
          endpoint = '/api/monetization/subscribe'
          body.plan = paymentDialog.extra?.plan
          break
        case 'boost':
          endpoint = '/api/monetization/boost'
          body.propertyId = paymentDialog.extra?.propertyId
          body.boostType = paymentDialog.extra?.boostType
          break
        case 'verify':
          endpoint = '/api/monetization/verify'
          body.propertyId = paymentDialog.extra?.propertyId
          body.verificationType = paymentDialog.extra?.verificationType
          break
        case 'ad-posting':
          endpoint = '/api/monetization/ad-posting'
          body.propertyId = paymentDialog.extra?.propertyId
          body.adType = paymentDialog.extra?.adType
          break
        default:
          return
      }

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      })

      const data = await res.json()

      if (res.ok) {
        toast({
          title: 'Payment Successful! ✅',
          description: data.message || 'Transaction completed!',
        })
        if (data.user) {
          // Update user in store
          const { useStore: store } = await import('./store')
          store.getState().setCurrentUser({ ...currentUser, ...data.user })
        }
      } else {
        toast({
          title: 'Payment Failed ❌',
          description: data.error || 'Something went wrong',
          variant: 'destructive',
        })
      }
    } catch {
      toast({ title: 'Error', description: 'Payment failed', variant: 'destructive' })
    } finally {
      setPaymentDialog((prev) => ({ ...prev, loading: false, open: false }))
    }
  }

  const openPayment = (type: string, title: string, amount: number, extra?: Record<string, string>) => {
    if (!currentUser) {
      setCurrentView('login')
      return
    }
    if (amount === 0) {
      toast({ title: 'This is free!', description: 'No payment needed' })
      return
    }
    setPaymentDialog({ open: true, type, title, amount, upiId: '', loading: false, extra })
  }

  if (!pricing) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-8 h-8 text-emerald-600 animate-spin" />
      </div>
    )
  }

  const tabs = [
    { key: 'ads' as const, label: 'Ad Posting', icon: Building2 },
    { key: 'boost' as const, label: 'Boost Listing', icon: Rocket },
    { key: 'broker' as const, label: 'Broker Plans', icon: Crown },
    { key: 'verify' as const, label: 'Verification', icon: Shield },
  ]

  return (
    <div className="max-w-6xl mx-auto px-4 py-6 pb-24 md:pb-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => setCurrentView('home')} className="p-2 hover:bg-gray-100 rounded-lg">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Pricing & Plans</h1>
          <p className="text-gray-500 text-sm">Grow your rental business with EasyRent</p>
        </div>
      </div>

      {/* Revenue Potential Banner */}
      <Card className="mb-6 bg-gradient-to-r from-emerald-600 to-teal-700 text-white border-0 overflow-hidden relative">
        <div className="absolute top-0 right-0 w-40 h-40 rounded-full bg-white/10 -translate-y-1/2 translate-x-1/2" />
        <CardContent className="p-5 relative z-10">
          <div className="flex items-center gap-3 mb-2">
            <TrendingUp className="w-6 h-6" />
            <h3 className="text-lg font-bold">Earn ₹30,000 – ₹1,00,000/month</h3>
          </div>
          <p className="text-emerald-100 text-sm">
            With 500 daily users, 20 paid ads & 10 broker subscriptions — your EasyRent app can generate significant revenue!
          </p>
        </CardContent>
      </Card>

      {/* Tab Navigation */}
      <div className="flex gap-2 overflow-x-auto pb-3 mb-6 scrollbar-hide">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${
              activeTab === tab.key
                ? 'bg-emerald-600 text-white shadow-md'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Ad Posting Plans */}
      {activeTab === 'ads' && (
        <div>
          <div className="mb-4">
            <h2 className="text-xl font-bold text-gray-900">Property Ad Posting</h2>
            <p className="text-gray-500 text-sm">First ad is FREE! Choose a plan for more visibility.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {pricing.adPosting.map((plan) => (
              <Card
                key={plan.id}
                className={`relative overflow-hidden transition-all hover:shadow-lg ${
                  plan.highlight
                    ? 'ring-2 ring-emerald-500 shadow-md'
                    : 'hover:-translate-y-1'
                }`}
              >
                {plan.highlight && (
                  <div className="absolute top-0 right-0 bg-emerald-500 text-white text-xs font-bold px-3 py-1 rounded-bl-lg">
                    Best Value
                  </div>
                )}
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">{plan.name}</CardTitle>
                  <p className="text-sm text-gray-500">{plan.description}</p>
                </CardHeader>
                <CardContent>
                  <div className="mb-4">
                    <span className="text-3xl font-bold text-gray-900">
                      {plan.price === 0 ? 'FREE' : `₹${plan.price}`}
                    </span>
                    {plan.price > 0 && <span className="text-gray-400 text-sm ml-1">/ad</span>}
                  </div>
                  <ul className="space-y-2 mb-4">
                    {plan.features.map((f, i) => (
                      <li key={i} className="flex items-center gap-2 text-sm text-gray-600">
                        <Check className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                        {f}
                      </li>
                    ))}
                  </ul>
                  <Button
                    className={`w-full ${
                      plan.highlight
                        ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                    onClick={() => openPayment('ad-posting', `${plan.name} - Ad Posting`, plan.price, {
                      adType: plan.id,
                    })}
                  >
                    {plan.price === 0 ? 'Post Free Ad' : `Choose ₹${plan.price}`}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Boost Listings */}
      {activeTab === 'boost' && (
        <div>
          <div className="mb-4">
            <h2 className="text-xl font-bold text-gray-900">Boost Your Listing</h2>
            <p className="text-gray-500 text-sm">Push your property to the top — get more enquiries!</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {pricing.boosts.map((plan) => (
              <Card
                key={plan.id}
                className={`relative overflow-hidden transition-all hover:shadow-lg ${
                  plan.highlight
                    ? 'ring-2 ring-emerald-500 shadow-md scale-[1.02]'
                    : 'hover:-translate-y-1'
                }`}
              >
                {plan.highlight && (
                  <div className="absolute top-0 right-0 bg-emerald-500 text-white text-xs font-bold px-3 py-1 rounded-bl-lg">
                    Popular
                  </div>
                )}
                <CardContent className="p-6 text-center">
                  <div className="w-14 h-14 rounded-full bg-amber-50 flex items-center justify-center mx-auto mb-3">
                    <Rocket className="w-7 h-7 text-amber-500" />
                  </div>
                  <h3 className="text-lg font-bold mb-1">{plan.name}</h3>
                  <p className="text-sm text-gray-500 mb-3">{plan.description}</p>
                  <div className="mb-1">
                    <span className="text-3xl font-bold text-gray-900">₹{plan.price}</span>
                  </div>
                  <Badge variant="secondary" className="mb-4">{plan.days} days visibility</Badge>
                  <Button
                    className={`w-full ${
                      plan.highlight
                        ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                    onClick={() => openPayment('boost', `Boost: ${plan.name}`, plan.price, {
                      boostType: plan.id,
                    })}
                  >
                    Boost Now <ChevronRight className="w-4 h-4 ml-1" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Broker Subscription */}
      {activeTab === 'broker' && (
        <div>
          <div className="mb-4">
            <h2 className="text-xl font-bold text-gray-900">Broker Subscription</h2>
            <p className="text-gray-500 text-sm">For property dealers & brokers — unlimited listings & premium features!</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {pricing.subscriptions.map((plan) => (
              <Card
                key={plan.id}
                className={`relative overflow-hidden transition-all hover:shadow-lg ${
                  plan.highlight
                    ? 'ring-2 ring-emerald-500 shadow-lg'
                    : 'hover:-translate-y-1'
                }`}
              >
                {plan.highlight && (
                  <div className="absolute top-0 right-0 bg-gradient-to-l from-emerald-500 to-teal-500 text-white text-xs font-bold px-4 py-1 rounded-bl-lg">
                    <Star className="w-3 h-3 inline mr-1" /> Recommended
                  </div>
                )}
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      plan.highlight ? 'bg-emerald-100' : 'bg-gray-100'
                    }`}>
                      <Crown className={`w-6 h-6 ${plan.highlight ? 'text-emerald-600' : 'text-gray-500'}`} />
                    </div>
                    <div>
                      <CardTitle className="text-xl">{plan.name}</CardTitle>
                      <p className="text-sm text-gray-500">₹{plan.price}/{plan.period}</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="mb-4">
                    <span className="text-4xl font-bold text-gray-900">₹{plan.price}</span>
                    <span className="text-gray-400 ml-1">/month</span>
                  </div>
                  <ul className="space-y-3 mb-6">
                    {plan.features.map((f, i) => (
                      <li key={i} className="flex items-center gap-2 text-sm text-gray-600">
                        <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${
                          plan.highlight ? 'bg-emerald-100' : 'bg-gray-100'
                        }`}>
                          <Check className={`w-3 h-3 ${plan.highlight ? 'text-emerald-600' : 'text-gray-500'}`} />
                        </div>
                        {f}
                      </li>
                    ))}
                  </ul>
                  <Button
                    className={`w-full h-12 text-base font-semibold ${
                      plan.highlight
                        ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                    onClick={() => openPayment('subscribe', `${plan.name} Subscription`, plan.price, {
                      plan: plan.id,
                    })}
                  >
                    Subscribe Now <ArrowLeft className="w-4 h-4 ml-1 rotate-180" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Realistic Target */}
          <Card className="mt-6 bg-gradient-to-r from-amber-50 to-orange-50 border-amber-200">
            <CardContent className="p-5">
              <h3 className="font-bold text-amber-800 mb-2 flex items-center gap-2">
                <TrendingUp className="w-5 h-5" /> Realistic Revenue Target
              </h3>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-amber-700">500</div>
                  <div className="text-xs text-amber-600">Daily Users</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-amber-700">20</div>
                  <div className="text-xs text-amber-600">Paid Ads/Day</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-amber-700">10</div>
                  <div className="text-xs text-amber-600">Subscriptions</div>
                </div>
              </div>
              <div className="text-center mt-3 pt-3 border-t border-amber-200">
                <span className="text-lg font-bold text-amber-800">₹30,000 – ₹1,00,000/month</span>
                <p className="text-xs text-amber-600">potential revenue</p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Verification Service */}
      {activeTab === 'verify' && (
        <div>
          <div className="mb-4">
            <h2 className="text-xl font-bold text-gray-900">Property Verification</h2>
            <p className="text-gray-500 text-sm">Get a "Verified Property" badge — build trust, get more tenants!</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {pricing.verification.map((plan) => {
              const iconMap: Record<string, React.ElementType> = {
                file: FileText,
                video: Video,
                shield: Shield,
              }
              const Icon = iconMap[plan.icon] || Shield

              return (
                <Card key={plan.id} className="relative overflow-hidden transition-all hover:shadow-lg hover:-translate-y-1">
                  <CardContent className="p-6 text-center">
                    <div className="w-14 h-14 rounded-full bg-emerald-50 flex items-center justify-center mx-auto mb-3">
                      <Icon className="w-7 h-7 text-emerald-600" />
                    </div>
                    <h3 className="text-lg font-bold mb-1">{plan.name}</h3>
                    <p className="text-sm text-gray-500 mb-3">{plan.description}</p>
                    <div className="mb-4">
                      <span className="text-3xl font-bold text-gray-900">₹{plan.price}</span>
                    </div>
                    <Badge className="mb-4 bg-emerald-100 text-emerald-700">
                      <Shield className="w-3 h-3 mr-1" /> Verified Badge
                    </Badge>
                    <Button
                      className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
                      onClick={() => openPayment('verify', `${plan.name} - Verification`, plan.price, {
                        verificationType: plan.id,
                      })}
                    >
                      Verify Now
                    </Button>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          {/* Benefits */}
          <Card className="mt-6 bg-gray-50">
            <CardContent className="p-5">
              <h3 className="font-bold text-gray-900 mb-3">Why Get Verified?</h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                  { icon: Sparkles, title: 'More Trust', desc: 'Tenants prefer verified properties 3x more' },
                  { icon: TrendingUp, title: 'More Enquiries', desc: 'Verified listings get 50% more contacts' },
                  { icon: Award, title: 'Premium Badge', desc: 'Green verified badge stands out in search' },
                ].map((item) => (
                  <div key={item.title} className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center flex-shrink-0">
                      <item.icon className="w-5 h-5 text-emerald-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm">{item.title}</h4>
                      <p className="text-xs text-gray-500">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Income Strategy Section */}
      <Card className="mt-8 border-0 bg-gradient-to-br from-gray-900 to-gray-800 text-white overflow-hidden">
        <CardContent className="p-6">
          <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
            <IndianRupee className="w-6 h-6 text-emerald-400" />
            Monetization Strategy — Start with These 3
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {[
              {
                step: '1',
                title: 'Featured Ads',
                desc: 'Owners pay ₹99–₹599 to boost their listing. Quick revenue from day one.',
                amount: '₹2,000–₹10,000/mo',
              },
              {
                step: '2',
                title: 'Broker Subscription',
                desc: 'Monthly plans ₹499–₹1,499 for unlimited listings & premium features.',
                amount: '₹5,000–₹15,000/mo',
              },
              {
                step: '3',
                title: 'Google Ads',
                desc: 'Banner & video ads once you have traffic. Passive income.',
                amount: '₹3,000–₹20,000/mo',
              },
            ].map((item) => (
              <div key={item.step} className="bg-white/10 rounded-xl p-4">
                <div className="w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center text-sm font-bold mb-2">
                  {item.step}
                </div>
                <h4 className="font-semibold mb-1">{item.title}</h4>
                <p className="text-sm text-gray-300 mb-2">{item.desc}</p>
                <div className="text-emerald-400 font-bold text-sm">{item.amount}</div>
              </div>
            ))}
          </div>
          <div className="mt-4 pt-4 border-t border-white/20 text-center">
            <p className="text-sm text-gray-300">
              <strong className="text-white">Key:</strong> Focus on users & listings first. Money follows trust!
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Payment Dialog */}
      <Dialog open={paymentDialog.open} onOpenChange={(open) => setPaymentDialog((prev) => ({ ...prev, open }))}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Complete Payment</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-emerald-50 rounded-xl p-4 text-center">
              <p className="text-sm text-gray-600">Amount to Pay</p>
              <p className="text-3xl font-bold text-emerald-700">₹{paymentDialog.amount}</p>
              <p className="text-sm text-gray-500">{paymentDialog.title}</p>
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">UPI ID</label>
              <Input
                placeholder="yourname@upi"
                value={paymentDialog.upiId}
                onChange={(e) => setPaymentDialog((prev) => ({ ...prev, upiId: e.target.value }))}
              />
              <p className="text-xs text-gray-400 mt-1">Simulated payment — no real money charged</p>
            </div>
            <Button
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white h-12 text-base font-semibold"
              onClick={handlePayment}
              disabled={paymentDialog.loading || !paymentDialog.upiId}
            >
              {paymentDialog.loading ? (
                <Loader2 className="w-5 h-5 animate-spin mr-2" />
              ) : (
                <IndianRupee className="w-5 h-5 mr-2" />
              )}
              Pay ₹{paymentDialog.amount}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
