'use client'

import { useState } from 'react'
import { useStore, Review } from './store'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Star, Send } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface ReviewSectionProps {
  propertyId: string
  reviews: Review[]
  onReviewAdded: () => void
}

export default function ReviewSection({ propertyId, reviews, onReviewAdded }: ReviewSectionProps) {
  const { currentUser, setCurrentView } = useStore()
  const { toast } = useToast()
  const [rating, setRating] = useState(0)
  const [hoverRating, setHoverRating] = useState(0)
  const [comment, setComment] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [showForm, setShowForm] = useState(false)

  const handleSubmit = async () => {
    if (!currentUser) {
      setCurrentView('login')
      return
    }
    if (rating === 0 || !comment.trim()) {
      toast({ title: 'Please add rating and comment', variant: 'destructive' })
      return
    }

    setSubmitting(true)
    try {
      const res = await fetch(`/api/properties/${propertyId}/review`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rating,
          comment: comment.trim(),
          userId: currentUser.id,
        }),
      })

      if (res.ok) {
        toast({ title: 'Review added!' })
        setRating(0)
        setComment('')
        setShowForm(false)
        onReviewAdded()
      } else {
        const data = await res.json()
        toast({ title: data.error || 'Failed to add review', variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Failed to add review', variant: 'destructive' })
    } finally {
      setSubmitting(false)
    }
  }

  const avgRating = reviews.length > 0
    ? Math.round((reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length) * 10) / 10
    : 0

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Reviews ({reviews.length})</CardTitle>
          {reviews.length > 0 && (
            <div className="flex items-center gap-1">
              <Star className="w-5 h-5 fill-amber-400 text-amber-400" />
              <span className="font-bold text-lg">{avgRating}</span>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Add review button */}
        {!showForm && currentUser && (
          <Button
            onClick={() => setShowForm(true)}
            variant="outline"
            className="w-full border-emerald-300 text-emerald-700 hover:bg-emerald-50"
          >
            Write a Review
          </Button>
        )}

        {/* Review form */}
        {showForm && (
          <div className="p-4 rounded-lg border border-emerald-200 bg-emerald-50/50 space-y-3">
            <div>
              <p className="text-sm font-medium mb-2">Your Rating</p>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onMouseEnter={() => setHoverRating(star)}
                    onMouseLeave={() => setHoverRating(0)}
                    onClick={() => setRating(star)}
                    className="p-1"
                  >
                    <Star
                      className={`w-7 h-7 transition-colors ${
                        star <= (hoverRating || rating)
                          ? 'fill-amber-400 text-amber-400'
                          : 'text-gray-300'
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>
            <Textarea
              placeholder="Share your experience..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              rows={3}
            />
            <div className="flex gap-2">
              <Button
                onClick={handleSubmit}
                disabled={submitting}
                className="bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                <Send className="w-4 h-4 mr-1" />
                {submitting ? 'Submitting...' : 'Submit Review'}
              </Button>
              <Button variant="ghost" onClick={() => setShowForm(false)}>Cancel</Button>
            </div>
          </div>
        )}

        {!currentUser && (
          <p className="text-sm text-gray-500 text-center">
            <button onClick={() => setCurrentView('login')} className="text-emerald-600 underline">
              Login
            </button>{' '}
            to write a review
          </p>
        )}

        {/* Review list */}
        <div className="space-y-3 max-h-96 overflow-y-auto">
          {reviews.length === 0 ? (
            <p className="text-gray-400 text-center py-4 text-sm">No reviews yet. Be the first!</p>
          ) : (
            reviews.map((review) => (
              <div key={review.id} className="p-3 rounded-lg border bg-white">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center text-xs font-bold text-emerald-700">
                      {review.user?.name?.charAt(0) || 'U'}
                    </div>
                    <span className="font-medium text-sm">{review.user?.name || 'User'}</span>
                  </div>
                  <div className="flex items-center gap-0.5">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`w-3.5 h-3.5 ${
                          star <= review.rating ? 'fill-amber-400 text-amber-400' : 'text-gray-200'
                        }`}
                      />
                    ))}
                  </div>
                </div>
                <p className="text-sm text-gray-600">{review.comment}</p>
                <p className="text-xs text-gray-400 mt-1">
                  {new Date(review.createdAt).toLocaleDateString('en-IN', {
                    year: 'numeric', month: 'short', day: 'numeric',
                  })}
                </p>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  )
}
