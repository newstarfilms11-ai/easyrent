import { create } from 'zustand'

export type ViewType = 'home' | 'listings' | 'detail' | 'add-property' | 'edit-property' | 'dashboard' | 'admin' | 'my-rentals' | 'login' | 'register' | 'pricing'

export interface User {
  id: string
  name: string
  email: string
  phone: string
  aadharNo?: string | null
  aadharVerified: boolean
  role: string
  avatar?: string | null
  subscriptionPlan?: string
  subscriptionExpiry?: string | null
  freeAdsUsed?: number
}

export interface Property {
  id: string
  title: string
  description: string
  type: string
  rent: number
  deposit: number
  address: string
  city: string
  state: string
  lat?: number | null
  lng?: number | null
  images: string
  video?: string | null
  availableFrom: string
  availableTo?: string | null
  status: string
  adType?: string
  isFeatured?: boolean
  featuredUntil?: string | null
  isVerified?: boolean
  ownerId: string
  owner?: User
  reviews?: Review[]
  rentals?: Rental[]
  createdAt: string
  updatedAt: string
  avgRating?: number
  reviewCount?: number
}

export interface Review {
  id: string
  rating: number
  comment: string
  userId: string
  propertyId: string
  user?: User
  createdAt: string
}

export interface Rental {
  id: string
  propertyId: string
  tenantId: string
  startDate: string
  endDate: string
  status: string
  paymentId?: string | null
  createdAt: string
  updatedAt: string
  property?: Property
  tenant?: User
}

export interface Payment {
  id: string
  rentalId: string
  amount: number
  upiId: string
  status: string
  transactionId?: string | null
  createdAt: string
}

export interface SearchFilters {
  city: string
  type: string
  minRent: number | null
  maxRent: number | null
  sort: string
}

interface AppState {
  currentView: ViewType
  currentUser: User | null
  selectedPropertyId: string | null
  searchFilters: SearchFilters
  editingProperty: Property | null

  setCurrentView: (view: ViewType) => void
  setCurrentUser: (user: User | null) => void
  setSelectedPropertyId: (id: string | null) => void
  setSearchFilters: (filters: Partial<SearchFilters>) => void
  setEditingProperty: (property: Property | null) => void
  logout: () => void
}

export const useStore = create<AppState>((set) => ({
  currentView: 'home',
  currentUser: null,
  selectedPropertyId: null,
  searchFilters: {
    city: '',
    type: '',
    minRent: null,
    maxRent: null,
    sort: 'newest',
  },
  editingProperty: null,

  setCurrentView: (view) => set({ currentView: view }),
  setCurrentUser: (user) => set({ currentUser: user }),
  setSelectedPropertyId: (id) => set({ selectedPropertyId: id }),
  setSearchFilters: (filters) =>
    set((state) => ({
      searchFilters: { ...state.searchFilters, ...filters },
    })),
  setEditingProperty: (property) => set({ editingProperty: property }),
  logout: () =>
    set({
      currentUser: null,
      currentView: 'home',
      selectedPropertyId: null,
    }),
}))
