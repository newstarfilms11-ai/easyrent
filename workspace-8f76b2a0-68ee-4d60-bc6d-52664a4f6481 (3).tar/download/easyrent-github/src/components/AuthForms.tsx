'use client'

import { useState } from 'react'
import { useStore } from './store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { Building2, LogIn, UserPlus, Phone, Mail, Lock, User, CreditCard } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

export default function AuthForms() {
  const { setCurrentView, setCurrentUser } = useStore()
  const { toast } = useToast()
  const [isLogin, setIsLogin] = useState(true)
  const [loading, setLoading] = useState(false)

  // Login fields
  const [identifier, setIdentifier] = useState('')
  const [password, setPassword] = useState('')

  // Register fields
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const [regPassword, setRegPassword] = useState('')
  const [aadharNo, setAadharNo] = useState('')

  const handleLogin = async () => {
    if (!identifier || !password) {
      toast({ title: 'Please fill all fields', variant: 'destructive' })
      return
    }

    setLoading(true)
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier, password }),
      })
      const data = await res.json()

      if (res.ok) {
        setCurrentUser(data.user)
        toast({ title: `Welcome, ${data.user.name}!` })
        setCurrentView('home')
      } else {
        toast({ title: data.error || 'Login failed', variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Login failed', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  const handleRegister = async () => {
    if (!name || !email || !phone || !regPassword) {
      toast({ title: 'Please fill all required fields', variant: 'destructive' })
      return
    }

    setLoading(true)
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          email,
          phone,
          password: regPassword,
          aadharNo: aadharNo || undefined,
        }),
      })
      const data = await res.json()

      if (res.ok) {
        setCurrentUser(data.user)
        toast({ title: `Welcome, ${data.user.name}! Account created.` })
        setCurrentView('home')
      } else {
        toast({ title: data.error || 'Registration failed', variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Registration failed', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4 py-8">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="w-14 h-14 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-3">
            <Building2 className="w-8 h-8 text-emerald-600" />
          </div>
          <CardTitle className="text-2xl">
            {isLogin ? 'Welcome Back!' : 'Create Account'}
          </CardTitle>
          <p className="text-gray-500 text-sm">
            {isLogin ? 'Login to your EasyRent account' : 'Join EasyRent today'}
          </p>
        </CardHeader>
        <CardContent>
          {isLogin ? (
            <div className="space-y-4">
              <div>
                <Label htmlFor="identifier">Email or Phone</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="identifier"
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    placeholder="email@example.com"
                    className="pl-9"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="loginPassword">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="loginPassword"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter password"
                    className="pl-9"
                    onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                  />
                </div>
              </div>
              <Button
                onClick={handleLogin}
                disabled={loading}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                <LogIn className="w-4 h-4 mr-2" />
                {loading ? 'Logging in...' : 'Login'}
              </Button>

              <div className="text-center">
                <p className="text-sm text-gray-500">
                  Demo Admin: admin@easyrent.com / admin123
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <Label htmlFor="regName">Full Name *</Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="regName"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Your full name"
                    className="pl-9"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="regEmail">Email *</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="regEmail"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="email@example.com"
                    className="pl-9"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="regPhone">Phone *</Label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="regPhone"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="9876543210"
                    className="pl-9"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="regPassword">Password *</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="regPassword"
                    type="password"
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="Create password"
                    className="pl-9"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="aadharNo">Aadhar Number</Label>
                <div className="relative">
                  <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="aadharNo"
                    value={aadharNo}
                    onChange={(e) => setAadharNo(e.target.value)}
                    placeholder="XXXX XXXX XXXX (optional)"
                    className="pl-9"
                  />
                </div>
              </div>
              <Button
                onClick={handleRegister}
                disabled={loading}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                <UserPlus className="w-4 h-4 mr-2" />
                {loading ? 'Creating Account...' : 'Create Account'}
              </Button>
            </div>
          )}

          <Separator className="my-5" />

          <div className="text-center">
            <button
              onClick={() => setIsLogin(!isLogin)}
              className="text-emerald-600 hover:text-emerald-700 text-sm font-medium"
            >
              {isLogin
                ? "Don't have an account? Register"
                : 'Already have an account? Login'}
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
