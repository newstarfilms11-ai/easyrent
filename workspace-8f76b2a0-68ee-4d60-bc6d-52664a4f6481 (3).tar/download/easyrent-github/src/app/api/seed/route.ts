import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

function simpleHash(password: string): string {
  return Buffer.from(password).toString('base64')
}

const propertyImages: Record<string, string[]> = {
  ROOM: [
    'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?w=600&h=400&fit=crop',
    'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=600&h=400&fit=crop',
  ],
  PG: [
    'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=600&h=400&fit=crop',
    'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=600&h=400&fit=crop',
  ],
  HOUSE: [
    'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=600&h=400&fit=crop',
    'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=600&h=400&fit=crop',
  ],
  SHOP: [
    'https://images.unsplash.com/photo-1604014237800-1c9102c219da?w=600&h=400&fit=crop',
    'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=600&h=400&fit=crop',
  ],
  GARAGE: [
    'https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=600&h=400&fit=crop',
    'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=600&h=400&fit=crop',
  ],
}

export async function GET() {
  try {
    // Check if already seeded
    const existingUsers = await db.user.count()
    if (existingUsers > 0) {
      return NextResponse.json({ message: 'Database already seeded', count: existingUsers })
    }

    // Create admin
    const admin = await db.user.create({
      data: {
        name: 'Admin EasyRent',
        email: 'admin@easyrent.com',
        phone: '9999999999',
        password: simpleHash('admin123'),
        aadharNo: '123456789012',
        aadharVerified: true,
        role: 'ADMIN',
      },
    })

    // Create regular users
    const user1 = await db.user.create({
      data: {
        name: 'Rajesh Kumar',
        email: 'rajesh@example.com',
        phone: '9876543210',
        password: simpleHash('password123'),
        aadharNo: '234567890123',
        aadharVerified: true,
        role: 'USER',
        subscriptionPlan: 'FREE',
        freeAdsUsed: 0,
      },
    })

    const user2 = await db.user.create({
      data: {
        name: 'Priya Sharma',
        email: 'priya@example.com',
        phone: '9876543211',
        password: simpleHash('password123'),
        aadharNo: '345678901234',
        aadharVerified: true,
        role: 'BROKER',
        subscriptionPlan: 'PRO_BROKER',
        subscriptionExpiry: '2026-06-30',
        freeAdsUsed: 3,
      },
    })

    const user3 = await db.user.create({
      data: {
        name: 'Amit Patel',
        email: 'amit@example.com',
        phone: '9876543212',
        password: simpleHash('password123'),
        role: 'BROKER',
        subscriptionPlan: 'BASIC_BROKER',
        subscriptionExpiry: '2026-05-30',
        freeAdsUsed: 5,
      },
    })

    const users = [user1, user2, user3]

    // Create properties with monetization fields
    const propertiesData = [
      {
        title: 'Spacious AC Room near Metro',
        description: 'Well-furnished AC room with attached bathroom, WiFi, 24/7 water supply. Near Metro Station, ideal for working professionals.',
        type: 'ROOM',
        rent: 8000,
        deposit: 16000,
        address: 'Sector 15, Near Metro Station',
        city: 'Noida',
        state: 'Uttar Pradesh',
        lat: 28.5843,
        lng: 77.3119,
        availableFrom: '2025-06-01',
        adType: 'FREE',
        isFeatured: false,
        isVerified: false,
      },
      {
        title: 'PG for Boys with Meals',
        description: 'Paying Guest accommodation for boys with 3 meals a day, WiFi, laundry, housekeeping. Fully furnished rooms.',
        type: 'PG',
        rent: 12000,
        deposit: 12000,
        address: 'Koramangala 4th Block',
        city: 'Bangalore',
        state: 'Karnataka',
        lat: 12.9352,
        lng: 77.6245,
        availableFrom: '2025-06-15',
        adType: 'FEATURED',
        isFeatured: true,
        featuredUntil: '2026-07-15',
        isVerified: true,
      },
      {
        title: '3 BHK Independent House',
        description: 'Beautiful independent house with 3 bedrooms, hall, kitchen, parking space. Gated community with security.',
        type: 'HOUSE',
        rent: 25000,
        deposit: 75000,
        address: 'Whitefield, ITPL Main Road',
        city: 'Bangalore',
        state: 'Karnataka',
        lat: 12.9698,
        lng: 77.7500,
        availableFrom: '2025-07-01',
        availableTo: '2026-06-30',
        adType: 'TOP_LISTING',
        isFeatured: true,
        featuredUntil: '2026-08-01',
        isVerified: true,
      },
      {
        title: 'Commercial Shop on Main Road',
        description: 'Prime location commercial shop on main road with heavy footfall. Suitable for retail, restaurant, or office.',
        type: 'SHOP',
        rent: 35000,
        deposit: 100000,
        address: 'MG Road, Main Market',
        city: 'Pune',
        state: 'Maharashtra',
        lat: 18.5314,
        lng: 73.8446,
        availableFrom: '2025-06-01',
        adType: 'BASIC',
        isFeatured: false,
        isVerified: false,
      },
      {
        title: 'Private Garage for Car Parking',
        description: 'Secure covered garage for car parking. 24/7 CCTV surveillance, remote gate access.',
        type: 'GARAGE',
        rent: 3000,
        deposit: 6000,
        address: 'DLF Phase 2',
        city: 'Gurgaon',
        state: 'Haryana',
        lat: 28.4947,
        lng: 77.0887,
        availableFrom: '2025-06-01',
        adType: 'FREE',
        isFeatured: false,
        isVerified: false,
      },
      {
        title: 'Furnished Room in Andheri',
        description: 'Semi-furnished room with AC, bed, wardrobe, attached bathroom. Close to Andheri station.',
        type: 'ROOM',
        rent: 10000,
        deposit: 20000,
        address: 'Andheri West, near Station',
        city: 'Mumbai',
        state: 'Maharashtra',
        lat: 19.1197,
        lng: 72.8464,
        availableFrom: '2025-07-01',
        adType: 'FEATURED',
        isFeatured: true,
        featuredUntil: '2026-07-01',
        isVerified: true,
      },
      {
        title: 'Girls PG with AC & WiFi',
        description: 'Safe and secure PG for girls with AC rooms, WiFi, meals, laundry service. CCTV and warden available.',
        type: 'PG',
        rent: 15000,
        deposit: 15000,
        address: 'Hauz Khas, near IIT Delhi',
        city: 'Delhi',
        state: 'Delhi',
        lat: 28.5494,
        lng: 77.2001,
        availableFrom: '2025-06-20',
        adType: 'FREE',
        isFeatured: false,
        isVerified: false,
      },
      {
        title: '2 BHK Flat for Family',
        description: 'Spacious 2 BHK flat suitable for family with kids. Near school, hospital, and market. Reserved parking.',
        type: 'HOUSE',
        rent: 18000,
        deposit: 54000,
        address: 'Kukatpally Housing Board',
        city: 'Hyderabad',
        state: 'Telangana',
        lat: 17.4849,
        lng: 78.4130,
        availableFrom: '2025-08-01',
        availableTo: '2026-07-31',
        adType: 'TOP_LISTING',
        isFeatured: true,
        featuredUntil: '2026-09-01',
        isVerified: true,
      },
      {
        title: 'Shop in Mall - Food Court',
        description: 'Shop space available in popular mall food court. High footfall area, ideal for food business.',
        type: 'SHOP',
        rent: 50000,
        deposit: 150000,
        address: 'Phoenix Mall, Lower Parel',
        city: 'Mumbai',
        state: 'Maharashtra',
        lat: 19.0142,
        lng: 72.8311,
        availableFrom: '2025-07-01',
        adType: 'FREE',
        isFeatured: false,
        isVerified: false,
      },
      {
        title: 'Budget Room for Students',
        description: 'Affordable room near university campus. Shared kitchen available. Quiet study environment.',
        type: 'ROOM',
        rent: 5000,
        deposit: 5000,
        address: 'Banaras Hindu University Campus',
        city: 'Varanasi',
        state: 'Uttar Pradesh',
        lat: 25.2677,
        lng: 82.9913,
        availableFrom: '2025-06-01',
        adType: 'FREE',
        isFeatured: false,
        isVerified: false,
      },
      {
        title: 'Premium PG with Gym Access',
        description: 'Premium PG with gym, swimming pool access, AC rooms, home-cooked meals. Perfect for IT professionals.',
        type: 'PG',
        rent: 20000,
        deposit: 20000,
        address: 'Electronic City Phase 1',
        city: 'Bangalore',
        state: 'Karnataka',
        lat: 12.8399,
        lng: 77.6770,
        availableFrom: '2025-06-10',
        adType: 'BASIC',
        isFeatured: false,
        isVerified: true,
      },
      {
        title: 'Garage for Two-Wheeler',
        description: 'Covered parking space for two-wheelers. Safe and secure with CCTV monitoring.',
        type: 'GARAGE',
        rent: 1500,
        deposit: 3000,
        address: 'Jayanagar 4th Block',
        city: 'Bangalore',
        state: 'Karnataka',
        lat: 12.9299,
        lng: 77.5838,
        availableFrom: '2025-06-01',
        adType: 'FREE',
        isFeatured: false,
        isVerified: false,
      },
    ]

    const properties = []
    for (let i = 0; i < propertiesData.length; i++) {
      const pData = propertiesData[i]
      const owner = users[i % users.length]
      const images = JSON.stringify(propertyImages[pData.type as keyof typeof propertyImages] || [])

      const property = await db.property.create({
        data: {
          ...pData,
          images,
          video: null,
          status: i < 8 ? 'APPROVED' : 'PENDING',
          ownerId: owner.id,
        },
      })
      properties.push(property)
    }

    // Create reviews
    const reviewData = [
      { rating: 5, comment: 'Excellent room! Very clean and well-maintained. Owner is very helpful.', userId: user2.id, propertyIndex: 0 },
      { rating: 4, comment: 'Good PG with decent food. WiFi speed is nice. Would recommend.', userId: user3.id, propertyIndex: 1 },
      { rating: 4, comment: 'Beautiful house, spacious rooms. Parking is a plus!', userId: user1.id, propertyIndex: 2 },
      { rating: 3, comment: 'Decent shop, but rent is a bit high for the size.', userId: user2.id, propertyIndex: 3 },
      { rating: 5, comment: 'Safe and secure garage. My car is always protected.', userId: user3.id, propertyIndex: 4 },
      { rating: 4, comment: 'Great location near station. Room is comfortable.', userId: user1.id, propertyIndex: 5 },
      { rating: 5, comment: 'Best PG for girls! Very safe and meals are delicious.', userId: user2.id, propertyIndex: 6 },
      { rating: 3, comment: 'Flat is nice but water supply is sometimes an issue.', userId: user3.id, propertyIndex: 7 },
    ]

    for (const rd of reviewData) {
      await db.review.create({
        data: {
          rating: rd.rating,
          comment: rd.comment,
          userId: rd.userId,
          propertyId: properties[rd.propertyIndex].id,
        },
      })
    }

    // Create a rental + payment
    const rental1 = await db.rental.create({
      data: {
        propertyId: properties[0].id,
        tenantId: user2.id,
        startDate: '2025-06-01',
        endDate: '2025-11-30',
        status: 'ACTIVE',
      },
    })

    await db.payment.create({
      data: {
        rentalId: rental1.id,
        amount: 8000,
        upiId: 'rajesh@upi',
        status: 'COMPLETED',
        transactionId: 'UPI123456ABC',
      },
    })

    const rental2 = await db.rental.create({
      data: {
        propertyId: properties[1].id,
        tenantId: user3.id,
        startDate: '2025-06-15',
        endDate: '2025-12-14',
        status: 'PENDING',
      },
    })

    await db.payment.create({
      data: {
        rentalId: rental2.id,
        amount: 12000,
        upiId: 'amit@paytm',
        status: 'PENDING',
      },
    })

    // Create sample subscriptions
    await db.subscription.create({
      data: {
        userId: user2.id,
        plan: 'PRO_BROKER',
        amount: 1499,
        startDate: '2025-06-01',
        endDate: '2026-06-30',
        status: 'ACTIVE',
        upiId: 'priya@upi',
      },
    })

    await db.subscription.create({
      data: {
        userId: user3.id,
        plan: 'BASIC_BROKER',
        amount: 499,
        startDate: '2025-05-01',
        endDate: '2026-05-30',
        status: 'ACTIVE',
        upiId: 'amit@paytm',
      },
    })

    // Create sample boosts
    await db.boostListing.create({
      data: {
        propertyId: properties[1].id,
        boostType: '7_DAY',
        amount: 199,
        startDate: '2025-06-15',
        endDate: '2025-06-22',
        status: 'EXPIRED',
        upiId: 'priya@upi',
      },
    })

    await db.boostListing.create({
      data: {
        propertyId: properties[2].id,
        boostType: '30_DAY',
        amount: 599,
        startDate: '2025-07-01',
        endDate: '2025-07-31',
        status: 'ACTIVE',
        upiId: 'priya@upi',
      },
    })

    // Create sample payment orders
    await db.paymentOrder.create({
      data: {
        userId: user2.id,
        propertyId: properties[1].id,
        orderType: 'AD_POSTING',
        amount: 99,
        status: 'COMPLETED',
        transactionId: 'PO001',
        upiId: 'priya@upi',
        metadata: JSON.stringify({ adType: 'FEATURED' }),
      },
    })

    await db.paymentOrder.create({
      data: {
        userId: user2.id,
        propertyId: properties[2].id,
        orderType: 'AD_POSTING',
        amount: 299,
        status: 'COMPLETED',
        transactionId: 'PO002',
        upiId: 'priya@upi',
        metadata: JSON.stringify({ adType: 'TOP_LISTING' }),
      },
    })

    await db.paymentOrder.create({
      data: {
        userId: user3.id,
        propertyId: properties[4].id,
        orderType: 'BOOST',
        amount: 199,
        status: 'COMPLETED',
        transactionId: 'PO003',
        upiId: 'amit@paytm',
        metadata: JSON.stringify({ boostType: '7_DAY' }),
      },
    })

    await db.paymentOrder.create({
      data: {
        userId: user2.id,
        propertyId: properties[5].id,
        orderType: 'VERIFICATION',
        amount: 299,
        status: 'COMPLETED',
        transactionId: 'PO004',
        upiId: 'priya@upi',
        metadata: JSON.stringify({ verificationType: 'VIDEO_VERIFY' }),
      },
    })

    await db.paymentOrder.create({
      data: {
        userId: user2.id,
        orderType: 'SUBSCRIPTION',
        amount: 1499,
        status: 'COMPLETED',
        transactionId: 'PO005',
        upiId: 'priya@upi',
        metadata: JSON.stringify({ plan: 'PRO_BROKER' }),
      },
    })

    await db.paymentOrder.create({
      data: {
        userId: user3.id,
        orderType: 'SUBSCRIPTION',
        amount: 499,
        status: 'COMPLETED',
        transactionId: 'PO006',
        upiId: 'amit@paytm',
        metadata: JSON.stringify({ plan: 'BASIC_BROKER' }),
      },
    })

    return NextResponse.json({
      message: 'Database seeded successfully with monetization data',
      data: {
        users: users.length + 1,
        properties: properties.length,
        reviews: reviewData.length,
        subscriptions: 2,
        boosts: 2,
        paymentOrders: 6,
      },
    })
  } catch (error) {
    console.error('Seed error:', error)
    return NextResponse.json(
      { error: 'Seeding failed', details: String(error) },
      { status: 500 }
    )
  }
}
