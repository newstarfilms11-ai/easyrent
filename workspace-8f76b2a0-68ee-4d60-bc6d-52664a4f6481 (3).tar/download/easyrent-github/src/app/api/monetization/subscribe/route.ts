import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

const subscriptionConfig: Record<string, { price: number; role: string }> = {
  'BASIC_BROKER': { price: 499, role: 'BROKER' },
  'PRO_BROKER': { price: 1499, role: 'BROKER' },
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { plan, upiId, userId } = body

    if (!plan || !userId) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    const config = subscriptionConfig[plan]
    if (!config) {
      return NextResponse.json({ error: 'Invalid subscription plan' }, { status: 400 })
    }

    // Check user exists
    const user = await db.user.findUnique({ where: { id: userId } })
    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Check if already subscribed
    if (user.subscriptionPlan === plan && user.subscriptionExpiry) {
      const expiry = new Date(user.subscriptionExpiry)
      if (expiry > new Date()) {
        return NextResponse.json({ error: 'Already subscribed to this plan' }, { status: 400 })
      }
    }

    // Simulate UPI payment (90% success)
    const paymentSuccess = Math.random() < 0.9
    const transactionId = `SUB${Date.now()}`
    const now = new Date()
    const endDate = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000)

    if (!paymentSuccess) {
      await db.paymentOrder.create({
        data: {
          userId,
          orderType: 'SUBSCRIPTION',
          amount: config.price,
          status: 'FAILED',
          transactionId,
          upiId: upiId || '',
          metadata: JSON.stringify({ plan }),
        },
      })
      return NextResponse.json({ error: 'Payment failed. Please try again.' }, { status: 400 })
    }

    // Create subscription
    const subscription = await db.subscription.create({
      data: {
        userId,
        plan,
        amount: config.price,
        startDate: now.toISOString().split('T')[0],
        endDate: endDate.toISOString().split('T')[0],
        status: 'ACTIVE',
        upiId: upiId || '',
      },
    })

    // Update user
    await db.user.update({
      where: { id: userId },
      data: {
        subscriptionPlan: plan,
        subscriptionExpiry: endDate.toISOString().split('T')[0],
        role: config.role,
      },
    })

    // Record successful payment
    await db.paymentOrder.create({
      data: {
        userId,
        orderType: 'SUBSCRIPTION',
        amount: config.price,
        status: 'COMPLETED',
        transactionId,
        upiId: upiId || '',
        metadata: JSON.stringify({ plan, subscriptionId: subscription.id }),
      },
    })

    return NextResponse.json({
      success: true,
      message: `${plan === 'PRO_BROKER' ? 'Pro Broker' : 'Basic Broker'} subscription activated!`,
      subscription: {
        id: subscription.id,
        plan,
        endDate: endDate.toISOString().split('T')[0],
        amount: config.price,
      },
      user: {
        role: config.role,
        subscriptionPlan: plan,
        subscriptionExpiry: endDate.toISOString().split('T')[0],
      },
    })
  } catch (error) {
    console.error('Subscribe error:', error)
    return NextResponse.json({ error: 'Subscription failed' }, { status: 500 })
  }
}
