import { NextResponse } from 'next/server'

export async function GET() {
  return NextResponse.json({
    adPosting: [
      {
        id: 'FREE',
        name: 'Free Ad',
        price: 0,
        description: '1 Free Ad for new users',
        features: ['Basic listing', '7 days visibility', 'Standard search results'],
        highlight: false,
      },
      {
        id: 'BASIC',
        name: 'Basic Ad',
        price: 49,
        description: '₹49 — Good visibility',
        features: ['Listing with photos', '15 days visibility', 'Search results', 'Contact details visible'],
        highlight: false,
      },
      {
        id: 'FEATURED',
        name: 'Featured Ad',
        price: 99,
        description: '₹99 — Best value!',
        features: ['Highlighted listing', '30 days visibility', 'Priority in search', 'Featured badge', 'More enquiries'],
        highlight: true,
      },
      {
        id: 'TOP_LISTING',
        name: 'Top Listing',
        price: 299,
        description: '₹299 — Maximum reach',
        features: ['Top of search results', '60 days visibility', 'Featured on homepage', 'Premium badge', 'WhatsApp leads', 'Priority support'],
        highlight: false,
      },
    ],
    boosts: [
      { id: '3_DAY', name: '3 Days Boost', price: 99, days: 3, description: 'Quick visibility push' },
      { id: '7_DAY', name: '7 Days Boost', price: 199, days: 7, description: 'Best for weekend searches', highlight: true },
      { id: '30_DAY', name: '30 Days Premium', price: 599, days: 30, description: 'Maximum exposure' },
    ],
    subscriptions: [
      {
        id: 'BASIC_BROKER',
        name: 'Basic Broker',
        price: 499,
        period: 'month',
        features: ['10 listings per month', 'Basic analytics', 'Email support', 'Standard visibility'],
        highlight: false,
      },
      {
        id: 'PRO_BROKER',
        name: 'Pro Broker',
        price: 1499,
        period: 'month',
        features: ['Unlimited listings', 'WhatsApp leads', 'Verified broker badge', 'Priority support', '2 Featured listings/month', 'Analytics dashboard', 'Top search priority'],
        highlight: true,
      },
    ],
    verification: [
      { id: 'DOC_VERIFY', name: 'Document Verification', price: 99, description: 'Property documents verified by our team', icon: 'file' },
      { id: 'VIDEO_VERIFY', name: 'Video Verification', price: 299, description: 'Video tour verification for authenticity', icon: 'video' },
      { id: 'PREMIUM_VERIFY', name: 'Premium Verification', price: 499, description: 'Full verification: Doc + Video + Physical visit', icon: 'shield' },
    ],
  })
}
