import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

const boostConfig: Record<string, { days: number; price: number }> = {
  '3_DAY': { days: 3, price: 99 },
  '7_DAY': { days: 7, price: 199 },
  '30_DAY': { days: 30, price: 599 },
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { propertyId, boostType, upiId, userId } = body

    if (!propertyId || !boostType || !userId) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    const config = boostConfig[boostType]
    if (!config) {
      return NextResponse.json({ error: 'Invalid boost type' }, { status: 400 })
    }

    // Check property exists and belongs to user
    const property = await db.property.findUnique({ where: { id: propertyId } })
    if (!property) {
      return NextResponse.json({ error: 'Property not found' }, { status: 404 })
    }
    if (property.ownerId !== userId) {
      return NextResponse.json({ error: 'Not your property' }, { status: 403 })
    }

    // Simulate UPI payment (90% success)
    const paymentSuccess = Math.random() < 0.9
    const transactionId = `BOOST${Date.now()}`
    const now = new Date()
    const endDate = new Date(now.getTime() + config.days * 24 * 60 * 60 * 1000)

    if (!paymentSuccess) {
      // Record failed payment
      await db.paymentOrder.create({
        data: {
          userId,
          propertyId,
          orderType: 'BOOST',
          amount: config.price,
          status: 'FAILED',
          transactionId,
          upiId: upiId || '',
          metadata: JSON.stringify({ boostType }),
        },
      })
      return NextResponse.json({ error: 'Payment failed. Please try again.' }, { status: 400 })
    }

    // Create boost listing
    const boost = await db.boostListing.create({
      data: {
        propertyId,
        boostType,
        amount: config.price,
        startDate: now.toISOString().split('T')[0],
        endDate: endDate.toISOString().split('T')[0],
        status: 'ACTIVE',
        upiId: upiId || '',
      },
    })

    // Update property as featured
    await db.property.update({
      where: { id: propertyId },
      data: {
        isFeatured: true,
        featuredUntil: endDate.toISOString().split('T')[0],
      },
    })

    // Record successful payment
    await db.paymentOrder.create({
      data: {
        userId,
        propertyId,
        orderType: 'BOOST',
        amount: config.price,
        status: 'COMPLETED',
        transactionId,
        upiId: upiId || '',
        metadata: JSON.stringify({ boostType, boostId: boost.id }),
      },
    })

    return NextResponse.json({
      success: true,
      message: `Property boosted for ${config.days} days!`,
      boost: {
        id: boost.id,
        boostType,
        days: config.days,
        endDate: endDate.toISOString().split('T')[0],
        amount: config.price,
      },
    })
  } catch (error) {
    console.error('Boost error:', error)
    return NextResponse.json({ error: 'Boost failed' }, { status: 500 })
  }
}
