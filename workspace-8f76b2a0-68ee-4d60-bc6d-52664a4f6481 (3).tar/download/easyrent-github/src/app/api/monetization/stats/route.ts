import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (userId) {
      // User-specific stats
      const user = await db.user.findUnique({ where: { id: userId } })
      if (!user) {
        return NextResponse.json({ error: 'User not found' }, { status: 404 })
      }

      const totalSpentResult = await db.paymentOrder.aggregate({
        where: { userId, status: 'COMPLETED' },
        _sum: { amount: true },
      })

      const activeBoosts = await db.boostListing.count({
        where: { property: { ownerId: userId }, status: 'ACTIVE' },
      })

      const subscription = await db.subscription.findFirst({
        where: { userId, status: 'ACTIVE' },
        orderBy: { createdAt: 'desc' },
      })

      const properties = await db.property.count({ where: { ownerId: userId } })

      const isBroker = user.subscriptionPlan === 'PRO_BROKER' || user.subscriptionPlan === 'BASIC_BROKER'
      const freeAdsAllowed = isBroker ? 999 : 1

      return NextResponse.json({
        totalSpent: totalSpentResult._sum.amount || 0,
        activeBoosts,
        subscription: subscription ? {
          plan: subscription.plan,
          endDate: subscription.endDate,
          status: subscription.status,
        } : null,
        properties,
        freeAdsUsed: user.freeAdsUsed || 0,
        freeAdsRemaining: Math.max(0, freeAdsAllowed - (user.freeAdsUsed || 0)),
        subscriptionPlan: user.subscriptionPlan || 'FREE',
        subscriptionExpiry: user.subscriptionExpiry,
      })
    }

    // Admin stats - all monetization (simpler queries to avoid crash)
    const completedOrders = await db.paymentOrder.findMany({
      where: { status: 'COMPLETED' },
      select: { amount: true, orderType: true },
    })

    const totalRevenue = completedOrders.reduce((sum, o) => sum + o.amount, 0)

    const revenueByType: Record<string, { amount: number; count: number }> = {}
    for (const order of completedOrders) {
      const type = order.orderType
      if (!revenueByType[type]) {
        revenueByType[type] = { amount: 0, count: 0 }
      }
      revenueByType[type].amount += order.amount
      revenueByType[type].count += 1
    }

    const [activeSubs, activeBoosts, verifiedCount, totalOrders] = await Promise.all([
      db.subscription.count({ where: { status: 'ACTIVE' } }),
      db.boostListing.count({ where: { status: 'ACTIVE' } }),
      db.property.count({ where: { isVerified: true } }),
      db.paymentOrder.count({ where: { status: 'COMPLETED' } }),
    ])

    const [basicBrokers, proBrokers] = await Promise.all([
      db.subscription.count({ where: { plan: 'BASIC_BROKER', status: 'ACTIVE' } }),
      db.subscription.count({ where: { plan: 'PRO_BROKER', status: 'ACTIVE' } }),
    ])

    // Recent orders with user and property info
    const recentOrdersRaw = await db.paymentOrder.findMany({
      where: { status: 'COMPLETED' },
      orderBy: { createdAt: 'desc' },
      take: 10,
      include: {
        user: { select: { name: true } },
        property: { select: { title: true } },
      },
    })

    return NextResponse.json({
      totalRevenue,
      activeSubscriptions: activeSubs,
      activeBoosts,
      verifiedProperties: verifiedCount,
      totalOrders,
      revenueByType,
      subscriptionBreakdown: {
        basicBroker: basicBrokers,
        proBroker: proBrokers,
      },
      recentOrders: recentOrdersRaw,
      stats: {
        totalRevenue,
        completedOrders: totalOrders,
        activeSubscriptions: activeSubs,
        activeBoosts,
        verificationCount: verifiedCount,
        revenueByType,
      },
      recentOrders: recentOrdersRaw,
    })
  } catch (error) {
    console.error('Stats error:', error)
    return NextResponse.json({ error: 'Failed to fetch stats' }, { status: 500 })
  }
}
