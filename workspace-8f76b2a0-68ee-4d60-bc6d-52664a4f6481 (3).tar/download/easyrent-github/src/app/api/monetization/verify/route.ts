import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

const verificationConfig: Record<string, { price: number }> = {
  'DOC_VERIFY': { price: 99 },
  'VIDEO_VERIFY': { price: 299 },
  'PREMIUM_VERIFY': { price: 499 },
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { propertyId, verificationType, upiId, userId } = body

    if (!propertyId || !verificationType || !userId) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    const config = verificationConfig[verificationType]
    if (!config) {
      return NextResponse.json({ error: 'Invalid verification type' }, { status: 400 })
    }

    // Check property exists and belongs to user
    const property = await db.property.findUnique({ where: { id: propertyId } })
    if (!property) {
      return NextResponse.json({ error: 'Property not found' }, { status: 404 })
    }
    if (property.ownerId !== userId) {
      return NextResponse.json({ error: 'Not your property' }, { status: 403 })
    }

    if (property.isVerified) {
      return NextResponse.json({ error: 'Property already verified' }, { status: 400 })
    }

    // Simulate UPI payment (90% success)
    const paymentSuccess = Math.random() < 0.9
    const transactionId = `VERIFY${Date.now()}`

    if (!paymentSuccess) {
      await db.paymentOrder.create({
        data: {
          userId,
          propertyId,
          orderType: 'VERIFICATION',
          amount: config.price,
          status: 'FAILED',
          transactionId,
          upiId: upiId || '',
          metadata: JSON.stringify({ verificationType }),
        },
      })
      return NextResponse.json({ error: 'Payment failed. Please try again.' }, { status: 400 })
    }

    // Update property as verified
    await db.property.update({
      where: { id: propertyId },
      data: { isVerified: true },
    })

    // Record successful payment
    await db.paymentOrder.create({
      data: {
        userId,
        propertyId,
        orderType: 'VERIFICATION',
        amount: config.price,
        status: 'COMPLETED',
        transactionId,
        upiId: upiId || '',
        metadata: JSON.stringify({ verificationType }),
      },
    })

    return NextResponse.json({
      success: true,
      message: 'Property verified successfully! Verified badge added.',
      verification: {
        propertyId,
        verificationType,
        amount: config.price,
      },
    })
  } catch (error) {
    console.error('Verify error:', error)
    return NextResponse.json({ error: 'Verification failed' }, { status: 500 })
  }
}
