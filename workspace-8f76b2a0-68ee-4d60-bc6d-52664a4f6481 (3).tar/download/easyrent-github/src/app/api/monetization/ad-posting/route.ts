import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

const adTypeConfig: Record<string, { price: number }> = {
  'FREE': { price: 0 },
  'BASIC': { price: 49 },
  'FEATURED': { price: 99 },
  'TOP_LISTING': { price: 299 },
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { propertyId, adType, upiId, userId } = body

    if (!propertyId || !adType || !userId) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    const config = adTypeConfig[adType]
    if (!config) {
      return NextResponse.json({ error: 'Invalid ad type' }, { status: 400 })
    }

    // Check user exists
    const user = await db.user.findUnique({ where: { id: userId } })
    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Check property exists and belongs to user
    const property = await db.property.findUnique({ where: { id: propertyId } })
    if (!property) {
      return NextResponse.json({ error: 'Property not found' }, { status: 404 })
    }
    if (property.ownerId !== userId) {
      return NextResponse.json({ error: 'Not your property' }, { status: 403 })
    }

    // Check free ad eligibility
    const isBrokerWithPlan = user.subscriptionPlan === 'PRO_BROKER' || user.subscriptionPlan === 'BASIC_BROKER'
    const freeAdsAllowed = isBrokerWithPlan ? 999 : 1
    const isFirstAdFree = user.freeAdsUsed < freeAdsAllowed && adType === 'FREE'

    // If not first free ad and trying to post free, charge for BASIC
    let actualAdType = adType
    let actualPrice = config.price

    if (adType === 'FREE' && !isFirstAdFree) {
      // User has used their free ad, upgrade to BASIC
      actualAdType = 'BASIC'
      actualPrice = 49
    }

    // Broker subscriptions get free posting
    if (isBrokerWithPlan) {
      actualPrice = 0
    }

    // Update property ad type
    await db.property.update({
      where: { id: propertyId },
      data: {
        adType: actualAdType,
        isFeatured: actualAdType === 'FEATURED' || actualAdType === 'TOP_LISTING',
        featuredUntil: actualAdType === 'FEATURED'
          ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
          : actualAdType === 'TOP_LISTING'
          ? new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
          : null,
      },
    })

    // Increment free ads used
    await db.user.update({
      where: { id: userId },
      data: { freeAdsUsed: { increment: 1 } },
    })

    // If paid ad, simulate payment
    if (actualPrice > 0) {
      const paymentSuccess = Math.random() < 0.9
      const transactionId = `AD${Date.now()}`

      if (!paymentSuccess) {
        await db.paymentOrder.create({
          data: {
            userId,
            propertyId,
            orderType: 'AD_POSTING',
            amount: actualPrice,
            status: 'FAILED',
            transactionId,
            upiId: upiId || '',
            metadata: JSON.stringify({ adType: actualAdType }),
          },
        })
        return NextResponse.json({ error: 'Payment failed. Please try again.' }, { status: 400 })
      }

      await db.paymentOrder.create({
        data: {
          userId,
          propertyId,
          orderType: 'AD_POSTING',
          amount: actualPrice,
          status: 'COMPLETED',
          transactionId,
          upiId: upiId || '',
          metadata: JSON.stringify({ adType: actualAdType }),
        },
      })
    }

    return NextResponse.json({
      success: true,
      message: actualPrice === 0
        ? `Ad posted as ${actualAdType} — Free!`
        : `Ad posted as ${actualAdType} — ₹${actualPrice} paid!`,
      ad: {
        propertyId,
        adType: actualAdType,
        amount: actualPrice,
        freeAdsUsed: user.freeAdsUsed + 1,
        freeAdsRemaining: Math.max(0, freeAdsAllowed - user.freeAdsUsed - 1),
      },
    })
  } catch (error) {
    console.error('Ad posting error:', error)
    return NextResponse.json({ error: 'Ad posting failed' }, { status: 500 })
  }
}
