import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const tenantId = searchParams.get('tenantId')
    const ownerId = searchParams.get('ownerId')

    const where: Record<string, unknown> = {}
    if (tenantId) where.tenantId = tenantId
    if (ownerId) {
      where.property = { ownerId }
    }

    const rentals = await db.rental.findMany({
      where,
      include: {
        property: {
          include: {
            owner: { select: { id: true, name: true, phone: true, email: true } },
          },
        },
        tenant: { select: { id: true, name: true, phone: true, email: true } },
      },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({ rentals })
  } catch (error) {
    console.error('Rentals GET error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch rentals' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { propertyId, tenantId, startDate, endDate } = body

    if (!propertyId || !tenantId || !startDate || !endDate) {
      return NextResponse.json(
        { error: 'Property, tenant, start date, and end date are required' },
        { status: 400 }
      )
    }

    const rental = await db.rental.create({
      data: {
        propertyId,
        tenantId,
        startDate,
        endDate,
        status: 'PENDING',
      },
      include: {
        property: true,
        tenant: { select: { id: true, name: true, phone: true, email: true } },
      },
    })

    return NextResponse.json({ rental }, { status: 201 })
  } catch (error) {
    console.error('Rental POST error:', error)
    return NextResponse.json(
      { error: 'Failed to create rental' },
      { status: 500 }
    )
  }
}
