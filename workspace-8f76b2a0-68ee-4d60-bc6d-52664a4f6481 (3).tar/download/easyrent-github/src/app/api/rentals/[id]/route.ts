import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { status, userId, role } = body

    if (!status) {
      return NextResponse.json(
        { error: 'Status is required' },
        { status: 400 }
      )
    }

    const rental = await db.rental.findUnique({
      where: { id },
      include: { property: true },
    })

    if (!rental) {
      return NextResponse.json(
        { error: 'Rental not found' },
        { status: 404 }
      )
    }

    if (role !== 'ADMIN' && rental.property.ownerId !== userId && rental.tenantId !== userId) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 403 }
      )
    }

    const updated = await db.rental.update({
      where: { id },
      data: { status },
      include: {
        property: {
          include: {
            owner: { select: { id: true, name: true, phone: true, email: true } },
          },
        },
        tenant: { select: { id: true, name: true, phone: true, email: true } },
      },
    })

    return NextResponse.json({ rental: updated })
  } catch (error) {
    console.error('Rental PATCH error:', error)
    return NextResponse.json(
      { error: 'Failed to update rental' },
      { status: 500 }
    )
  }
}
