import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

function simpleHash(password: string): string {
  return Buffer.from(password).toString('base64')
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, email, phone, password, aadharNo } = body

    if (!name || !email || !phone || !password) {
      return NextResponse.json(
        { error: 'Name, email, phone, and password are required' },
        { status: 400 }
      )
    }

    const existingEmail = await db.user.findUnique({ where: { email } })
    if (existingEmail) {
      return NextResponse.json(
        { error: 'Email already registered' },
        { status: 400 }
      )
    }

    const existingPhone = await db.user.findUnique({ where: { phone } })
    if (existingPhone) {
      return NextResponse.json(
        { error: 'Phone number already registered' },
        { status: 400 }
      )
    }

    const hashedPassword = simpleHash(password)

    const user = await db.user.create({
      data: {
        name,
        email,
        phone,
        password: hashedPassword,
        aadharNo: aadharNo || null,
        aadharVerified: false,
        role: 'USER',
      },
    })

    const { password: _, ...userWithoutPassword } = user
    return NextResponse.json({ user: userWithoutPassword }, { status: 201 })
  } catch (error) {
    console.error('Register error:', error)
    return NextResponse.json(
      { error: 'Registration failed' },
      { status: 500 }
    )
  }
}
