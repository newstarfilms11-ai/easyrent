import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { rentalId, amount, upiId } = body

    if (!rentalId || !amount || !upiId) {
      return NextResponse.json(
        { error: 'Rental ID, amount, and UPI ID are required' },
        { status: 400 }
      )
    }

    const rental = await db.rental.findUnique({ where: { id: rentalId } })
    if (!rental) {
      return NextResponse.json(
        { error: 'Rental not found' },
        { status: 404 }
      )
    }

    // Simulate payment
    const isSuccess = Math.random() > 0.1 // 90% success rate for demo
    const transactionId = `UPI${Date.now()}${Math.random().toString(36).substring(2, 8).toUpperCase()}`

    const payment = await db.payment.create({
      data: {
        rentalId,
        amount: parseInt(String(amount)),
        upiId,
        status: isSuccess ? 'COMPLETED' : 'FAILED',
        transactionId: isSuccess ? transactionId : null,
      },
    })

    if (isSuccess) {
      await db.rental.update({
        where: { id: rentalId },
        data: { status: 'ACTIVE', paymentId: payment.id },
      })
    }

    return NextResponse.json({ payment })
  } catch (error) {
    console.error('Payment POST error:', error)
    return NextResponse.json(
      { error: 'Payment processing failed' },
      { status: 500 }
    )
  }
}
