import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')

    const where: Record<string, unknown> = {}
    if (status) where.status = status

    const properties = await db.property.findMany({
      where,
      include: {
        owner: {
          select: { id: true, name: true, phone: true, email: true },
        },
        reviews: true,
        rentals: true,
      },
      orderBy: { createdAt: 'desc' },
    })

    const users = await db.user.findMany({
      select: {
        id: true,
        name: true,
        email: true,
        phone: true,
        aadharNo: true,
        aadharVerified: true,
        role: true,
        createdAt: true,
        _count: { select: { properties: true, reviews: true, rentalsAsTenant: true } },
      },
      orderBy: { createdAt: 'desc' },
    })

    const rentals = await db.rental.findMany({
      include: {
        property: { select: { id: true, title: true, city: true, rent: true } },
        tenant: { select: { id: true, name: true, phone: true } },
      },
      orderBy: { createdAt: 'desc' },
    })

    const payments = await db.payment.findMany({
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({ properties, users, rentals, payments })
  } catch (error) {
    console.error('Admin properties GET error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch admin data' },
      { status: 500 }
    )
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json()
    const { propertyId, status, role } = body

    if (!propertyId || !status) {
      return NextResponse.json(
        { error: 'Property ID and status are required' },
        { status: 400 }
      )
    }

    if (role !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 403 }
      )
    }

    const property = await db.property.update({
      where: { id: propertyId },
      data: { status },
      include: {
        owner: {
          select: { id: true, name: true, phone: true, email: true },
        },
      },
    })

    return NextResponse.json({ property })
  } catch (error) {
    console.error('Admin properties PATCH error:', error)
    return NextResponse.json(
      { error: 'Failed to update property status' },
      { status: 500 }
    )
  }
}
