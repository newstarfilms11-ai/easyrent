import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const totalUsers = await db.user.count()
    const totalProperties = await db.property.count()
    const pendingProperties = await db.property.count({ where: { status: 'PENDING' } })
    const approvedProperties = await db.property.count({ where: { status: 'APPROVED' } })
    const rejectedProperties = await db.property.count({ where: { status: 'REJECTED' } })
    const activeRentals = await db.rental.count({ where: { status: 'ACTIVE' } })
    const totalRentals = await db.rental.count()
    const totalPayments = await db.payment.count()
    const completedPayments = await db.payment.findMany({
      where: { status: 'COMPLETED' },
    })
    const revenue = completedPayments.reduce((sum: number, p: { amount: number }) => sum + p.amount, 0)

    return NextResponse.json({
      stats: {
        totalUsers,
        totalProperties,
        pendingProperties,
        approvedProperties,
        rejectedProperties,
        activeRentals,
        totalRentals,
        revenue,
        totalPayments,
        completedPayments: completedPayments.length,
      },
    })
  } catch (error) {
    console.error('Admin stats error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch stats' },
      { status: 500 }
    )
  }
}
