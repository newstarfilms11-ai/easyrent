import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    // Property type distribution
    const allProperties = await db.property.findMany({
      select: { type: true, status: true, createdAt: true, rent: true, city: true },
    })

    const typeDistribution: Record<string, number> = {}
    const cityDistribution: Record<string, number> = {}
    const statusDistribution: Record<string, number> = {}
    const rentByType: Record<string, { total: number; count: number }> = {}
    const monthlyData: Record<string, { properties: number; rentals: number }> = {}

    allProperties.forEach((p) => {
      typeDistribution[p.type] = (typeDistribution[p.type] || 0) + 1
      cityDistribution[p.city] = (cityDistribution[p.city] || 0) + 1
      statusDistribution[p.status] = (statusDistribution[p.status] || 0) + 1

      if (!rentByType[p.type]) rentByType[p.type] = { total: 0, count: 0 }
      rentByType[p.type].total += p.rent
      rentByType[p.type].count += 1

      const month = new Date(p.createdAt).toISOString().slice(0, 7)
      if (!monthlyData[month]) monthlyData[month] = { properties: 0, rentals: 0 }
      monthlyData[month].properties += 1
    })

    // Rental monthly data
    const allRentals = await db.rental.findMany({
      select: { createdAt: true, status: true },
    })

    allRentals.forEach((r) => {
      const month = new Date(r.createdAt).toISOString().slice(0, 7)
      if (!monthlyData[month]) monthlyData[month] = { properties: 0, rentals: 0 }
      monthlyData[month].rentals += 1
    })

    // Average rent by type
    const avgRentByType: Record<string, number> = {}
    Object.entries(rentByType).forEach(([type, data]) => {
      avgRentByType[type] = Math.round(data.total / data.count)
    })

    // Top cities by listings
    const topCities = Object.entries(cityDistribution)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 10)
      .map(([city, count]) => ({ city, count }))

    // Recent activity (last 10 items across all types)
    const recentProperties = await db.property.findMany({
      take: 5,
      orderBy: { createdAt: 'desc' },
      select: { id: true, title: true, status: true, createdAt: true, type: true,
        owner: { select: { name: true } } },
    })

    const recentUsers = await db.user.findMany({
      take: 5,
      orderBy: { createdAt: 'desc' },
      select: { id: true, name: true, email: true, createdAt: true, role: true },
    })

    const recentRentals = await db.rental.findMany({
      take: 5,
      orderBy: { createdAt: 'desc' },
      select: { id: true, status: true, createdAt: true,
        property: { select: { title: true } },
        tenant: { select: { name: true } } },
    })

    const activity = [
      ...recentProperties.map((p) => ({
        type: 'property' as const,
        title: p.title,
        subtitle: `${p.type} - ${p.status}`,
        user: p.owner.name,
        time: p.createdAt,
      })),
      ...recentUsers.map((u) => ({
        type: 'user' as const,
        title: u.name,
        subtitle: `${u.role} - ${u.email}`,
        user: u.name,
        time: u.createdAt,
      })),
      ...recentRentals.map((r) => ({
        type: 'rental' as const,
        title: r.property.title,
        subtitle: `${r.tenant.name} - ${r.status}`,
        user: r.tenant.name,
        time: r.createdAt,
      })),
    ].sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime()).slice(0, 10)

    // User growth
    const totalUsers = await db.user.count()
    const verifiedUsers = await db.user.count({ where: { aadharVerified: true } })
    const adminUsers = await db.user.count({ where: { role: 'ADMIN' } })

    return NextResponse.json({
      analytics: {
        typeDistribution,
        cityDistribution: topCities,
        statusDistribution,
        avgRentByType,
        monthlyData,
        activity,
        userStats: { total: totalUsers, verified: verifiedUsers, admins: adminUsers },
      },
    })
  } catch (error) {
    console.error('Admin analytics error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch analytics' },
      { status: 500 }
    )
  }
}
