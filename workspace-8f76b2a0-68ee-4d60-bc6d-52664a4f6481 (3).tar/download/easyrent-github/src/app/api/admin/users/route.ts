import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// PATCH - Update user (verify Aadhar, change role, delete)
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, action, role, aadharVerified } = body

    if (!userId || !action) {
      return NextResponse.json(
        { error: 'User ID and action are required' },
        { status: 400 }
      )
    }

    if (action === 'VERIFY_AADHAR') {
      const user = await db.user.update({
        where: { id: userId },
        data: { aadharVerified: true },
      })
      return NextResponse.json({ user: { id: user.id, name: user.name, aadharVerified: user.aadharVerified } })

    } else if (action === 'UNVERIFY_AADHAR') {
      const user = await db.user.update({
        where: { id: userId },
        data: { aadharVerified: false },
      })
      return NextResponse.json({ user: { id: user.id, name: user.name, aadharVerified: user.aadharVerified } })

    } else if (action === 'CHANGE_ROLE') {
      if (!role || (role !== 'USER' && role !== 'ADMIN')) {
        return NextResponse.json(
          { error: 'Valid role (USER or ADMIN) is required' },
          { status: 400 }
        )
      }
      const user = await db.user.update({
        where: { id: userId },
        data: { role },
      })
      return NextResponse.json({ user: { id: user.id, name: user.name, role: user.role } })

    } else if (action === 'DELETE') {
      // Delete user's properties first, then reviews, then rentals, then user
      await db.review.deleteMany({ where: { userId } })
      await db.payment.deleteMany({
        where: { rental: { tenantId: userId } }
      })
      await db.rental.deleteMany({ where: { tenantId: userId } })
      // Delete properties owned by user (and their reviews/rentals)
      const userProperties = await db.property.findMany({
        where: { ownerId: userId },
        select: { id: true },
      })
      for (const prop of userProperties) {
        await db.review.deleteMany({ where: { propertyId: prop.id } })
        await db.payment.deleteMany({
          where: { rental: { propertyId: prop.id } }
        })
        await db.rental.deleteMany({ where: { propertyId: prop.id } })
      }
      await db.property.deleteMany({ where: { ownerId: userId } })
      await db.user.delete({ where: { id: userId } })
      return NextResponse.json({ success: true, message: 'User deleted' })

    } else {
      return NextResponse.json(
        { error: 'Invalid action. Use: VERIFY_AADHAR, UNVERIFY_AADHAR, CHANGE_ROLE, DELETE' },
        { status: 400 }
      )
    }
  } catch (error) {
    console.error('Admin user PATCH error:', error)
    return NextResponse.json(
      { error: 'Failed to update user' },
      { status: 500 }
    )
  }
}
