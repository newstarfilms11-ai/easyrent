import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET - List all reviews with property and user info
export async function GET() {
  try {
    const reviews = await db.review.findMany({
      include: {
        user: { select: { id: true, name: true, email: true, avatar: true } },
        property: { select: { id: true, title: true, city: true, status: true } },
      },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({ reviews })
  } catch (error) {
    console.error('Admin reviews GET error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch reviews' },
      { status: 500 }
    )
  }
}

// PATCH - Delete a review (moderation)
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json()
    const { reviewId, action } = body

    if (!reviewId || !action) {
      return NextResponse.json(
        { error: 'Review ID and action are required' },
        { status: 400 }
      )
    }

    if (action === 'DELETE') {
      await db.review.delete({ where: { id: reviewId } })
      return NextResponse.json({ success: true, message: 'Review deleted' })
    }

    return NextResponse.json(
      { error: 'Invalid action. Use: DELETE' },
      { status: 400 }
    )
  } catch (error) {
    console.error('Admin reviews PATCH error:', error)
    return NextResponse.json(
      { error: 'Failed to update review' },
      { status: 500 }
    )
  }
}
