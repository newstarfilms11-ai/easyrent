import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const property = await db.property.findUnique({
      where: { id },
      include: {
        owner: {
          select: { id: true, name: true, phone: true, email: true, avatar: true },
        },
        reviews: {
          include: {
            user: { select: { id: true, name: true, avatar: true } },
          },
          orderBy: { createdAt: 'desc' },
        },
        rentals: {
          include: {
            tenant: { select: { id: true, name: true, phone: true } },
          },
        },
      },
    })

    if (!property) {
      return NextResponse.json(
        { error: 'Property not found' },
        { status: 404 }
      )
    }

    const avgRating = property.reviews.length > 0
      ? property.reviews.reduce((sum: number, r: { rating: number }) => sum + r.rating, 0) / property.reviews.length
      : 0

    return NextResponse.json({
      property: {
        ...property,
        avgRating: Math.round(avgRating * 10) / 10,
        reviewCount: property.reviews.length,
      },
    })
  } catch (error) {
    console.error('Property GET error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch property' },
      { status: 500 }
    )
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { userId, role, ...updateData } = body

    const property = await db.property.findUnique({ where: { id } })
    if (!property) {
      return NextResponse.json(
        { error: 'Property not found' },
        { status: 404 }
      )
    }

    if (property.ownerId !== userId && role !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 403 }
      )
    }

    const data: Record<string, unknown> = { ...updateData }
    if (updateData.rent) data.rent = parseInt(String(updateData.rent))
    if (updateData.deposit) data.deposit = parseInt(String(updateData.deposit))
    if (updateData.lat) data.lat = parseFloat(String(updateData.lat))
    if (updateData.lng) data.lng = parseFloat(String(updateData.lng))

    const updated = await db.property.update({
      where: { id },
      data,
      include: {
        owner: {
          select: { id: true, name: true, phone: true, email: true },
        },
      },
    })

    return NextResponse.json({ property: updated })
  } catch (error) {
    console.error('Property PATCH error:', error)
    return NextResponse.json(
      { error: 'Failed to update property' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const role = searchParams.get('role')

    const property = await db.property.findUnique({ where: { id } })
    if (!property) {
      return NextResponse.json(
        { error: 'Property not found' },
        { status: 404 }
      )
    }

    if (property.ownerId !== userId && role !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 403 }
      )
    }

    await db.review.deleteMany({ where: { propertyId: id } })
    await db.rental.deleteMany({ where: { propertyId: id } })
    await db.property.delete({ where: { id } })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Property DELETE error:', error)
    return NextResponse.json(
      { error: 'Failed to delete property' },
      { status: 500 }
    )
  }
}
