import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const city = searchParams.get('city')
    const type = searchParams.get('type')
    const minRent = searchParams.get('minRent')
    const maxRent = searchParams.get('maxRent')
    const sort = searchParams.get('sort') || 'newest'

    const ownerId = searchParams.get('ownerId')
    const showAll = searchParams.get('showAll')

    const where: Record<string, unknown> = {}

    // If ownerId is provided, show that user's properties (including PENDING)
    // Otherwise, only show APPROVED properties
    if (ownerId) {
      where.ownerId = ownerId
      if (!showAll) {
        where.status = 'APPROVED'
      }
    } else {
      where.status = 'APPROVED'
    }

    if (city) {
      where.city = { contains: city, mode: 'insensitive' }
    }
    if (type) {
      where.type = type
    }
    if (minRent || maxRent) {
      where.rent = {}
      if (minRent) (where.rent as Record<string, unknown>).gte = parseInt(minRent)
      if (maxRent) (where.rent as Record<string, unknown>).lte = parseInt(maxRent)
    }

    const orderBy: Record<string, string> =
      sort === 'rent-low' ? { rent: 'asc' } :
      sort === 'rent-high' ? { rent: 'desc' } :
      { createdAt: 'desc' }

    const properties = await db.property.findMany({
      where,
      orderBy,
      include: {
        owner: {
          select: { id: true, name: true, phone: true, email: true, avatar: true },
        },
        reviews: {
          include: {
            user: { select: { id: true, name: true, avatar: true } },
          },
        },
      },
    })

    const propertiesWithRating = properties.map((p) => {
      const avgRating = p.reviews.length > 0
        ? p.reviews.reduce((sum: number, r: { rating: number }) => sum + r.rating, 0) / p.reviews.length
        : 0
      return {
        ...p,
        avgRating: Math.round(avgRating * 10) / 10,
        reviewCount: p.reviews.length,
      }
    })

    return NextResponse.json({ properties: propertiesWithRating })
  } catch (error) {
    console.error('Properties GET error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch properties' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      title, description, type, rent, deposit, address, city, state,
      lat, lng, images, video, availableFrom, availableTo, ownerId,
    } = body

    if (!title || !type || !rent || !deposit || !address || !city || !state || !ownerId || !availableFrom) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    const property = await db.property.create({
      data: {
        title,
        description: description || '',
        type,
        rent: parseInt(String(rent)),
        deposit: parseInt(String(deposit)),
        address,
        city,
        state,
        lat: lat ? parseFloat(String(lat)) : null,
        lng: lng ? parseFloat(String(lng)) : null,
        images: images || '[]',
        video: video || null,
        availableFrom,
        availableTo: availableTo || null,
        status: 'PENDING',
        ownerId,
      },
      include: {
        owner: {
          select: { id: true, name: true, phone: true, email: true },
        },
      },
    })

    return NextResponse.json({ property }, { status: 201 })
  } catch (error) {
    console.error('Properties POST error:', error)
    return NextResponse.json(
      { error: 'Failed to create property' },
      { status: 500 }
    )
  }
}
