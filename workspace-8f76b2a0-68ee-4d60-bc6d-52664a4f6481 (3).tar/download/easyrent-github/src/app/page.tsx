'use client'

import { useState, useEffect, useCallback } from 'react'
import { useStore, Property, Rental } from '@/components/store'
import Navbar from '@/components/Navbar'
import MobileNav from '@/components/MobileNav'
import PropertyCard from '@/components/PropertyCard'
import PropertyForm from '@/components/PropertyForm'
import PropertyDetail from '@/components/PropertyDetail'
import AdminPanel from '@/components/AdminPanel'
import AuthForms from '@/components/AuthForms'
import GoogleAd from '@/components/GoogleAd'
import RentalCard from '@/components/RentalCard'
import PricingPage from '@/components/PricingPage'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Building2, Home, Store, Warehouse, Bed, Star, ArrowRight,
  Search, MapPin, Shield, Users, TrendingUp, ChevronRight,
  Plus, Trash2, Edit, Eye, CalendarRange, Navigation, Sparkles,
  IndianRupee, Loader2, Rocket, Crown, Zap, Award, CreditCard, Phone, MessageCircle,
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

const typeIcons: Record<string, React.ElementType> = {
  ROOM: Bed,
  PG: Building2,
  HOUSE: Home,
  SHOP: Store,
  GARAGE: Warehouse,
}

const typeLabels: Record<string, string> = {
  ROOM: 'कमरा / Room',
  PG: 'PG / Paying Guest',
  HOUSE: 'मकान / House',
  SHOP: 'दुकान / Shop',
  GARAGE: 'गैराज / Garage',
}

// ========== SHIMMER SKELETON ==========
function PropertySkeleton() {
  return (
    <Card className="overflow-hidden">
      <div className="aspect-[4/3] bg-gradient-to-r from-gray-200 via-gray-100 to-gray-200 animate-[shimmer_1.5s_infinite] rounded-none" />
      <CardContent className="p-4 space-y-3">
        <div className="h-5 bg-gradient-to-r from-gray-200 via-gray-100 to-gray-200 animate-[shimmer_1.5s_infinite] rounded w-3/4" />
        <div className="h-4 bg-gradient-to-r from-gray-100 via-gray-50 to-gray-100 animate-[shimmer_1.5s_infinite] rounded w-1/2" />
        <div className="flex items-center justify-between">
          <div className="h-5 bg-gradient-to-r from-emerald-100 via-emerald-50 to-emerald-100 animate-[shimmer_1.5s_infinite] rounded w-20" />
          <div className="h-4 bg-gradient-to-r from-gray-100 via-gray-50 to-gray-100 animate-[shimmer_1.5s_infinite] rounded w-12" />
        </div>
      </CardContent>
    </Card>
  )
}

// ========== HOME VIEW ==========
function HomeView() {
  const { currentUser, setCurrentView, setSearchFilters } = useStore()
  const [featured, setFeatured] = useState<Property[]>([])
  const [allProperties, setAllProperties] = useState<Property[]>([])
  const [loading, setLoading] = useState(true)
  const [searchCity, setSearchCity] = useState('')
  const [detectingLocation, setDetectingLocation] = useState(false)

  useEffect(() => {
    fetchProperties()
  }, [])

  const fetchProperties = async () => {
    try {
      const res = await fetch('/api/properties?sort=newest')
      const data = await res.json()
      if (res.ok) {
        const props = data.properties || []
        setAllProperties(props)
        // Featured = isFeatured or TOP_LISTING or FEATURED adType
        const featuredProps = props.filter((p: Property) => p.isFeatured || p.adType === 'FEATURED' || p.adType === 'TOP_LISTING')
        setFeatured(featuredProps.length > 0 ? featuredProps.slice(0, 6) : props.slice(0, 6))
      }
    } catch {
      // ignore
    } finally {
      setLoading(false)
    }
  }

  const handleTypeClick = (type: string) => {
    setSearchFilters({ type })
    setCurrentView('listings')
  }

  const handleSearch = () => {
    setSearchFilters({ city: searchCity })
    setCurrentView('listings')
  }

  const handleUseCurrentLocation = () => {
    if (!navigator.geolocation) return
    setDetectingLocation(true)
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords
        try {
          const res = await fetch(
            `https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json&addressdetails=1`,
            { headers: { 'Accept-Language': 'en' } }
          )
          const data = await res.json()
          const city = data?.address?.city || data?.address?.town || data?.address?.village || data?.address?.district || ''
          if (city) {
            setSearchCity(city)
            setSearchFilters({ city })
            setCurrentView('listings')
          }
        } catch {
          setCurrentView('listings')
        } finally {
          setDetectingLocation(false)
        }
      },
      () => {
        setDetectingLocation(false)
        setCurrentView('listings')
      },
      { timeout: 10000 }
    )
  }

  return (
    <div className="pb-20 md:pb-0">
      {/* Hero - Ultra Compact */}
      <section className="relative bg-gradient-to-br from-emerald-600 via-emerald-700 to-teal-800 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-2 left-8 w-32 h-32 rounded-full bg-white/20 blur-3xl" />
          <div className="absolute bottom-2 right-8 w-48 h-48 rounded-full bg-white/10 blur-3xl" />
        </div>
        <div className="max-w-7xl mx-auto px-4 py-3 sm:py-4 relative z-10">
          <div className="max-w-2xl mx-auto text-center">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold mb-1.5 leading-tight">
              Ghar, Dukan, Kamra — <span className="text-emerald-200">Sab Rent Par!</span>
            </h1>
            <p className="text-xs sm:text-sm text-emerald-100 mb-3">
              Find rooms, PGs, houses, shops & garages for rent across India.
            </p>

            {/* Search Bar */}
            <div className="bg-white rounded-xl p-2 shadow-xl flex flex-col sm:flex-row gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search by city..."
                  value={searchCity}
                  onChange={(e) => setSearchCity(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                  className="pl-9 border-0 focus-visible:ring-0 focus-visible:ring-offset-0 text-gray-800 h-10"
                />
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={handleUseCurrentLocation}
                  variant="outline"
                  className="border-gray-200 text-gray-600 hover:bg-emerald-50 hover:text-emerald-700 h-10 gap-1"
                  disabled={detectingLocation}
                >
                  {detectingLocation ? <Loader2 className="w-4 h-4 animate-spin" /> : <Navigation className="w-4 h-4" />}
                  <span className="hidden sm:inline text-xs">Location</span>
                </Button>
                <Button
                  onClick={handleSearch}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white h-10 px-6 font-semibold"
                >
                  <Search className="w-4 h-4 sm:mr-1" /> <span className="hidden sm:inline">Search</span>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Property Types - Compact */}
      <section className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg sm:text-xl font-bold text-gray-900">Browse by Type</h2>
        </div>
        <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
          {Object.entries(typeLabels).map(([type, label]) => {
            const Icon = typeIcons[type]
            return (
              <button
                key={type}
                onClick={() => handleTypeClick(type)}
                className="flex flex-col items-center gap-2 min-w-[72px] p-3 rounded-xl bg-white border border-gray-100 hover:border-emerald-300 hover:shadow-md transition-all duration-200 group"
              >
                <div className="w-10 h-10 rounded-full bg-emerald-50 flex items-center justify-center group-hover:bg-emerald-100 transition-colors">
                  <Icon className="w-5 h-5 text-emerald-600" />
                </div>
                <span className="text-xs font-medium text-gray-700 whitespace-nowrap">{label.split(' / ')[1] || label}</span>
              </button>
            )
          })}
        </div>
      </section>

      {/* Featured / Premium Properties */}
      {featured.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 py-2">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Crown className="w-5 h-5 text-amber-500" />
              <h2 className="text-lg sm:text-xl font-bold text-gray-900">Featured Properties</h2>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setCurrentView('listings')}
              className="text-emerald-600 hover:text-emerald-700"
            >
              View All <ArrowRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {[1, 2, 3].map((i) => (
                <PropertySkeleton key={i} />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {featured.map((property) => (
                <PropertyCard key={property.id} property={property} onClick={(id) => {
                  useStore.getState().setSelectedPropertyId(id)
                  useStore.getState().setCurrentView('detail')
                }} />
              ))}
            </div>
          )}
        </section>
      )}

      {/* Latest Listings - Always Shows */}
      <section className="max-w-7xl mx-auto px-4 py-2">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg sm:text-xl font-bold text-gray-900">Latest Listings</h2>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setCurrentView('listings')}
            className="text-emerald-600 hover:text-emerald-700"
          >
            View All <ArrowRight className="w-4 h-4 ml-1" />
          </Button>
        </div>
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <PropertySkeleton key={i} />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
            {allProperties.slice(0, 6).map((property) => (
              <PropertyCard key={property.id} property={property} onClick={(id) => {
                useStore.getState().setSelectedPropertyId(id)
                useStore.getState().setCurrentView('detail')
              }} />
            ))}
          </div>
        )}
      </section>

      {/* Google Ad */}
      <div className="max-w-7xl mx-auto px-4 my-4">
        <GoogleAd slot="horizontal" />
      </div>

      {/* Post Ad CTA - Big Attractive with Glow */}
      <section className="max-w-7xl mx-auto px-4 py-3">
        <button
          onClick={() => setCurrentView(currentUser ? 'add-property' : 'login')}
          className="w-full bg-gradient-to-r from-emerald-400 via-emerald-500 to-teal-600 text-white rounded-2xl p-5 sm:p-7 flex items-center justify-between hover:shadow-2xl hover:scale-[1.02] transition-all duration-300 group shadow-lg relative overflow-hidden"
          style={{ boxShadow: '0 8px 32px rgba(16, 185, 129, 0.3)' }}
        >
          {/* Animated background pulse */}
          <div className="absolute inset-0 bg-white/5 animate-pulse" />
          <div className="flex items-center gap-4 relative z-10">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-white/20 flex items-center justify-center group-hover:bg-white/30 transition-colors">
              <Sparkles className="w-7 h-7 sm:w-8 sm:h-8" />
            </div>
            <div className="text-left">
              <h3 className="text-xl sm:text-3xl font-bold">Post Your Ad - Free!</h3>
              <p className="text-emerald-100 text-xs sm:text-sm">List your property in 2 minutes. Room, PG, House, Shop, Garage</p>
            </div>
          </div>
          <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-white/20 flex items-center justify-center group-hover:bg-white/30 transition-all relative z-10 group-hover:scale-110">
            <Plus className="w-6 h-6 sm:w-7 sm:h-7" />
          </div>
        </button>
      </section>

      {/* Monetization CTA - Earn Money */}
      <section className="max-w-7xl mx-auto px-4 py-2">
        <button
          onClick={() => setCurrentView('pricing')}
          className="w-full bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 text-white rounded-2xl p-5 flex items-center justify-between hover:shadow-xl hover:scale-[1.01] transition-all duration-300 group"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center group-hover:bg-white/30 transition-colors">
              <IndianRupee className="w-6 h-6" />
            </div>
            <div className="text-left">
              <h3 className="text-lg sm:text-xl font-bold">Earn Money with EasyRent</h3>
              <p className="text-amber-100 text-sm">Featured Ads, Broker Plans, Verification — ₹30K-₹1L/month</p>
            </div>
          </div>
          <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
        </button>
      </section>

      {/* How it Works - Compact */}
      <section className="bg-gray-50 py-8 mt-4">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-lg sm:text-xl font-bold text-gray-900 text-center mb-6">
            How EasyRent Works
          </h2>
          <div className="grid grid-cols-3 gap-4 sm:gap-8">
            {[
              { step: '1', title: 'Search & Find', desc: 'Browse verified listings. Filter by type, rent, location.', icon: Search },
              { step: '2', title: 'Connect & Visit', desc: 'Contact owner directly. Schedule a visit.', icon: MapPin },
              { step: '3', title: 'Rent & Move In', desc: 'Secure UPI payment & move in!', icon: Shield },
            ].map((item) => (
              <div key={item.step} className="text-center">
                <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-emerald-600 text-white flex items-center justify-center mx-auto mb-2 text-lg sm:text-xl font-bold">
                  {item.step}
                </div>
                <h3 className="text-sm sm:text-base font-semibold text-gray-900 mb-1">{item.title}</h3>
                <p className="text-gray-500 text-xs sm:text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { value: '10,000+', label: 'Properties', icon: Building2 },
            { value: '25,000+', label: 'Tenants', icon: Users },
            { value: '50+', label: 'Cities', icon: MapPin },
            { value: '₹5Cr+', label: 'Transacted', icon: TrendingUp },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <stat.icon className="w-6 h-6 text-emerald-600 mx-auto mb-1" />
              <div className="text-xl font-bold text-gray-900">{stat.value}</div>
              <div className="text-xs text-gray-500">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* WhatsApp Contact Banner - EasyRent Office */}
      <section className="max-w-7xl mx-auto px-4 py-4">
        <a
          href="https://wa.me/918968541628?text=Hi%20EasyRent!%20I%20need%20help%20with%20rental%20listing.%20Please%20assist%20me."
          target="_blank"
          rel="noopener noreferrer"
          className="block bg-gradient-to-r from-green-500 via-green-600 to-emerald-700 text-white rounded-2xl p-5 hover:shadow-xl hover:scale-[1.01] transition-all duration-300 group"
          style={{ boxShadow: '0 6px 24px rgba(34, 197, 94, 0.25)' }}
        >
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-full bg-white/20 flex items-center justify-center group-hover:bg-white/30 transition-colors flex-shrink-0">
              <svg className="w-8 h-8" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
            </div>
            <div className="flex-1">
              <h3 className="text-lg sm:text-xl font-bold">EasyRent Office — WhatsApp Karein!</h3>
              <p className="text-green-100 text-sm">Koi bhi sawal ho? Property rent karni hai? Abhi WhatsApp pe message karein — hum help karenge!</p>
            </div>
            <div className="flex items-center gap-2 bg-white/20 rounded-full px-4 py-2 group-hover:bg-white/30 transition-colors flex-shrink-0">
              <Phone className="w-4 h-4" />
              <span className="font-bold text-sm">89685-41628</span>
            </div>
          </div>
        </a>
      </section>

      {/* CTA - Compact with Contact */}
      <section className="bg-emerald-700 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-xl sm:text-2xl font-bold mb-3">
            Ready to Find Your Perfect Rental?
          </h2>
          <p className="text-emerald-200 mb-4 text-sm max-w-lg mx-auto">
            Whether you&apos;re looking for a room, PG, house, shop, or garage — EasyRent has it all.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center mb-5">
            <Button
              onClick={() => setCurrentView('listings')}
              size="lg"
              className="bg-white text-emerald-700 hover:bg-emerald-50 font-semibold"
            >
              Browse Listings
            </Button>
            <Button
              onClick={() => setCurrentView('pricing')}
              size="lg"
              variant="outline"
              className="border-white/40 text-white hover:bg-white/10"
            >
              <CreditCard className="w-4 h-4 mr-1" /> Pricing & Plans
            </Button>
          </div>
          {/* Contact Info */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-3 border-t border-emerald-600">
            <a href="tel:+918968541628" className="flex items-center gap-2 text-emerald-200 hover:text-white transition-colors">
              <Phone className="w-4 h-4" />
              <span className="font-semibold">89685-41628</span>
            </a>
            <a href="https://wa.me/918968541628?text=Hi%20EasyRent!%20I%20need%20help%20with%20rental%20listing.%20Please%20assist%20me." target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-emerald-200 hover:text-white transition-colors">
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
              <span className="font-semibold">WhatsApp</span>
            </a>
          </div>
        </div>
      </section>
    </div>
  )
}

// ========== LISTINGS VIEW ==========
function ListingsView() {
  const { searchFilters, setSearchFilters, setSelectedPropertyId, setCurrentView } = useStore()
  const [properties, setProperties] = useState<Property[]>([])
  const [loading, setLoading] = useState(true)
  const [showFilters, setShowFilters] = useState(false)

  const fetchProperties = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (searchFilters.city) params.set('city', searchFilters.city)
      if (searchFilters.type) params.set('type', searchFilters.type)
      if (searchFilters.minRent) params.set('minRent', String(searchFilters.minRent))
      if (searchFilters.maxRent) params.set('maxRent', String(searchFilters.maxRent))
      if (searchFilters.sort) params.set('sort', searchFilters.sort)

      const res = await fetch(`/api/properties?${params.toString()}`)
      const data = await res.json()
      if (res.ok) {
        setProperties(data.properties || [])
      }
    } catch {
      // ignore
    } finally {
      setLoading(false)
    }
  }, [searchFilters])

  useEffect(() => {
    fetchProperties()
  }, [fetchProperties])

  const clearFilters = () => {
    setSearchFilters({ city: '', type: '', minRent: null, maxRent: null, sort: 'newest' })
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 pb-24 md:pb-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Property Listings</h1>
          <p className="text-gray-500 text-sm">{properties.length} properties found</p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowFilters(!showFilters)}
            className="md:hidden"
          >
            <Search className="w-4 h-4 mr-1" /> Filters
          </Button>
          <Select
            value={searchFilters.sort}
            onValueChange={(val) => setSearchFilters({ sort: val })}
          >
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest First</SelectItem>
              <SelectItem value="rent-low">Rent: Low to High</SelectItem>
              <SelectItem value="rent-high">Rent: High to Low</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex gap-6">
        {/* Filters sidebar - desktop */}
        <aside className={`${showFilters ? 'block' : 'hidden'} md:block w-full md:w-64 flex-shrink-0`}>
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Filters</CardTitle>
                <button onClick={clearFilters} className="text-xs text-emerald-600 hover:text-emerald-700">
                  Clear All
                </button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-1 block">City</label>
                <Input
                  placeholder="Search city..."
                  value={searchFilters.city}
                  onChange={(e) => setSearchFilters({ city: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Property Type</label>
                <Select
                  value={searchFilters.type}
                  onValueChange={(val) => setSearchFilters({ type: val === 'ALL' ? '' : val })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="All Types" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ALL">All Types</SelectItem>
                    <SelectItem value="ROOM">कमरा / Room</SelectItem>
                    <SelectItem value="PG">PG / Paying Guest</SelectItem>
                    <SelectItem value="HOUSE">मकान / House</SelectItem>
                    <SelectItem value="SHOP">दुकान / Shop</SelectItem>
                    <SelectItem value="GARAGE">गैराज / Garage</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Min Rent (₹)</label>
                <Input
                  type="number"
                  placeholder="0"
                  value={searchFilters.minRent || ''}
                  onChange={(e) => setSearchFilters({ minRent: e.target.value ? parseInt(e.target.value) : null })}
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Max Rent (₹)</label>
                <Input
                  type="number"
                  placeholder="100000"
                  value={searchFilters.maxRent || ''}
                  onChange={(e) => setSearchFilters({ maxRent: e.target.value ? parseInt(e.target.value) : null })}
                />
              </div>
              <Button
                onClick={fetchProperties}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                Apply Filters
              </Button>
            </CardContent>
          </Card>
        </aside>

        {/* Properties grid */}
        <div className="flex-1">
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <PropertySkeleton key={i} />
              ))}
            </div>
          ) : properties.length === 0 ? (
            <Card className="p-12 text-center">
              <Building2 className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-700">No properties found</h3>
              <p className="text-gray-500 mt-1">Try adjusting your filters</p>
              <Button onClick={clearFilters} variant="outline" className="mt-4">
                Clear Filters
              </Button>
            </Card>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {properties.map((property, index) => (
                <div key={property.id}>
                  <PropertyCard
                    property={property}
                    onClick={(id) => {
                      setSelectedPropertyId(id)
                      setCurrentView('detail')
                    }}
                  />
                  {/* Ad banner after every 4th card */}
                  {(index + 1) % 4 === 0 && index < properties.length - 1 && (
                    <div className="mt-6">
                      <GoogleAd />
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

// ========== BOOST DIALOG ==========
function BoostDialog({ propertyId, open, onClose }: { propertyId: string; open: boolean; onClose: () => void }) {
  const { currentUser } = useStore()
  const { toast } = useToast()
  const [upiId, setUpiId] = useState('')
  const [loading, setLoading] = useState(false)

  const boosts = [
    { id: '3_DAY', name: '3 Days', price: 99, days: 3 },
    { id: '7_DAY', name: '7 Days', price: 199, days: 7, highlight: true },
    { id: '30_DAY', name: '30 Days', price: 599, days: 30 },
  ]

  const handleBoost = async (boostId: string, price: number) => {
    if (!currentUser || !upiId) return
    setLoading(true)
    try {
      const res = await fetch('/api/monetization/boost', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ propertyId, boostType: boostId, upiId, userId: currentUser.id }),
      })
      const data = await res.json()
      if (res.ok) {
        toast({ title: 'Boost activated! 🚀', description: data.message })
        onClose()
      } else {
        toast({ title: 'Boost failed', description: data.error, variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Error', variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Rocket className="w-5 h-5 text-amber-500" /> Boost Your Listing
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <p className="text-sm text-gray-500">Push your property to the top — get more enquiries!</p>
          <div>
            <label className="text-sm font-medium mb-1 block">UPI ID</label>
            <Input placeholder="yourname@upi" value={upiId} onChange={(e) => setUpiId(e.target.value)} />
          </div>
          <div className="space-y-2">
            {boosts.map((b) => (
              <button
                key={b.id}
                onClick={() => handleBoost(b.id, b.price)}
                disabled={loading || !upiId}
                className={`w-full p-3 rounded-xl border-2 flex items-center justify-between transition-all ${
                  b.highlight ? 'border-emerald-500 bg-emerald-50' : 'border-gray-200 hover:border-emerald-300'
                } ${loading || !upiId ? 'opacity-50' : ''}`}
              >
                <div className="text-left">
                  <div className="font-semibold">{b.name} Boost</div>
                  <div className="text-xs text-gray-500">{b.days} days on top</div>
                </div>
                <div className="font-bold text-emerald-700">₹{b.price}</div>
              </button>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

// ========== DASHBOARD VIEW ==========
function DashboardView() {
  const { currentUser, setSelectedPropertyId, setCurrentView, setEditingProperty } = useStore()
  const { toast } = useToast()
  const [myProperties, setMyProperties] = useState<Property[]>([])
  const [myReviews, setMyReviews] = useState<unknown[]>([])
  const [loading, setLoading] = useState(true)
  const [boostDialogProperty, setBoostDialogProperty] = useState<string | null>(null)
  const [monetizationStats, setMonetizationStats] = useState<{
    totalSpent: number
    activeBoosts: number
    subscriptionPlan: string
    subscriptionExpiry: string | null
    freeAdsUsed: number
    freeAdsRemaining: number
  } | null>(null)

  const fetchMyData = useCallback(async () => {
    if (!currentUser) return
    try {
      const [propsRes, statsRes] = await Promise.all([
        fetch(`/api/properties?ownerId=${currentUser.id}&showAll=true`),
        fetch(`/api/monetization/stats?userId=${currentUser.id}`),
      ])

      const propsData = await propsRes.json()
      if (propsRes.ok) {
        const mine = propsData.properties || []
        setMyProperties(mine)
        const reviews: unknown[] = []
        mine.forEach((p: Property) => {
          if (p.reviews) {
            p.reviews.forEach((r: unknown) => {
              reviews.push({ ...(r as Record<string, unknown>), propertyTitle: p.title })
            })
          }
        })
        setMyReviews(reviews)
      }

      if (statsRes.ok) {
        const stats = await statsRes.json()
        setMonetizationStats(stats)
      }
    } catch {
      // ignore
    } finally {
      setLoading(false)
    }
  }, [currentUser])

  useEffect(() => {
    fetchMyData()
  }, [fetchMyData])

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this property?')) return
    try {
      const res = await fetch(`/api/properties/${id}?userId=${currentUser?.id}`, { method: 'DELETE' })
      if (res.ok) {
        toast({ title: 'Property deleted' })
        fetchMyData()
      }
    } catch {
      toast({ title: 'Delete failed', variant: 'destructive' })
    }
  }

  const handleVerify = async (propertyId: string) => {
    if (!currentUser) return
    const upiId = prompt('Enter UPI ID for verification payment:')
    if (!upiId) return
    try {
      const res = await fetch('/api/monetization/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ propertyId, verificationType: 'VIDEO_VERIFY', upiId, userId: currentUser.id }),
      })
      const data = await res.json()
      if (res.ok) {
        toast({ title: 'Property Verified! ✅', description: data.message })
        fetchMyData()
      } else {
        toast({ title: 'Verification failed', description: data.error, variant: 'destructive' })
      }
    } catch {
      toast({ title: 'Error', variant: 'destructive' })
    }
  }

  if (!currentUser) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Card className="p-8 text-center">
          <Building2 className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-gray-700">Please Login</h2>
          <Button onClick={() => setCurrentView('login')} className="mt-4 bg-emerald-600 hover:bg-emerald-700 text-white">
            Login
          </Button>
        </Card>
      </div>
    )
  }

  const planName = monetizationStats?.subscriptionPlan || currentUser.subscriptionPlan || 'FREE'
  const isBroker = planName === 'PRO_BROKER' || planName === 'BASIC_BROKER'
  const planLabel = planName === 'PRO_BROKER' ? 'Pro Broker' : planName === 'BASIC_BROKER' ? 'Basic Broker' : 'Free User'

  return (
    <div className="max-w-5xl mx-auto px-4 py-6 pb-24 md:pb-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">My Dashboard</h1>
          <p className="text-gray-500 text-sm">Welcome, {currentUser.name}</p>
        </div>
        <Button
          onClick={() => setCurrentView('add-property')}
          className="bg-emerald-600 hover:bg-emerald-700 text-white"
        >
          <Plus className="w-4 h-4 mr-1" /> Add Property
        </Button>
      </div>

      {/* User Info Card */}
      <Card className="mb-6">
        <CardContent className="p-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center">
              <span className="text-2xl font-bold text-emerald-700">
                {currentUser.name.charAt(0)}
              </span>
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-lg">{currentUser.name}</h3>
              <p className="text-sm text-gray-500">{currentUser.email}</p>
              <p className="text-sm text-gray-500">{currentUser.phone}</p>
            </div>
            <div className="text-right">
              <Badge variant={currentUser.role === 'ADMIN' ? 'default' : 'secondary'}>
                {currentUser.role}
              </Badge>
              <div className="mt-1 flex items-center gap-2">
                <Badge className={isBroker ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-600'}>
                  <Crown className="w-3 h-3 mr-1" /> {planLabel}
                </Badge>
                {currentUser.aadharVerified && (
                  <span className="text-xs text-emerald-600 flex items-center gap-1">
                    <Shield className="w-3 h-3" /> Verified
                  </span>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Monetization Summary */}
      <Card className="mb-6 bg-gradient-to-r from-emerald-50 to-teal-50 border-emerald-200">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-emerald-800 flex items-center gap-2">
              <IndianRupee className="w-5 h-5" /> Monetization
            </h3>
            <Button size="sm" variant="outline" className="border-emerald-300 text-emerald-700" onClick={() => setCurrentView('pricing')}>
              <CreditCard className="w-3 h-3 mr-1" /> View Plans
            </Button>
          </div>          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-white rounded-lg p-3 text-center">
              <div className="text-xs text-gray-500">Current Plan</div>
              <div className="font-bold text-emerald-700">{planLabel}</div>
            </div>
            <div className="bg-white rounded-lg p-3 text-center">
              <div className="text-xs text-gray-500">Free Ads Left</div>
              <div className="font-bold text-emerald-700">{monetizationStats?.freeAdsRemaining ?? (isBroker ? '∞' : '1')}</div>
            </div>
            <div className="bg-white rounded-lg p-3 text-center">
              <div className="text-xs text-gray-500">Active Boosts</div>
              <div className="font-bold text-amber-600">{monetizationStats?.activeBoosts || 0}</div>
            </div>
            <div className="bg-white rounded-lg p-3 text-center">
              <div className="text-xs text-gray-500">Total Spent</div>
              <div className="font-bold text-gray-700">₹{monetizationStats?.totalSpent || 0}</div>
            </div>
          </div>
          {!isBroker && (
            <button
              onClick={() => setCurrentView('pricing')}
              className="w-full mt-3 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-lg p-2.5 text-sm font-semibold hover:shadow-md transition-all flex items-center justify-center gap-2"
            >
              <Crown className="w-4 h-4" /> Upgrade to Broker Plan — ₹499/mo
            </button>
          )}
        </CardContent>
      </Card>

      {/* Need Help? WhatsApp Us */}
      <a
        href="https://wa.me/918968541628?text=Hi%20EasyRent!%20I%20need%20help%20with%20my%20account.%20Please%20assist%20me."
        target="_blank"
        rel="noopener noreferrer"
        className="block mb-6 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-xl p-4 hover:shadow-lg hover:scale-[1.01] transition-all group"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center group-hover:bg-white/30 transition-colors flex-shrink-0">
            <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
            </svg>
          </div>
          <div className="flex-1">
            <h3 className="font-bold text-sm">Need Help? WhatsApp Karein!</h3>
            <p className="text-green-100 text-xs">EasyRent Office: 89685-41628 — Koi bhi problem ho, hum help karenge</p>
          </div>
          <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform flex-shrink-0" />
        </div>
      </a>

      <Tabs defaultValue="properties">
        <TabsList className="w-full">
          <TabsTrigger value="properties" className="flex-1">
            My Properties ({myProperties.length})
          </TabsTrigger>
          <TabsTrigger value="reviews" className="flex-1">
            Reviews ({myReviews.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="properties" className="mt-4">
          {loading ? (
            <div className="space-y-4">
              {[1, 2].map((i) => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-4"><div className="h-20 bg-gray-100 rounded" /></CardContent>
                </Card>
              ))}
            </div>
          ) : myProperties.length === 0 ? (
            <Card className="p-8 text-center">
              <Building2 className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">No properties listed yet</p>
              <Button
                onClick={() => setCurrentView('add-property')}
                className="mt-4 bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                <Plus className="w-4 h-4 mr-1" /> Post Your First Ad
              </Button>
            </Card>
          ) : (
            <div className="space-y-3">
              {myProperties.map((p) => (
                <Card key={p.id} className={p.isFeatured ? 'ring-1 ring-emerald-300' : ''}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1 flex-wrap">
                          <h3 className="font-semibold truncate">{p.title}</h3>
                          <Badge variant={p.status === 'APPROVED' ? 'default' : p.status === 'PENDING' ? 'secondary' : 'destructive'}>
                            {p.status}
                          </Badge>
                          {p.isFeatured && (
                            <Badge className="bg-amber-100 text-amber-700 text-[10px]">
                              <Zap className="w-2.5 h-2.5 mr-0.5" /> Featured
                            </Badge>
                          )}
                          {p.isVerified && (
                            <Badge className="bg-emerald-100 text-emerald-700 text-[10px]">
                              <Shield className="w-2.5 h-2.5 mr-0.5" /> Verified
                            </Badge>
                          )}
                          {p.adType && p.adType !== 'FREE' && (
                            <Badge className="bg-purple-100 text-purple-700 text-[10px]">
                              {p.adType}
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-gray-500">{p.city}, {p.state}</p>
                        <p className="text-sm text-emerald-600 font-medium">
                          ₹{p.rent.toLocaleString('en-IN')}/mo
                        </p>
                      </div>
                      <div className="flex gap-1 flex-wrap">
                        <Button size="sm" variant="ghost" onClick={() => { setSelectedPropertyId(p.id); setCurrentView('detail') }}>
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => { setEditingProperty(p); setCurrentView('edit-property') }}>
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="ghost" className="text-amber-600" onClick={() => setBoostDialogProperty(p.id)}>
                          <Rocket className="w-4 h-4" />
                        </Button>
                        {!p.isVerified && p.status === 'APPROVED' && (
                          <Button size="sm" variant="ghost" className="text-emerald-600" onClick={() => handleVerify(p.id)}>
                            <Shield className="w-4 h-4" />
                          </Button>
                        )}
                        <Button size="sm" variant="ghost" className="text-red-500" onClick={() => handleDelete(p.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="reviews" className="mt-4">
          {myReviews.length === 0 ? (
            <Card className="p-8 text-center text-gray-500">No reviews on your properties yet</Card>
          ) : (
            <div className="space-y-3">
              {(myReviews as Record<string, unknown>[]).map((r, i) => (
                <Card key={i}>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="flex">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star
                            key={star}
                            className={`w-4 h-4 ${
                              star <= (r.rating as number) ? 'fill-amber-400 text-amber-400' : 'text-gray-200'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-sm text-gray-500">on {(r.propertyTitle as string) || 'Property'}</span>
                    </div>
                    <p className="text-sm text-gray-600">{r.comment as string}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Boost Dialog */}
      {boostDialogProperty && (
        <BoostDialog
          propertyId={boostDialogProperty}
          open={!!boostDialogProperty}
          onClose={() => setBoostDialogProperty(null)}
        />
      )}
    </div>
  )
}

// ========== MY RENTALS VIEW ==========
function MyRentalsView() {
  const { currentUser } = useStore()
  const [tenantRentals, setTenantRentals] = useState<Rental[]>([])
  const [ownerRentals, setOwnerRentals] = useState<Rental[]>([])
  const [loading, setLoading] = useState(true)

  const fetchRentals = useCallback(async () => {
    if (!currentUser) return
    try {
      const [tenantRes, ownerRes] = await Promise.all([
        fetch(`/api/rentals?tenantId=${currentUser.id}`),
        fetch(`/api/rentals?ownerId=${currentUser.id}`),
      ])

      const tenantData = await tenantRes.json()
      const ownerData = await ownerRes.json()

      if (tenantRes.ok) setTenantRentals(tenantData.rentals || [])
      if (ownerRes.ok) setOwnerRentals(ownerData.rentals || [])
    } catch {
      // ignore
    } finally {
      setLoading(false)
    }
  }, [currentUser])

  useEffect(() => {
    fetchRentals()
  }, [fetchRentals])

  const handleStatusUpdate = () => {
    fetchRentals()
  }

  if (!currentUser) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Card className="p-8 text-center">
          <CalendarRange className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-gray-700">Please Login</h2>
          <Button onClick={() => useStore.getState().setCurrentView('login')} className="mt-4 bg-emerald-600 hover:bg-emerald-700 text-white">
            Login
          </Button>
        </Card>
      </div>
    )
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-6 pb-24 md:pb-6">
      <h1 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
        <CalendarRange className="w-7 h-7 text-emerald-600" /> My Rentals
      </h1>

      {loading ? (
        <div className="space-y-4">
          {[1, 2].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-4"><div className="h-20 bg-gray-100 rounded" /></CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Tabs defaultValue="tenant">
          <TabsList className="w-full">
            <TabsTrigger value="tenant" className="flex-1">
              As Tenant ({tenantRentals.length})
            </TabsTrigger>
            <TabsTrigger value="owner" className="flex-1">
              As Owner ({ownerRentals.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="tenant" className="mt-4">
            {tenantRentals.length === 0 ? (
              <Card className="p-8 text-center text-gray-500">
                No rental applications yet
              </Card>
            ) : (
              <div className="space-y-3">
                {tenantRentals.map((r) => (
                  <RentalCard key={r.id} rental={r} onStatusUpdate={handleStatusUpdate} />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="owner" className="mt-4">
            {ownerRentals.length === 0 ? (
              <Card className="p-8 text-center text-gray-500">
                No rental requests on your properties
              </Card>
            ) : (
              <div className="space-y-3">
                {ownerRentals.map((r) => (
                  <RentalCard key={r.id} rental={r} isOwner onStatusUpdate={handleStatusUpdate} />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      )}
    </div>
  )
}

// ========== MAIN PAGE ==========
export default function Page() {
  const { currentView } = useStore()

  const renderView = () => {
    switch (currentView) {
      case 'home':
        return <HomeView />
      case 'listings':
        return <ListingsView />
      case 'detail':
        return <PropertyDetail />
      case 'add-property':
        return <PropertyForm />
      case 'edit-property':
        return <PropertyForm editProperty={useStore.getState().editingProperty} />
      case 'dashboard':
        return <DashboardView />
      case 'admin':
        return <AdminPanel />
      case 'my-rentals':
        return <MyRentalsView />
      case 'pricing':
        return <PricingPage />
      case 'login':
      case 'register':
        return <AuthForms />
      default:
        return <HomeView />
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar />
      <main className="flex-1">
        {renderView()}
      </main>

      {/* Floating WhatsApp & Call Buttons - Always Visible */}
      <div className="fixed bottom-20 right-3 z-40 flex flex-col gap-2">
        {/* WhatsApp Chat Button - Prominent */}
        <a
          href="https://wa.me/918968541628?text=Hi%20EasyRent!%20I%20need%20help%20with%20rental%20listing.%20Please%20assist%20me."
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 bg-green-500 text-white rounded-full shadow-lg hover:bg-green-600 hover:scale-105 transition-all pr-4 pl-3 py-2.5"
          style={{ boxShadow: '0 4px 16px rgba(34, 197, 94, 0.45)' }}
        >
          <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
          </svg>
          <span className="text-sm font-semibold whitespace-nowrap hidden sm:inline">Chat with Us</span>
        </a>
        {/* Call Button */}
        <a
          href="tel:+918968541628"
          className="w-12 h-12 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow-lg hover:bg-emerald-700 hover:scale-110 transition-all"
          style={{ boxShadow: '0 4px 12px rgba(5, 150, 105, 0.4)' }}
        >
          <Phone className="w-5 h-5" />
        </a>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-6 md:py-8">
        <div className="max-w-7xl mx-auto px-4">
          {/* Mobile Contact Bar */}
          <div className="md:hidden mb-4 pb-4 border-b border-gray-800">
            <a
              href="https://wa.me/918968541628?text=Hi%20EasyRent!%20I%20need%20help%20with%20rental%20listing.%20Please%20assist%20me."
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 bg-green-600/20 rounded-xl p-3 hover:bg-green-600/30 transition-colors"
            >
              <div className="w-10 h-10 rounded-full bg-green-500 flex items-center justify-center flex-shrink-0">
                <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
              </div>
              <div>
                <div className="font-semibold text-white text-sm">EasyRent WhatsApp Support</div>
                <div className="text-xs text-green-300">89685-41628 — Abhi message karein!</div>
              </div>
            </a>
            <a href="tel:+918968541628" className="flex items-center gap-2 text-sm mt-3 text-gray-300 hover:text-white">
              <Phone className="w-4 h-4 text-emerald-400" />
              <span>Call: 89685-41628</span>
            </a>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
                  <Building2 className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold text-white">EasyRent</span>
              </div>
              <p className="text-sm">
                Ghar, Dukan, Kamra — Sab Rent Par! Find affordable rentals across India.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-3">Property Types</h4>
              <ul className="space-y-1 text-sm">
                <li>कमरा / Room</li>
                <li>PG / Paying Guest</li>
                <li>मकान / House</li>
                <li>दुकान / Shop</li>
                <li>गैराज / Garage</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-3">Monetization</h4>
              <ul className="space-y-1 text-sm">
                <li>Ad Posting Plans</li>
                <li>Boost Listings</li>
                <li>Broker Subscription</li>
                <li>Verification Service</li>
                <li>Google AdMob</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-3">Contact</h4>
              <ul className="space-y-1 text-sm">
                <li>support@easyrent.com</li>
                <li className="flex items-center gap-1.5">
                  <Phone className="w-3 h-3" />
                  <a href="tel:+918968541628" className="hover:text-white transition-colors">89685-41628</a>
                </li>
                <li className="flex items-center gap-1.5">
                  <svg className="w-3 h-3" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                  </svg>
                  <a href="https://wa.me/918968541628?text=Hi%20EasyRent!%20I%20need%20help%20with%20rental%20listing.%20Please%20assist%20me." target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">WhatsApp</a>
                </li>
                <li>Mumbai, India</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-6 pt-4 text-center text-xs">
            © 2025 EasyRent. All rights reserved.
          </div>
        </div>
      </footer>

      <MobileNav />
    </div>
  )
}
