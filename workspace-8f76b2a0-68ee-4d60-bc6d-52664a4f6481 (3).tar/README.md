# 🏠 EasyRent — Ghar, Dukan, Kamra, Sab Rent Par!

EasyRent is a mobile-first rental marketplace app built with **Next.js 16**, **Tailwind CSS 4**, **Prisma ORM**, and **SQLite**. It helps users find rooms, PGs, houses, shops, and garages for rent across India.

![EasyRent](https://img.shields.io/badge/EasyRent-v1.0-emerald?style=for-the-badge)
![Next.js](https://img.shields.io/badge/Next.js-16-black?style=flat-square&logo=next.js)
![TypeScript](https://img.shields.io/badge/TypeScript-5-blue?style=flat-square&logo=typescript)
![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-4-06B6D4?style=flat-square&logo=tailwindcss)
![Prisma](https://img.shields.io/badge/Prisma-6-2D3748?style=flat-square&logo=prisma)
![SQLite](https://img.shields.io/badge/SQLite-3-003B57?style=flat-square&logo=sqlite)

---

## ✨ Features

### 🏘️ Property Listings
- **5 Property Types**: Room (कमरा), PG, House (मकान), Shop (दुकान), Garage (गैराज)
- Photo & video upload with camera support
- City search + geolocation-based search
- Property detail page with images, reviews, owner info
- Admin approval workflow (PENDING → APPROVED/REJECTED)

### 🔐 Authentication & Verification
- User registration & login
- Admin panel with role-based access
- Aadhaar verification support
- Admin credentials: `admin@easyrent.com` / `admin123`

### 💰 Monetization
- **Featured Ads**: Boost listings (3-day ₹99, 7-day ₹199, 30-day ₹599)
- **Broker Subscription**: Basic ₹499/mo, Pro ₹1,499/mo
- **Google AdMob** integration ready
- UPI payment support

### 📱 Mobile-First Design
- Bottom navigation (Home, Listings, Post Ad, Rentals, Profile)
- Floating WhatsApp support button (89685-41628)
- Responsive layout for all screen sizes
- Shimmer loading skeletons

### 🛡️ Admin Panel (7 Tabs)
- Overview (stats & analytics)
- Pending Approvals
- Properties Management
- Users Management
- Rentals Tracking
- Reviews Moderation
- Payments & Revenue

### 📞 Contact & Support
- WhatsApp integration: **89685-41628**
- Floating WhatsApp + Call buttons
- Pre-filled WhatsApp messages
- Contact info in footer, dashboard, and property details

---

## 🚀 Getting Started

### Prerequisites
- **Node.js** 18+ or **Bun** runtime
- **npm** or **bun** package manager

### Installation

```bash
# 1. Clone the repository
git clone https://github.com/YOUR_USERNAME/easyrent.git
cd easyrent

# 2. Install dependencies
npm install

# 3. Set up environment variables
cp .env.example .env
# Edit .env if needed (default SQLite path works out of the box)

# 4. Generate Prisma client & push database schema
npx prisma generate
npx prisma db push

# 5. Start the development server
npm run dev
```

The app will be running at **http://localhost:3000**

### Seed Sample Data

After starting the server, seed the database with sample properties:

```bash
curl -X POST http://localhost:3000/api/seed
```

---

## 📁 Project Structure

```
easyrent/
├── prisma/
│   └── schema.prisma          # Database schema (8 models)
├── db/
│   └── custom.db              # SQLite database
├── public/
│   ├── logo.svg               # App logo
│   └── robots.txt             # SEO
├── src/
│   ├── app/
│   │   ├── layout.tsx         # Root layout with metadata
│   │   ├── page.tsx           # Main SPA (all views)
│   │   ├── globals.css        # Global styles + Tailwind
│   │   └── api/               # API routes
│   │       ├── admin/         # Admin endpoints
│   │       ├── auth/          # Login & Register
│   │       ├── properties/    # CRUD + Reviews
│   │       ├── rentals/       # Rental management
│   │       ├── payments/      # UPI payments
│   │       ├── monetization/  # Boost, Subscribe, Stats
│   │       └── seed/          # DB seeding
│   ├── components/
│   │   ├── Navbar.tsx         # Desktop navigation
│   │   ├── MobileNav.tsx      # Bottom tab bar
│   │   ├── PropertyCard.tsx   # Listing card
│   │   ├── PropertyForm.tsx   # Add/Edit property
│   │   ├── PropertyDetail.tsx # Property detail page
│   │   ├── AdminPanel.tsx     # Admin dashboard
│   │   ├── AuthForms.tsx      # Login & Register forms
│   │   ├── PricingPage.tsx    # Subscription plans
│   │   ├── GoogleAd.tsx       # AdMob placeholder
│   │   ├── ReviewSection.tsx  # Reviews component
│   │   ├── RentalCard.tsx     # Rental card
│   │   ├── store.ts           # Zustand state management
│   │   └── ui/                # shadcn/ui components (38)
│   ├── hooks/
│   │   ├── use-mobile.ts      # Mobile detection hook
│   │   └── use-toast.ts       # Toast notification hook
│   └── lib/
│       ├── db.ts              # Prisma client instance
│       └── utils.ts           # Utility functions
├── .env.example               # Environment variables template
├── .gitignore                 # Git ignore rules
├── components.json            # shadcn/ui config
├── eslint.config.mjs          # ESLint configuration
├── next.config.ts             # Next.js configuration
├── package.json               # Dependencies & scripts
├── postcss.config.mjs         # PostCSS configuration
├── tailwind.config.ts         # Tailwind CSS configuration
└── tsconfig.json              # TypeScript configuration
```

---

## 🔑 Default Accounts

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@easyrent.com | admin123 |
| User | rajesh@example.com | password123 |

---

## 🛠️ Tech Stack

| Technology | Purpose |
|-----------|---------|
| **Next.js 16** | React framework with App Router |
| **TypeScript** | Type-safe development |
| **Tailwind CSS 4** | Utility-first styling |
| **shadcn/ui** | UI component library |
| **Prisma ORM** | Database ORM |
| **SQLite** | Lightweight database |
| **Zustand** | State management |
| **Lucide React** | Icon library |

---

## 📲 Deploy to Production

### Vercel (Recommended)
```bash
npm install -g vercel
vercel
```

### Docker
```bash
docker build -t easyrent .
docker run -p 3000:3000 easyrent
```

### Manual
```bash
npm run build
npm run start
```

---

## 📄 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/properties` | List all properties |
| POST | `/api/properties` | Create property |
| GET | `/api/properties/[id]` | Get property detail |
| PUT | `/api/properties/[id]` | Update property |
| DELETE | `/api/properties/[id]` | Delete property |
| POST | `/api/properties/[id]/review` | Add review |
| POST | `/api/auth/login` | User login |
| POST | `/api/auth/register` | User registration |
| GET | `/api/admin` | Admin dashboard data |
| GET | `/api/admin/properties` | Admin properties |
| GET | `/api/admin/users` | Admin users list |
| GET | `/api/admin/analytics` | Analytics data |
| GET | `/api/admin/reviews` | Reviews moderation |
| POST | `/api/monetization/boost` | Boost a listing |
| POST | `/api/monetization/subscribe` | Broker subscription |
| GET | `/api/monetization/pricing` | Get pricing plans |
| GET | `/api/monetization/stats` | User monetization stats |
| POST | `/api/monetization/verify` | Verify property |
| POST | `/api/rentals` | Create rental |
| GET | `/api/rentals/[id]` | Rental detail |
| POST | `/api/payments` | Process payment |
| POST | `/api/seed` | Seed database |

---

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch: `git checkout -b feature/amazing-feature`
3. Commit your changes: `git commit -m 'Add amazing feature'`
4. Push to the branch: `git push origin feature/amazing-feature`
5. Open a Pull Request

---

## 📞 Contact

- **WhatsApp**: [89685-41628](https://wa.me/918968541628)
- **Email**: support@easyrent.com
- **Location**: Mumbai, India

---

## 📜 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

<p align="center">
  <strong>EasyRent</strong> — Ghar, Dukan, Kamra, Sab Rent Par! 🏠
</p>
