import { 
  collection, 
  getDocs, 
  doc, 
  setDoc, 
  deleteDoc, 
  updateDoc,
  getDoc
} from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from './firebase';
import { PropertyListing, RentalAgreement, UserProfile } from '../types';
import { defaultListings } from '../data/defaultListings';

const LISTINGS_COLLECTION = 'listings';
const RENTALS_COLLECTION = 'rentals';
const USERS_COLLECTION = 'users';

/**
 * Fetches all property listings from Firestore.
 * If empty in the cloud database, it initializes it with standard default listings.
 */
export async function fetchListingsFromFirestore(): Promise<PropertyListing[]> {
  try {
    const querySnapshot = await getDocs(collection(db, LISTINGS_COLLECTION));
    const list: PropertyListing[] = [];
    querySnapshot.forEach((doc) => {
      list.push(doc.data() as PropertyListing);
    });

    if (list.length === 0) {
      if (auth.currentUser) {
        // Seed initial default listings into the real database
        console.log('Seeding default listings to Firestore...');
        try {
          for (const item of defaultListings) {
            await setDoc(doc(db, LISTINGS_COLLECTION, item.id), item);
            list.push(item);
          }
        } catch (writeError) {
          handleFirestoreError(writeError, OperationType.WRITE, LISTINGS_COLLECTION);
        }
      } else {
        // Not signed in, just return default lists without seeding DB
        return defaultListings;
      }
    }
    return list;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, LISTINGS_COLLECTION);
    return defaultListings;
  }
}

/**
 * Adds or updates a property listing in Firestore.
 */
export async function saveListingToFirestore(listing: PropertyListing): Promise<void> {
  try {
    const docRef = doc(db, LISTINGS_COLLECTION, listing.id);
    await setDoc(docRef, listing);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${LISTINGS_COLLECTION}/${listing.id}`);
  }
}

/**
 * Deletes a property listing from Firestore.
 */
export async function deleteListingFromFirestore(id: string): Promise<void> {
  try {
    const docRef = doc(db, LISTINGS_COLLECTION, id);
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `${LISTINGS_COLLECTION}/${id}`);
  }
}

/**
 * Fetches all rental agreements from Firestore.
 */
export async function fetchRentalsFromFirestore(): Promise<RentalAgreement[]> {
  try {
    if (!auth.currentUser) return [];
    
    const querySnapshot = await getDocs(collection(db, RENTALS_COLLECTION));
    const list: RentalAgreement[] = [];
    querySnapshot.forEach((doc) => {
      list.push(doc.data() as RentalAgreement);
    });
    return list;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, RENTALS_COLLECTION);
    return [];
  }
}

/**
 * Adds or updates a rental agreement.
 */
export async function saveRentalToFirestore(rental: RentalAgreement): Promise<void> {
  try {
    const docRef = doc(db, RENTALS_COLLECTION, rental.id);
    await setDoc(docRef, rental);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${RENTALS_COLLECTION}/${rental.id}`);
  }
}

/**
 * Marks rental agreement as terminated or deletes.
 */
export async function terminateRentalInFirestore(id: string): Promise<void> {
  try {
    const docRef = doc(db, RENTALS_COLLECTION, id);
    await updateDoc(docRef, { status: 'terminated' });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `${RENTALS_COLLECTION}/${id}`);
  }
}

/**
 * Deletes a rental agreement completely.
 */
export async function deleteRentalFromFirestore(id: string): Promise<void> {
  try {
    const docRef = doc(db, RENTALS_COLLECTION, id);
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `${RENTALS_COLLECTION}/${id}`);
  }
}

/**
 * Syncs the current verified user profile to the database.
 */
export async function syncUserProfileInFirestore(userId: string, profile: UserProfile): Promise<void> {
  try {
    const docRef = doc(db, USERS_COLLECTION, userId);
    await setDoc(docRef, profile, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${USERS_COLLECTION}/${userId}`);
  }
}

/**
 * Fetches user profile from Firestore.
 */
export async function fetchUserProfileFromFirestore(userId: string): Promise<UserProfile | null> {
  try {
    const docRef = doc(db, USERS_COLLECTION, userId);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return docSnap.data() as UserProfile;
    }
    return null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `${USERS_COLLECTION}/${userId}`);
    return null;
  }
}
