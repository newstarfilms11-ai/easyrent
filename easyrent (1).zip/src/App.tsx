/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Building2,
  Phone,
  MessageSquare,
  Users,
  MapPin,
  TrendingUp,
  Bed,
  House as HouseIcon,
  Store,
  Warehouse,
  Sparkles,
  ArrowRight,
  Plus,
  Send,
  Loader2,
  X,
  CreditCard,
  User,
  Heart,
  Compass
} from 'lucide-react';
import { PropertyListing, RentalAgreement, UserProfile, PropertyType } from './types';
import { defaultListings } from './data/defaultListings';
import { 
  fetchListingsFromFirestore, 
  saveListingToFirestore, 
  deleteListingFromFirestore,
  fetchRentalsFromFirestore,
  saveRentalToFirestore,
  terminateRentalInFirestore,
  syncUserProfileInFirestore
} from './lib/dbService';
import { onAuthStateChange } from './lib/firebase';

// Modular Child Components
import Header from './components/Header';
import Hero from './components/Hero';
import ListingsSection from './components/ListingsSection';
import PostAdForm from './components/PostAdForm';
import PricingSection from './components/PricingSection';
import RentalsSection from './components/RentalsSection';
import ProfileSection from './components/ProfileSection';
import GoogleAd from './components/GoogleAd';
import QRPaymentSlip from './components/QRPaymentSlip';

export default function App() {
  // Navigation State
  const [activeTab, setActiveTab] = useState<string>('home');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Domain Database States
  const [listings, setListings] = useState<PropertyListing[]>([]);
  const [rentals, setRentals] = useState<RentalAgreement[]>([]);
  const [user, setUser] = useState<UserProfile>({
    name: 'Rahul Sharma',
    username: 'rahul_sharma99',
    phone: '8968541628',
    email: 'rahul.sharma@easyrent.com',
    role: 'Tenant',
    isPremium: false,
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150&q=80',
    bio: 'Software engineer looking for a semi-furnished 1 BHK or private room in a PG in Bangalore near Koramangala or HSR Layout. Direct owner contact preferred!'
  });

  // Global Dialog states
  const [showWhatsAppSupport, setShowWhatsAppSupport] = useState(false);
  const [waMessageText, setWaMessageText] = useState('');
  const [waChatHistory, setWaChatHistory] = useState<{ sender: 'user' | 'bot'; text: string; time: string }[]>([
    {
      sender: 'bot',
      text: 'Namaste! Welcome to EasyRent Support Desk. How can we assist you with property renting or ad posting today?',
      time: 'Now'
    }
  ]);

  // Load from Firestore OR fall back to localStorage on mount
  useEffect(() => {
    async function loadData() {
      try {
        const firestoreListings = await fetchListingsFromFirestore();
        if (firestoreListings && firestoreListings.length > 0) {
          setListings(firestoreListings);
        } else {
          const savedListings = localStorage.getItem('easyrent_listings');
          if (savedListings) {
            setListings(JSON.parse(savedListings));
          } else {
            setListings(defaultListings);
          }
        }
      } catch (e) {
        console.error("Error fetching listings from Firestore, falling back:", e);
        const savedListings = localStorage.getItem('easyrent_listings');
        if (savedListings) {
          setListings(JSON.parse(savedListings));
        } else {
          setListings(defaultListings);
        }
      }

      try {
        const firestoreRentals = await fetchRentalsFromFirestore();
        if (firestoreRentals && firestoreRentals.length > 0) {
          setRentals(firestoreRentals);
        } else {
          const savedRentals = localStorage.getItem('easyrent_rentals');
          if (savedRentals) {
            setRentals(JSON.parse(savedRentals));
          }
        }
      } catch (e) {
        console.error("Error fetching rentals from Firestore, falling back:", e);
        const savedRentals = localStorage.getItem('easyrent_rentals');
        if (savedRentals) {
          setRentals(JSON.parse(savedRentals));
        }
      }
    }

    loadData();

    const savedUser = localStorage.getItem('easyrent_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }

    const unsubscribe = onAuthStateChange((firebaseUser) => {
      if (firebaseUser) {
        // User is signed in
        const email = firebaseUser.email || '';
        setUser((prev) => ({
          ...prev,
          name: prev.name !== 'Guest Guest' ? prev.name : (firebaseUser.displayName || email || 'User'),
          email: email,
        }));
      } else {
        // User is signed out
        setUser((prev) => ({
          ...prev,
          name: 'Guest Guest',
          email: 'guest@easyrent.com',
          avatarUrl: '',
        }));
      }
    });

    return () => unsubscribe();
  }, []);

  // Save to localStorage and sync to Firebase Firestore
  const saveListingsObj = (updated: PropertyListing[]) => {
    setListings(updated);
    localStorage.setItem('easyrent_listings', JSON.stringify(updated));
  };

  const saveRentalsObj = (updated: RentalAgreement[]) => {
    setRentals(updated);
    localStorage.setItem('easyrent_rentals', JSON.stringify(updated));
  };

  const saveUserObj = (updated: UserProfile) => {
    setUser(updated);
    localStorage.setItem('easyrent_user', JSON.stringify(updated));
    // Synchronize profile to users/{userId} in the real backend
    const userId = updated.username || 'user_rahul';
    syncUserProfileInFirestore(userId, updated).catch(e => console.error("Firestore user profile sync failed:", e));
  };

  // Listings operations
  const handleAddNewListing = (newListing: PropertyListing) => {
    const updated = [newListing, ...listings];
    saveListingsObj(updated);
    // Write to our real Firestore backend
    saveListingToFirestore(newListing).catch(e => console.error("Firestore save listing fails:", e));
    setActiveTab('listings');
  };

  const handleDeleteListing = (id: string) => {
    const updated = listings.filter(item => item.id !== id);
    saveListingsObj(updated);
    // Delete from our real Firestore backend
    deleteListingFromFirestore(id).catch(e => console.error("Firestore delete listing fails:", e));
  };

  // Rentals Lease operations
  const handleRentProperty = (agreement: RentalAgreement) => {
    const updated = [agreement, ...rentals];
    saveRentalsObj(updated);
    // Write to our real Firestore backend
    saveRentalToFirestore(agreement).catch(e => console.error("Firestore save rental agreement fails:", e));
    setActiveTab('rentals');
  };

  const handleTerminateRental = (id: string) => {
    const updated = rentals.filter(r => r.id !== id);
    saveRentalsObj(updated);
    // Terminate in our real Firestore backend
    terminateRentalInFirestore(id).catch(e => console.error("Firestore terminate rental agreement fails:", e));
  };


  // WhatsApp bot simulations
  const handleSendWaMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!waMessageText.trim()) return;

    const userText = waMessageText.trim();
    setWaChatHistory(prev => [...prev, { sender: 'user', text: userText, time: 'Now' }]);
    setWaMessageText('');

    // Simulated response dictionary
    setTimeout(() => {
      let reply = "I would be glad to help! Please call our helpline directly at 89685-41628 for emergency support.";
      const lower = userText.toLowerCase();

      if (lower.includes('post') || lower.includes('list') || lower.includes('ad')) {
        reply = "Posting an ad is 100% free! Simply click on the '+ Post Ad' button at the bottom of the app, fill out your room details, and publish in 2 minutes.";
      } else if (lower.includes('mumbai') || lower.includes('andheri') || lower.includes('flat')) {
        reply = "We have outstanding verified single rooms and shared PGs vacant in Andheri East, Lower Parel, and Bandra. Type 'Mumbai' in the listings search box to explore them!";
      } else if (lower.includes('free') || lower.includes('charge') || lower.includes('broker')) {
        reply = "EasyRent offers zero brokerage transactions! Renters can contact landlords directly. Standard listing is free, while Boost highlights cost only ₹299.";
      } else if (lower.includes('pg') || lower.includes('paying guest')) {
        reply = "We have high-occupancy PGs with continuous electricity, high-speed WiFi, and 3 home-cooked meals included. Explore our PG filter category!";
      } else if (lower.includes('rent') || lower.includes('pay')) {
        reply = "To rent any place, just click 'Rent Now'. That seals a modern digital lease contract, and you can pay the monthly rent securely inside the 'Rentals' panel.";
      }

      setWaChatHistory(prev => [...prev, { sender: 'bot', text: reply, time: 'Just Now' }]);
    }, 1200);
  };

  const activeRentedPropertyIds = rentals.map(r => r.propertyId);

  return (
    <div className="min-h-screen flex flex-col bg-white text-gray-800" id="easyrent-container">
      {/* Universal Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        user={user}
        setUser={saveUserObj}
      />

      {/* Main Screen Router Routing */}
      <main className="flex-grow pb-16 md:pb-0 font-sans">
        {activeTab === 'home' && (
          <div className="animate-fade-in" id="home-view">
            {/* Hero search portion */}
            <Hero
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              setActiveTab={setActiveTab}
              availableCities={['Mumbai', 'Delhi', 'Bangalore', 'Pune', 'Noida']}
            />

            {/* Simulated Live Google Adsense Banner */}
            <div className="max-w-7xl mx-auto px-4 pt-6">
              <GoogleAd placement="leaderboard" className="border-amber-200/60 bg-amber-50/20" />
            </div>

            {/* Quick Browse Categories slider falls in listings section props, shown in card list */}
            <section className="max-w-7xl mx-auto px-4 py-8">
              <div className="flex items-center justify-between mb-5">
                <h2 className="text-base sm:text-lg font-black text-gray-900 tracking-tight">Browse by Property Type</h2>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
                {[
                  { type: 'Room', display: 'Room / कमरा', icon: <Bed className="w-6 h-6 text-emerald-600" /> },
                  { type: 'PG', display: 'Paying Guest', icon: <Building2 className="w-6 h-6 text-emerald-600" /> },
                  { type: 'House', display: 'House / मकान', icon: <HouseIcon className="w-6 h-6 text-emerald-600" /> },
                  { type: 'Shop', display: 'Shop / दुकान', icon: <Store className="w-6 h-6 text-emerald-600" /> },
                  { type: 'Garage', display: 'Garage / गैराज', icon: <Warehouse className="w-6 h-6 text-emerald-600" /> }
                ].map((item) => (
                  <button
                    key={item.type}
                    onClick={() => {
                      setSearchQuery('');
                      // Wait, we can specify ListingsSection's state or let it sync
                      setActiveTab('listings');
                    }}
                    className="bg-white border border-gray-150 rounded-2xl p-4.5 hover:border-emerald-350 hover:shadow-xs transition-all flex flex-col items-center gap-3 group cursor-pointer"
                  >
                    <div className="w-12 h-12 rounded-full bg-emerald-50 flex items-center justify-center group-hover:bg-emerald-100 transition-colors">
                      {item.icon}
                    </div>
                    <span className="text-xs font-bold text-gray-750 whitespace-nowrap group-hover:text-emerald-700">
                      {item.display}
                    </span>
                  </button>
                ))}
              </div>
            </section>

            {/* Featured Premium Listings (Home view) */}
            <section className="max-w-7xl mx-auto px-4 py-2">
              <div className="flex items-center justify-between mb-5">
                <div>
                  <h2 className="text-base sm:text-lg font-extrabold text-gray-900">Premium Boosted Vacancies</h2>
                  <p className="text-[11px] text-gray-400 mt-0.5">Top-rated rental properties verified by physical agents.</p>
                </div>
                <button
                  onClick={() => setActiveTab('listings')}
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-600 hover:text-emerald-700 transition-colors"
                >
                  <span>View All Listings</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {listings.filter(l => l.isFeatured || l.isVerified).slice(0, 3).map((prop) => (
                  <div
                    key={prop.id}
                    onClick={() => {
                      setActiveTab('listings');
                    }}
                    className="bg-white rounded-xl border border-gray-150 hover:border-emerald-250 shadow-xs hover:shadow-sm transition-all overflow-hidden flex flex-col group cursor-pointer"
                  >
                    <div className="relative aspect-[4/3] bg-gray-100">
                      <img src={prop.imageUrl} alt={prop.title} referrerPolicy="no-referrer" className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-500" />
                      <div className="absolute top-2 left-2 flex flex-col gap-1">
                        <span className="text-[9px] font-black uppercase bg-emerald-600 text-white px-2.5 py-0.6 rounded-full shadow-xs">
                          {prop.type}
                        </span>
                      </div>
                      <div className="absolute bottom-2 left-2 bg-gray-900/80 backdrop-blur-xs text-white text-xs font-black px-2.5 py-1 rounded">
                        ₹{prop.rent}/mo
                      </div>
                    </div>
                    <div className="p-4 flex-1 space-y-1.5 text-left">
                      <span className="text-[9px] font-bold text-gray-400 uppercase tracking-wider">{prop.city} Metro area</span>
                      <h3 className="text-xs sm:text-sm font-bold text-gray-900 line-clamp-1 leading-snug group-hover:text-emerald-700 transition-colors">
                        {prop.title}
                      </h3>
                      <p className="text-[11px] text-gray-500 line-clamp-2 leading-relaxed">
                        {prop.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Google AdMob Mock Banner */}
            <section className="max-w-7xl mx-auto px-4 my-8">
              <div className="w-full bg-gradient-to-r from-gray-50 to-gray-100 border border-dashed border-gray-300 rounded-xl flex items-center justify-center text-gray-400 relative overflow-hidden h-[90px] py-4 shadow-2xs">
                <div className="text-center">
                  <div className="text-[9px] uppercase tracking-widest mb-0.5 font-bold text-gray-400">Advertisement</div>
                  <div className="text-xs text-gray-500 font-extrabold">AdMob Unified Display Banner</div>
                  <div className="text-[10px] text-emerald-600 font-bold mt-0.5">Supports EasyRent Platform Maintenance</div>
                </div>
                <div className="absolute top-1.5 right-2 px-1 py-0.2 bg-gray-200 rounded text-[8px] text-gray-400 font-mono">ca-app-pub-8968541628</div>
              </div>
            </section>

            {/* Double Segment CTA banner matrix */}
            <section className="max-w-7xl mx-auto px-4 py-4 grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Box A: Post Ad */}
              <button
                onClick={() => setActiveTab('post-ad')}
                className="bg-gradient-to-r from-emerald-500 via-emerald-650 to-teal-700 text-white rounded-2xl p-6 text-left hover:scale-[1.01] hover:shadow-lg transition-all shadow-md flex justify-between items-center group cursor-pointer relative overflow-hidden"
              >
                <div className="space-y-1 relative z-10">
                  <span className="text-[10px] bg-white/20 uppercase tracking-widest font-black px-2.5 py-0.8 rounded-full">
                    100% Free classified
                  </span>
                  <h3 className="text-lg sm:text-xl font-bold pt-1.5">Post Your Ad - Free!</h3>
                  <p className="text-xs text-emerald-100 leading-relaxed max-w-sm">
                    List room, PG, house, commercial shop or warehouse in 2 minutes. Get calls instantly.
                  </p>
                </div>
                <div className="w-11 h-11 rounded-full bg-white/10 group-hover:bg-white/20 flex items-center justify-center transition-all shrink-0">
                  <Plus className="w-6 h-6" />
                </div>
              </button>

              {/* Box B: Pricing plans */}
              <button
                onClick={() => setActiveTab('pricing')}
                className="bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 text-white rounded-2xl p-6 text-left hover:scale-[1.01] hover:shadow-lg transition-all shadow-md flex justify-between items-center group cursor-pointer relative overflow-hidden"
              >
                <div className="space-y-1 relative z-10">
                  <span className="text-[10px] bg-white/20 uppercase tracking-widest font-black px-2.5 py-0.8 rounded-full">
                    Become Partner Agent
                  </span>
                  <h3 className="text-lg sm:text-xl font-bold pt-1.5">Earn Money with EasyRent</h3>
                  <p className="text-xs text-amber-100 leading-relaxed max-w-sm">
                    Premium boosts, verification packages, banner placement: Earn up to ₹1L per month.
                  </p>
                </div>
                <div className="w-11 h-11 rounded-full bg-white/10 group-hover:bg-white/20 flex items-center justify-center transition-all shrink-0">
                  <ArrowRight className="w-5 h-5 text-white" />
                </div>
              </button>
            </section>

            {/* How EasyRent Works portion */}
            <section className="bg-gray-50 py-10 my-6 border-y border-gray-150">
              <div className="max-w-7xl mx-auto px-4 text-center">
                <h2 className="text-base sm:text-lg font-black text-gray-900 mb-8">How EasyRent Direct Works</h2>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-8">
                  <div className="bg-white border rounded-2xl p-5.5 shadow-2xs space-y-2">
                    <div className="w-10 h-10 rounded-full bg-emerald-600 text-white flex items-center justify-center mx-auto text-sm font-black">1</div>
                    <h3 className="text-xs sm:text-sm font-bold text-gray-900">Search &amp; Filter</h3>
                    <p className="text-gray-500 text-[11px] leading-relaxed">
                      Select rooms or shops in major Indian hubs. Refine using specific amenities.
                    </p>
                  </div>
                  <div className="bg-white border rounded-2xl p-5.5 shadow-2xs space-y-2">
                    <div className="w-10 h-10 rounded-full bg-emerald-600 text-white flex items-center justify-center mx-auto text-sm font-black">2</div>
                    <h3 className="text-xs sm:text-sm font-bold text-gray-900">Connect Landlord</h3>
                    <p className="text-gray-500 text-[11px] leading-relaxed">
                      Message directly via WhatsApp chatbot, call host phone, or take instant visit.
                    </p>
                  </div>
                  <div className="bg-white border rounded-2xl p-5.5 shadow-2xs space-y-2">
                    <div className="w-10 h-10 rounded-full bg-emerald-600 text-white flex items-center justify-center mx-auto text-sm font-black">3</div>
                    <h3 className="text-xs sm:text-sm font-bold text-gray-900">Sign &amp; Reside</h3>
                    <p className="text-gray-500 text-[11px] leading-relaxed">
                      Execute cryptographic digitized tenancy agreements and start paying rent digitally.
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* Statistics panel */}
            <section className="max-w-7xl mx-auto px-4 py-6" id="stats-numbers">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {[
                  { icon: <Building2 className="w-5.h-5 text-emerald-600" />, num: '10,000+', desc: 'Listed Properties' },
                  { icon: <Users className="w-5 h-5 text-emerald-600" />, num: '25,000+', desc: 'Happy Tenants' },
                  { icon: <MapPin className="w-5 h-5 text-emerald-600" />, num: '50+', desc: 'Indian Cities' },
                  { icon: <TrendingUp className="w-5 h-5 text-emerald-600" />, num: '₹5Cr+', desc: 'Tied Transactions' }
                ].map((stat, i) => (
                  <div key={i} className="bg-slate-50 border border-slate-100 rounded-2xl p-4.5 text-center">
                    <div className="flex justify-center mb-1 bg-white w-9 h-9 rounded-full items-center mx-auto shadow-2xs">
                      {stat.icon}
                    </div>
                    <div className="text-base sm:text-lg font-black text-gray-900 mt-1">{stat.num}</div>
                    <div className="text-[10px] text-gray-400 font-bold uppercase">{stat.desc}</div>
                  </div>
                ))}
              </div>
            </section>

            {/* Green WhatsApp support banner */}
            <section className="max-w-7xl mx-auto px-4 py-4">
              <button
                onClick={() => setShowWhatsAppSupport(true)}
                className="w-full bg-gradient-to-r from-green-500 via-green-600 to-emerald-700 text-white rounded-2xl p-5 hover:shadow-md transition-all text-left flex flex-col sm:flex-row items-center gap-4 cursor-pointer"
              >
                <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center shrink-0">
                  <MessageSquare className="w-6.5 h-6.5 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-xs sm:text-sm font-bold">EasyRent Office — WhatsApp Assistant</h3>
                  <p className="text-[11px] text-green-100 leading-normal mt-0.5">
                    Any doubts? Need help to list your room or pay rent? Open a simulated WhatsApp chat instantly below!
                  </p>
                </div>
                <div className="px-4 py-2 bg-white/20 hover:bg-white/30 rounded-full text-xs font-bold shrink-0">
                  Chat Support +91 89685-41628
                </div>
              </button>
            </section>
          </div>
        )}

        {activeTab === 'listings' && (
          <ListingsSection
            listings={listings}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            rentProperty={handleRentProperty}
            rentedIds={activeRentedPropertyIds}
            userPhone={user.phone}
          />
        )}

        {activeTab === 'post-ad' && (
          <PostAdForm
            onAddListing={handleAddNewListing}
            setActiveTab={setActiveTab}
            userPhone={user.phone}
            userName={user.name}
          />
        )}

        {activeTab === 'pricing' && (
          <PricingSection
            user={user}
            setUser={saveUserObj}
          />
        )}

        {activeTab === 'payments' && (
          <QRPaymentSlip
            rentals={rentals}
            onPaymentSuccess={(leaseId, amount, txRef) => {
              console.log(`Rent QR Payment verified for Lease ${leaseId}: Amount ₹${amount}, UTR: ${txRef}`);
            }}
          />
        )}

        {activeTab === 'rentals' && (
          <RentalsSection
            rentals={rentals}
            terminateRental={handleTerminateRental}
            setActiveTab={setActiveTab}
          />
        )}

        {activeTab === 'profile' && (
          <ProfileSection
            user={user}
            setUser={saveUserObj}
            listings={listings}
            onDeleteListing={handleDeleteListing}
            setActiveTab={setActiveTab}
          />
        )}
      </main>

      {/* Universal Footer */}
      <footer className="bg-slate-900 text-slate-400 py-10 md:py-12 border-t border-slate-800 text-xs shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-8">
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center shadow-xs">
                  <Building2 className="w-4.5 h-4.5 text-white" />
                </div>
                <span className="text-lg font-black text-white">EasyRent</span>
              </div>
              <p className="text-[11px] leading-relaxed text-slate-400">
                Ghar, Dukan, Kamra — Sab Rent Par! Find, inspect, and book verified listings directly from landlords instantly.
              </p>
              <div className="text-[10px] text-slate-500 font-bold">
                Made for Tenants &amp; Brokers across India.
              </div>
            </div>

            <div>
              <h4 className="font-extrabold text-white mb-3 tracking-wider uppercase text-[11px]">Property Types</h4>
              <ul className="space-y-1.5 text-slate-400">
                <li>कमरा / Room</li>
                <li>PG / Paying Guest</li>
                <li>मकान / House</li>
                <li>दुकान / Shop</li>
                <li>गैराज / Garage</li>
              </ul>
            </div>

            <div>
              <h4 className="font-extrabold text-white mb-3 tracking-wider uppercase text-[11px]">Monetization</h4>
              <ul className="space-y-1.5 text-slate-400">
                <li>Ad Posting Plans</li>
                <li>Boost Listings</li>
                <li>Broker Premium</li>
                <li>Verification Checks</li>
                <li>Google AdMob</li>
              </ul>
            </div>

            <div>
              <h4 className="font-extrabold text-white mb-3 tracking-wider uppercase text-[11px]">Direct Support</h4>
              <ul className="space-y-2 text-slate-400 font-mono">
                <li>office@easyrent.com</li>
                <li className="flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Call: +91 89685-41628</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <MessageSquare className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>WA: +91 89685-41628</span>
                </li>
                <li className="text-xs text-slate-550 pt-1 font-sans">
                  Mumbai, India
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-slate-800 mt-8 pt-6 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 gap-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
              <span>© 2026 EasyRent Ltd. All rights reserved.</span>
              <span className="hidden sm:inline text-slate-700">|</span>
              <span className="font-black text-emerald-500 uppercase tracking-wider text-[9px] bg-slate-950 px-2.5 py-0.5 rounded border border-slate-800">
                Powered by easyrent.in
              </span>
            </div>
            <div className="flex gap-4 font-bold text-slate-400">
              <button onClick={() => setActiveTab('listings')} className="hover:text-white transition-colors cursor-pointer">Directory</button>
              <button onClick={() => setActiveTab('pricing')} className="hover:text-white transition-colors cursor-pointer">Pricing</button>
              <button onClick={() => setShowWhatsAppSupport(true)} className="hover:text-green-400 transition-colors cursor-pointer">WhatsApp Help</button>
            </div>
          </div>
        </div>
      </footer>

      {/* Global Floating simulated WhatsApp drawer */}
      {showWhatsAppSupport && (
        <div className="fixed bottom-18 right-4 md:right-8 md:bottom-8 z-50 flex flex-col w-76 bg-white rounded-xl shadow-2xl border border-gray-150 overflow-hidden h-[420px] animate-fade-in" id="global-whatsapp-chat">
          {/* Header */}
          <div className="bg-emerald-700 text-white p-3.5 shrink-0 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8.5 h-8.5 bg-emerald-600 rounded-full flex items-center justify-center font-bold">
                E
              </div>
              <div className="text-left font-sans">
                <h4 className="text-[11px] font-bold">EasyRent Helpdesk</h4>
                <span className="text-[8.5px] text-emerald-200 block">Agent Live • Direct Support</span>
              </div>
            </div>
            <button
              onClick={() => setShowWhatsAppSupport(false)}
              className="text-white hover:text-gray-200 text-base font-extrabold cursor-pointer"
            >
              ×
            </button>
          </div>

          {/* Real WhatsApp Launch Link Banner */}
          <div className="bg-emerald-50 border-b border-emerald-150 p-2.5 shrink-0 flex items-center justify-between gap-1.5 text-[10px]">
            <div className="text-emerald-800 leading-tight">
              <span className="font-extrabold block">📲 Want to open official WhatsApp?</span>
              <span className="text-emerald-650">Our support representative is online.</span>
            </div>
            <a
              href="https://wa.me/918968541628?text=Hello%20EasyRent%20Helpline%2C%20I%20need%20direct%20assistance%20on%20rentals."
              target="_blank"
              rel="noopener noreferrer"
              className="px-2.5 py-1.5 bg-green-600 hover:bg-green-700 text-white font-black rounded text-[9px] transition-colors no-underline uppercase tracking-tight"
              id="real-support-whatsapp-redirect"
            >
              Open WA
            </a>
          </div>

          {/* Chat log */}
          <div className="p-3.5 flex-1 overflow-y-auto bg-slate-50 space-y-3">
            {waChatHistory.map((item, index) => (
              <div
                key={index}
                className={`max-w-[85%] rounded-lg p-2.5 text-[11px] ${
                  item.sender === 'user'
                    ? 'bg-emerald-600 text-white ml-auto'
                    : 'bg-white text-gray-800 border border-gray-200 shadow-3xs'
                }`}
              >
                <p className="leading-relaxed">{item.text}</p>
              </div>
            ))}
          </div>

          {/* Input form */}
          <form onSubmit={handleSendWaMessage} className="p-2 border-t shrink-0 flex gap-1.5 bg-white">
            <input
              type="text"
              required
              className="flex-grow text-xs px-2.5 py-1.8 rounded-lg border border-gray-200 focus:outline-hidden text-gray-800"
              placeholder="Type message: 'how to list'"
              value={waMessageText}
              onChange={(e) => setWaMessageText(e.target.value)}
            />
            <button
              type="submit"
              className="w-8.5 h-8.5 bg-emerald-600 hover:bg-emerald-700 rounded-lg flex items-center justify-center text-white shrink-0 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      )}

      {/* Global floating quick-chat launcher bubble on desktop */}
      {!showWhatsAppSupport && (
        <button
          onClick={() => setShowWhatsAppSupport(true)}
          className="fixed bottom-4 right-4 z-45 w-12 h-12 bg-green-500 hover:bg-green-600 rounded-full flex items-center justify-center text-white shadow-xl hover:scale-105 transition-all cursor-pointer box-shadow-[0_4px_16px_rgba(34,197,94,0.45)]"
          title="Chat with Support"
        >
          <MessageSquare className="w-5.5 h-5.5" />
        </button>
      )}

      {/* Mobile Sticky Bottom Navigation Bar (Hidden on md screens) */}
      <nav className="fixed bottom-0 left-0 right-0 z-45 bg-white border-t border-gray-200 md:hidden safe-area-bottom">
        <div className="flex items-end justify-around h-16 px-1">
          <button
            onClick={() => setActiveTab('home')}
            className={`flex flex-col items-center justify-center gap-0.5 py-1 px-3 transition-colors relative cursor-pointer ${
              activeTab === 'home' ? 'text-emerald-700 font-bold' : 'text-gray-400 hover:text-gray-600'
            }`}
          >
            <Compass className="w-5 h-5" />
            <span className="text-[9px] font-extrabold">Home</span>
          </button>

          <button
            onClick={() => setActiveTab('listings')}
            className={`flex flex-col items-center justify-center gap-0.5 py-1 px-3 transition-colors relative cursor-pointer ${
              activeTab === 'listings' ? 'text-emerald-700 font-bold' : 'text-gray-400 hover:text-gray-600'
            }`}
          >
            <Building2 className="w-5 h-5" />
            <span className="text-[9px] font-extrabold">Listings</span>
          </button>

          {/* Floating Central "+ Post Ad" Button */}
          <button
            onClick={() => setActiveTab('post-ad')}
            className="flex flex-col items-center justify-center gap-0.5 py-1 px-3.5 relative cursor-pointer"
          >
            <div className="absolute -top-6 left-1/2 -translate-x-1/2">
              <div className="w-14 h-14 rounded-full flex items-center justify-center shadow-lg transition-transform bg-gradient-to-br from-emerald-400 via-emerald-500 to-teal-600 text-white hover:scale-105">
                <Plus className="w-7 h-7 text-white" />
              </div>
            </div>
            <span className={`text-[9px] font-extrabold mt-8 ${activeTab === 'post-ad' ? 'text-emerald-700' : 'text-gray-400'}`}>
              Post Ad
            </span>
          </button>

          <button
            onClick={() => setActiveTab('rentals')}
            className={`flex flex-col items-center justify-center gap-0.5 py-1 px-3 transition-colors relative cursor-pointer ${
              activeTab === 'rentals' ? 'text-emerald-700 font-bold' : 'text-gray-400 hover:text-gray-600'
            }`}
          >
            <CalendarRangeIcon className="w-5 h-5" />
            <span className="text-[9px] font-extrabold">Rentals</span>
          </button>

          <button
            onClick={() => setActiveTab('profile')}
            className={`flex flex-col items-center justify-center gap-0.5 py-1 px-3 transition-colors relative cursor-pointer ${
              activeTab === 'profile' ? 'text-emerald-700 font-bold' : 'text-gray-400 hover:text-gray-600'
            }`}
          >
            <User className="w-5 h-5" />
            <span className="text-[9px] font-extrabold">Profile</span>
          </button>
        </div>
      </nav>
    </div>
  );
}

// Custom Helper icon mapped nicely
function CalendarRangeIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="18" height="18" x="3" y="4" rx="2" />
      <path d="M16 2v4" />
      <path d="M3 10h18" />
      <path d="M8 2v4" />
      <path d="M17 14h-6" />
      <path d="M13 18H7" />
      <path d="M7 14h.01" />
      <path d="M17 18h.01" />
    </svg>
  );
}
