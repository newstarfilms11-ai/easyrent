/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type PropertyType = 'Room' | 'PG' | 'House' | 'Shop' | 'Garage';

export interface PropertyListing {
  id: string;
  title: string;
  type: PropertyType;
  city: string;
  address: string;
  rent: number;
  deposit: number;
  description: string;
  amenities: string[];
  imageUrl: string;
  ownerName: string;
  ownerPhone: string;
  isVerified: boolean;
  isFeatured: boolean;
  createdAt: string;
  bhk?: string;
  latitude?: number;
  longitude?: number;
}

export interface RentalAgreement {
  id: string;
  propertyId: string;
  propertyTitle: string;
  city: string;
  address: string;
  imageUrl: string;
  rent: number;
  deposit: number;
  ownerName: string;
  ownerPhone: string;
  startDate: string;
  nextDueDate: string;
  status: 'active' | 'terminated';
}

export interface UserProfile {
  name: string;
  phone: string;
  email: string;
  role: 'Tenant' | 'Owner' | 'Broker' | 'Admin';
  isPremium: boolean;
  username?: string;
  avatarUrl?: string;
  bio?: string;
}

export interface SupportChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
}
