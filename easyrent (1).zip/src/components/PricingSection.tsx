/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CreditCard, Check, ShieldCheck, Ticket, AlertCircle, ShoppingBag, Banknote } from 'lucide-react';
import { UserProfile } from '../types';

interface PricingSectionProps {
  user: UserProfile;
  setUser: (user: UserProfile) => void;
}

export default function PricingSection({ user, setUser }: PricingSectionProps) {
  const [selectedPlan, setSelectedPlan] = useState<{ id: string; name: string; price: number; type: string } | null>(null);
  const [upiHandle, setUpiHandle] = useState('');
  const [paymentComplete, setPaymentComplete] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorText, setErrorText] = useState('');
  const [infoText, setInfoText] = useState('');

  const plans = [
    {
      id: 'plan-basic',
      name: 'Classified Basic',
      price: 0,
      period: '30 days',
      features: [
        '1 standard classified listing',
        'Visible in general search list',
        'Normal customer support response',
        'Direct owner-tenant WhatsApp contact'
      ],
      popular: false,
      color: 'border-gray-200 bg-white'
    },
    {
      id: 'plan-boost',
      name: 'Classified Top Boost',
      price: 299,
      period: 'single listing ad',
      features: [
        'Property listed at the TOP of searched cities',
        'Multi-color Verified badge icon',
        '5x more direct tenant calls & messages',
        'Direct connection tracking',
        'Priority verification inspection within 24 hours'
      ],
      popular: true,
      color: 'border-emerald-500 bg-white ring-2 ring-emerald-500/10'
    },
    {
      id: 'plan-broker',
      name: 'Broker Pro Account',
      price: 999,
      period: 'month',
      features: [
        'Unlimited active listed properties',
        'Official certified "Partner Agent" blue badge',
        'Automated WhatsApp inquiry answering setup',
        'Dedicated broker manager support desk',
        'Bulk listing CSV import tools'
      ],
      popular: false,
      color: 'border-gray-300 bg-gray-50'
    }
  ];

  const handleCheckoutBegin = (p: typeof plans[0]) => {
    if (p.price === 0) {
      setInfoText('The Classified Basic is completely free and available instantly when posting an ad on easyrent.in!');
      return;
    }
    setSelectedPlan({
      id: p.id,
      name: p.name,
      price: p.price,
      type: p.period
    });
    setPaymentComplete(false);
    setErrorText('');
  };

  const handleProcessPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!upiHandle || !upiHandle.includes('@')) {
      setErrorText('Please enter a valid UPI address (e.g., rahul@okaxis or vikas@paytm).');
      return;
    }

    setIsProcessing(true);
    setErrorText('');

    setTimeout(() => {
      setIsProcessing(false);
      setPaymentComplete(true);
      // Upgrade user premium state
      setUser({
        ...user,
        isPremium: true,
        role: selectedPlan?.id === 'plan-broker' ? 'Broker' : user.role
      });
    }, 1800);
  };

  return (
    <section className="max-w-7xl mx-auto px-4 py-8 text-gray-800" id="pricing-plans-directory">
      <div className="text-center max-w-xl mx-auto mb-10 space-y-2">
        <span className="text-[10px] uppercase font-mono tracking-widest bg-amber-100 text-amber-900 border border-amber-250 px-2.5 py-1 rounded-full font-bold">
          High-Value Premium Solutions
        </span>
        <h2 className="text-xl sm:text-2xl font-black">Ad Posting Pricing &amp; Plans</h2>
        <p className="text-xs sm:text-sm text-gray-400 font-medium">
          Whether you want to post a single room vacancy or have a portfolio of hundreds of shops, we have a budget match.
        </p>

        {infoText && (
          <div className="p-3 bg-emerald-50 border border-emerald-100 rounded-xl text-emerald-850 text-[11px] font-bold leading-normal animate-fade-in flex items-center justify-between gap-2 max-w-md mx-auto mt-4 shadow-xs">
            <span className="flex items-center gap-1.5 text-left">
              <span>🌿</span>
              <span>{infoText}</span>
            </span>
            <button
              onClick={() => setInfoText('')}
              className="text-emerald-400 hover:text-emerald-600 font-extrabold px-1 text-xs select-none cursor-pointer"
            >
              ×
            </button>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        {plans.map((p) => (
          <div
            key={p.id}
            className={`rounded-2xl border p-5 flex flex-col justify-between relative shadow-xs transition-transform duration-300 hover:scale-[1.01] ${p.color}`}
          >
            {p.popular && (
              <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-amber-400 to-amber-500 text-[9px] uppercase font-black tracking-wider px-3.5 py-1 rounded-full text-amber-900 shadow-sm">
                Most Popular
              </span>
            )}

            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-black text-gray-900">{p.name}</h3>
                <div className="mt-2 flex items-baseline">
                  <span className="text-2xl sm:text-3xl font-black text-gray-800">
                    {p.price === 0 ? 'FREE' : `₹${p.price}`}
                  </span>
                  {p.price !== 0 && (
                    <span className="text-gray-400 text-xs font-bold ml-1">/ {p.period}</span>
                  )}
                </div>
              </div>

              <div className="space-y-2.5 pt-4 border-t border-gray-100">
                {p.features.map((feat, index) => (
                  <div key={index} className="flex gap-2 text-xs text-gray-600">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={() => handleCheckoutBegin(p)}
              className={`w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-xs transition-colors cursor-pointer mt-6 ${
                p.price === 0 ? 'bg-gray-200 hover:bg-gray-300 text-gray-600 font-semibold' : ''
              }`}
            >
              {p.price === 0 ? 'Included on Posting' : 'Buy Boost Package'}
            </button>
          </div>
        ))}
      </div>

      {/* UPI Billing Modal Simulator */}
      {selectedPlan && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 animate-fade-in" id="billing-module">
          <div className="bg-white rounded-xl shadow-2xl overflow-hidden w-full max-w-sm border border-gray-150 relative">
            <button
              onClick={() => setSelectedPlan(null)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 font-bold text-lg cursor-pointer"
            >
              ×
            </button>

            {!paymentComplete ? (
              <form onSubmit={handleProcessPayment} className="p-6 space-y-5">
                <div className="text-center mb-4">
                  <div className="w-12 h-12 bg-emerald-50 rounded-full flex items-center justify-center mx-auto mb-2 text-emerald-600">
                    <ShoppingBag className="w-6 h-6" />
                  </div>
                  <h3 className="text-base font-black">EasyRent UPI Checkout</h3>
                  <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider mt-1">{selectedPlan.name}</p>
                </div>

                <div className="p-3 bg-gray-50 border border-gray-200 rounded-lg text-xs flex justify-between items-center">
                  <div>
                    <span className="text-[9px] text-gray-400 uppercase tracking-wide">Charge Amount</span>
                    <p className="font-extrabold text-emerald-700">₹{selectedPlan.price}</p>
                  </div>
                  <div className="text-right">
                    <span className="text-[9px] text-gray-400 uppercase tracking-wide">Plan Period</span>
                    <p className="font-bold text-gray-700 text-xs uppercase">{selectedPlan.type}</p>
                  </div>
                </div>

                {errorText && (
                  <div className="p-2.5 bg-rose-50 border border-rose-150 rounded-lg text-rose-600 text-xs flex gap-1.5 items-center">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{errorText}</span>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1.5">Your UPI ID (GPay / PhonePe / Paytm) *</label>
                  <input
                    type="text"
                    required
                    className="w-full text-xs px-3 py-2 rounded-lg border border-gray-250 text-gray-800 placeholder-gray-400 focus:outline-hidden"
                    placeholder="e.g., rahul@okaxis, vikas@ybl"
                    value={upiHandle}
                    onChange={(e) => setUpiHandle(e.target.value)}
                  />
                  <span className="text-[10px] text-gray-400 mt-0.5 block leading-normal">
                    Enter your actual UPI handle. A secure payment ticket request gets simulated to your mobile.
                  </span>
                </div>

                <button
                  type="submit"
                  disabled={isProcessing}
                  className="w-full py-2.8 bg-emerald-600 hover:bg-emerald-700 font-bold text-xs text-white rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                >
                  {isProcessing ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Simulating Merchant Token...</span>
                    </>
                  ) : (
                    <>
                      <Banknote className="w-4.5 h-4.5" />
                      <span>Authorize UPI ₹{selectedPlan.price}</span>
                    </>
                  )}
                </button>
              </form>
            ) : (
              <div className="p-6 text-center space-y-4">
                <div className="w-16 h-16 bg-emerald-50 rounded-full flex items-center justify-center mx-auto text-emerald-600 animate-pulse">
                  <ShieldCheck className="w-9 h-9" />
                </div>
                <div>
                  <h3 className="text-base font-black">Premium Status Enabled!</h3>
                  <p className="text-[11px] text-gray-500 mt-1">
                    Your account has been upgraded with <span className="font-bold text-emerald-700">{selectedPlan.name}</span>. All your active and future listings are boosted on our network!
                  </p>
                </div>

                <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg text-left text-[11px] font-mono whitespace-pre space-y-0.5">
                  <div className="flex justify-between">
                    <span>RECEIPT NO:</span><span>{Math.floor(Math.random() * 900500 + 100000)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>ITEM:</span><span>{selectedPlan.name.toUpperCase()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>PAY METHOD:</span><span>UPI ({upiHandle})</span>
                  </div>
                  <div className="flex justify-between border-t border-gray-200 mt-1 pt-1 font-bold text-emerald-700">
                    <span>PAID AMT:</span><span>₹{selectedPlan.price}.00</span>
                  </div>
                </div>

                <button
                  onClick={() => setSelectedPlan(null)}
                  className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg cursor-pointer"
                >
                  Return to Dashboard
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </section>
  );
}
