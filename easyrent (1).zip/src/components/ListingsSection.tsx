/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Bed,
  Building2,
  House,
  Store,
  Warehouse,
  IndianRupee,
  MapPin,
  Phone,
  MessageSquare,
  BadgeCheck,
  Compass,
  SlidersHorizontal,
  X,
  Plus,
  Send,
  Sparkles,
  ShieldCheck,
  Calendar,
  CheckCircle,
  Clock,
  Map,
  List
} from 'lucide-react';
import { PropertyListing, PropertyType, RentalAgreement } from '../types';
import InteractiveMap from './InteractiveMap';
import GoogleAd from './GoogleAd';

interface ListingsSectionProps {
  listings: PropertyListing[];
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  rentProperty: (agreement: RentalAgreement) => void;
  rentedIds: string[];
  userPhone: string;
}

export default function ListingsSection({
  listings,
  searchQuery,
  setSearchQuery,
  rentProperty,
  rentedIds,
  userPhone
}: ListingsSectionProps) {
  // Views
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');

  // Filters
  const [selectedType, setSelectedType] = useState<PropertyType | 'All'>('All');
  const [minRent, setMinRent] = useState<number>(0);
  const [maxRent, setMaxRent] = useState<number>(50000);
  const [selectedBhk, setSelectedBhk] = useState<string>('All');
  const [selectedAmenities, setSelectedAmenities] = useState<string[]>([]);
  const [selectedCity, setSelectedCity] = useState<string>('All');

  // UI Modals / Interactivity
  const [selectedProperty, setSelectedProperty] = useState<PropertyListing | null>(null);
  const [shoingFilters, setShowingFilters] = useState(false);
  const [simulatingCall, setSimulatingCall] = useState<PropertyListing | null>(null);
  const [activeCallStatus, setActiveCallStatus] = useState<'connecting' | 'talking' | 'hung_up'>('connecting');
  const [simulatingChat, setSimulatingChat] = useState<PropertyListing | null>(null);
  const [chatMessageText, setChatMessageText] = useState('');
  const [chatLog, setChatLog] = useState<{ sender: 'user' | 'owner'; text: string; time: string }[]>([]);
  const [agreementProperty, setAgreementProperty] = useState<PropertyListing | null>(null);
  const [agreementStartDate, setAgreementStartDate] = useState('');
  const [completingAgreement, setCompletingAgreement] = useState(false);

  // Constants
  const categories: { label: PropertyType; display: string; icon: React.ReactNode }[] = [
    { label: 'Room', display: 'Room/कमरा', icon: <Bed className="w-5 h-5 text-emerald-600" /> },
    { label: 'PG', display: 'Paying Guest', icon: <Building2 className="w-5 h-5 text-emerald-600" /> },
    { label: 'House', display: 'House/मकान', icon: <House className="w-5 h-5 text-emerald-600" /> },
    { label: 'Shop', display: 'Shop/दुकान', icon: <Store className="w-5 h-5 text-emerald-600" /> },
    { label: 'Garage', display: 'Garage/गैराज', icon: <Warehouse className="w-5 h-5 text-emerald-600" /> }
  ];

  const toggleAmenity = (amenity: string) => {
    setSelectedAmenities(prev =>
      prev.includes(amenity) ? prev.filter(a => a !== amenity) : [...prev, amenity]
    );
  };

  // Filter listings based on criteria
  const filteredListings = listings.filter(item => {
    // City filter
    if (selectedCity !== 'All' && item.city.toLowerCase() !== selectedCity.toLowerCase()) {
      return false;
    }
    // Search query matches City or Title or Address
    if (searchQuery) {
      const sq = searchQuery.toLowerCase();
      const matchesCity = item.city.toLowerCase().includes(sq);
      const matchesTitle = item.title.toLowerCase().includes(sq);
      const matchesAddress = item.address.toLowerCase().includes(sq);
      if (!matchesCity && !matchesTitle && !matchesAddress) return false;
    }
    // Type Filter
    if (selectedType !== 'All' && item.type !== selectedType) {
      return false;
    }
    // Price range filter
    if (item.rent < minRent || item.rent > maxRent) {
      return false;
    }
    // Bedrooms (BHK) filter
    if (selectedBhk !== 'All') {
      if (!item.bhk) {
        return false;
      }
      const bhkLower = item.bhk.toLowerCase();
      if (selectedBhk === '1') {
        if (!bhkLower.includes('1') && !bhkLower.includes('single') && !bhkLower.includes('twin') && !bhkLower.includes('room')) {
          return false;
        }
      } else if (selectedBhk === '2') {
        if (!bhkLower.includes('2') && !bhkLower.includes('double')) {
          return false;
        }
      } else if (selectedBhk === '3') {
        if (!bhkLower.includes('3') && !bhkLower.includes('triple')) {
          return false;
        }
      } else if (selectedBhk === '4') {
        if (!bhkLower.includes('4') && !bhkLower.includes('5') && !bhkLower.includes('6') && !bhkLower.includes('7') && !bhkLower.includes('+')) {
          return false;
        }
      }
    }
    // Amenities filter
    if (selectedAmenities.length > 0) {
      const hasAll = selectedAmenities.every(a => {
        const lowerSelected = a.toLowerCase();
        return item.amenities.some(am => am.toLowerCase() === lowerSelected);
      });
      if (!hasAll) return false;
    }
    return true;
  });

  const handleCallBegin = (prop: PropertyListing) => {
    setSimulatingCall(prop);
    setActiveCallStatus('connecting');
    // Simulate connection to conversation
    setTimeout(() => {
      setActiveCallStatus('talking');
    }, 1500);
  };

  const endCallSimulation = () => {
    setActiveCallStatus('hung_up');
    setTimeout(() => {
      setSimulatingCall(null);
    }, 500);
  };

  const getWhatsAppLink = (phone: string, title: string) => {
    // Keep only numbers
    let cleaned = phone.replace(/\D/g, '');
    if (cleaned.startsWith('0')) {
      cleaned = cleaned.substring(1);
    }
    if (cleaned.length === 10) {
      cleaned = '91' + cleaned;
    }
    const message = `Hello, I saw your property advertisement "${title}" listed on EasyRent.in and would like to inquire about renting it.`;
    return `https://wa.me/${cleaned}?text=${encodeURIComponent(message)}`;
  };

  const handleChatBegin = (prop: PropertyListing) => {
    setSimulatingChat(prop);
    setChatLog([
      {
        sender: 'owner',
        text: `Hi! Thanks for checking my property "${prop.title}". Is there any question I can answer for you?`,
        time: 'Now'
      }
    ]);
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatMessageText.trim() || !simulatingChat) return;

    const userMsg = chatMessageText.trim();
    setChatLog(prev => [...prev, { sender: 'user', text: userMsg, time: 'Now' }]);
    setChatMessageText('');

    // Predefined smart answers back from property owner
    setTimeout(() => {
      let replyText = "That's great! When would you like to schedule a quick physical visit?";
      const lower = userMsg.toLowerCase();
      if (lower.includes('price') || lower.includes('rent') || lower.includes('negotiable')) {
        replyText = `The current monthly rent is ₹${simulatingChat.rent} with a deposit of ₹${simulatingChat.deposit}. It is slightly negotiable if you pay at least 6 months advance!`;
      } else if (lower.includes('parking') || lower.includes('car')) {
        replyText = simulatingChat.amenities.includes('Parking')
          ? "Yes, secure private car parking space is fully available inside the compound."
          : "Parking is typically on the street side, but it is extremely safe and gated.";
      } else if (lower.includes('water') || lower.includes('electricity')) {
        replyText = "We have water supply 24 hours a day, and the electric billing is as per the state electricity meter board directly.";
      } else if (lower.includes('broker') || lower.includes('commission')) {
        replyText = "This is a direct owner listing! Absolutely clean transaction with zero brokerage fees or unexpected commissions involved.";
      }
      setChatLog(prev => [...prev, { sender: 'owner', text: replyText, time: 'Just Now' }]);
    }, 1200);
  };

  const openAgreementSigning = (prop: PropertyListing) => {
    setSelectedProperty(null);
    const today = new Date();
    const futureStr = today.toISOString().split('T')[0];
    setAgreementStartDate(futureStr);
    setAgreementProperty(prop);
  };

  const handleSignAgreement = () => {
    if (!agreementProperty) return;
    setCompletingAgreement(true);

    // Simulate cryptographic blockchain lease signature
    setTimeout(() => {
      const today = new Date(agreementStartDate || new Date());
      const nextMonth = new Date(today);
      nextMonth.setMonth(nextMonth.getMonth() + 1);

      rentProperty({
        id: `lease-${Math.floor(Math.random() * 100000)}`,
        propertyId: agreementProperty.id,
        propertyTitle: agreementProperty.title,
        city: agreementProperty.city,
        address: agreementProperty.address,
        imageUrl: agreementProperty.imageUrl,
        rent: agreementProperty.rent,
        deposit: agreementProperty.deposit,
        ownerName: agreementProperty.ownerName,
        ownerPhone: agreementProperty.ownerPhone,
        startDate: today.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }),
        nextDueDate: nextMonth.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }),
        status: 'active'
      });

      setCompletingAgreement(false);
      setAgreementProperty(null);
    }, 2000);
  };

  const extractUniqueCities = () => {
    return Array.from(new Set(listings.map(l => l.city)));
  };

  return (
    <section className="max-w-7xl mx-auto px-4 py-6" id="listings-directory">
      {/* Category selector slider */}
      <div className="mb-6">
        <h2 className="text-base sm:text-lg font-extrabold text-gray-900 mb-4">Browse by Rental Type</h2>
        <div className="flex gap-3 overflow-x-auto pb-3.5 scrollbar-hide">
          <button
            onClick={() => setSelectedType('All')}
            className={`flex flex-col items-center gap-2.5 min-w-[80px] p-4.5 rounded-2xl border transition-all duration-300 cursor-pointer ${
              selectedType === 'All'
                ? 'bg-emerald-600 border-emerald-600 text-white shadow-md shadow-emerald-600/10 scale-102 font-bold'
                : 'bg-white border-gray-100 hover:border-emerald-300 hover:shadow-xs group'
            }`}
          >
            <div className={`w-11 h-11 rounded-full flex items-center justify-center transition-colors ${
              selectedType === 'All' ? 'bg-white/20' : 'bg-emerald-50 group-hover:bg-emerald-100'
            }`}>
              <Compass className={`w-5.5 h-5.5 ${selectedType === 'All' ? 'text-white' : 'text-emerald-600'}`} />
            </div>
            <span className={`text-xs whitespace-nowrap ${selectedType === 'All' ? 'text-white' : 'text-gray-700'}`}>All Types</span>
          </button>

          {categories.map((cat) => (
            <button
              key={cat.label}
              onClick={() => setSelectedType(cat.label)}
              className={`flex flex-col items-center gap-2.5 min-w-[80px] p-4.5 rounded-2xl border transition-all duration-300 cursor-pointer ${
                selectedType === cat.label
                  ? 'bg-emerald-600 border-emerald-600 text-white shadow-md shadow-emerald-600/10 scale-102 font-bold'
                  : 'bg-white border-gray-100 hover:border-emerald-300 hover:shadow-xs group'
              }`}
            >
              <div className={`w-11 h-11 rounded-full flex items-center justify-center transition-colors ${
                selectedType === cat.label ? 'bg-white/20' : 'bg-emerald-50 group-hover:bg-emerald-100'
              }`}>
                {cat.icon}
              </div>
              <span className={`text-xs whitespace-nowrap ${selectedType === cat.label ? 'text-white' : 'text-gray-700'}`}>
                {cat.display}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Directory Grid with Filters */}
      <div className="flex flex-col lg:flex-row gap-6 items-start">
        {/* Sidebar Filters (Responsive & Always visible on desktop) */}
        <div className="w-full lg:w-64 shrink-0 bg-gray-50 border border-gray-200 rounded-xl p-5 block">
          <div className="flex items-center justify-between mb-4 pb-2 border-b border-gray-200">
            <span className="text-sm font-black text-gray-800 flex items-center gap-1.5">
              <SlidersHorizontal className="w-4 h-4 text-emerald-600" />
              Advanced Filters
            </span>
            <button
              onClick={() => {
                setSelectedCity('All');
                setSelectedType('All');
                setMinRent(0);
                setMaxRent(50000);
                setSelectedBhk('All');
                setSelectedAmenities([]);
                setSearchQuery('');
              }}
              className="text-[11px] text-emerald-600 hover:underline font-bold cursor-pointer"
            >
              Reset All
            </button>
          </div>

          <div className="space-y-4">
            {/* City option */}
            <div>
              <label className="block text-[11px] font-bold text-gray-500 uppercase tracking-wider mb-1.5">Selected City</label>
              <select
                className="w-full text-xs px-2 py-1.8 bg-white border border-gray-250 rounded-lg text-gray-800 font-medium"
                value={selectedCity}
                onChange={(e) => setSelectedCity(e.target.value)}
              >
                <option value="All">All Cities (India)</option>
                {extractUniqueCities().map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            {/* Price Range Filter */}
            <div>
              <label className="block text-[11px] font-bold text-gray-500 uppercase tracking-wider mb-1.5">Price Range (Rent/mo)</label>
              <div className="grid grid-cols-2 gap-2 mb-2">
                <div>
                  <span className="text-[10px] text-gray-400 block mb-0.5 font-bold">Min Price</span>
                  <select
                    className="w-full text-xs px-2 py-1.5 bg-white border border-gray-250 rounded-lg text-gray-800 font-medium"
                    value={minRent}
                    onChange={(e) => setMinRent(Number(e.target.value))}
                  >
                    <option value={0}>Any</option>
                    <option value={2000}>₹2,000</option>
                    <option value={5000}>₹5,000</option>
                    <option value={10000}>₹10,000</option>
                    <option value={15000}>₹15,000</option>
                    <option value={20000}>₹20,000</option>
                    <option value={30000}>₹30,000</option>
                  </select>
                </div>
                <div>
                  <span className="text-[10px] text-gray-400 block mb-0.5 font-bold">Max Price</span>
                  <select
                    className="w-full text-xs px-2 py-1.5 bg-white border border-gray-250 rounded-lg text-gray-800 font-medium"
                    value={maxRent}
                    onChange={(e) => setMaxRent(Number(e.target.value))}
                  >
                    <option value={1000000}>Any</option>
                    <option value={5000}>₹5,000</option>
                    <option value={10000}>₹10,000</option>
                    <option value={15000}>₹15,000</option>
                    <option value={20000}>₹20,000</option>
                    <option value={30000}>₹30,000</option>
                    <option value={50000}>₹50,000</option>
                    <option value={100000}>₹1,00,000</option>
                  </select>
                </div>
              </div>
              
              <div className="space-y-1 mt-1">
                <div className="flex justify-between items-center text-[10px]">
                  <span className="text-gray-400 font-bold">Quick Slider Max</span>
                  <span className="text-emerald-700 font-extrabold font-mono">
                    ₹{(maxRent === 1000000 || maxRent === 100000) ? '50,000+' : maxRent.toLocaleString('en-IN')}
                  </span>
                </div>
                <input
                  type="range"
                  min={2000}
                  max={50000}
                  step={1000}
                  className="w-full h-1.5 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
                  value={maxRent > 50000 ? 50000 : maxRent}
                  onChange={(e) => setMaxRent(Number(e.target.value))}
                />
              </div>
            </div>

            {/* Bedrooms Configuration */}
            <div>
              <label className="block text-[11px] font-bold text-gray-500 uppercase tracking-wider mb-1.5">No. of Bedrooms (BHK)</label>
              <div className="grid grid-cols-5 gap-1">
                {[
                  { value: 'All', label: 'All' },
                  { value: '1', label: '1 BHK' },
                  { value: '2', label: '2 BHK' },
                  { value: '3', label: '3 BHK' },
                  { value: '4', label: '4+' }
                ].map(item => {
                  const isActive = selectedBhk === item.value;
                  return (
                    <button
                      key={item.value}
                      onClick={() => setSelectedBhk(item.value)}
                      className={`py-2 text-[10px] text-center rounded-lg border transition-all cursor-pointer font-extrabold ${
                        isActive
                          ? 'border-emerald-600 bg-emerald-605 text-white bg-emerald-600 shadow-xs'
                          : 'border-gray-200 bg-white text-gray-600 hover:border-gray-300'
                      }`}
                    >
                      {item.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Amenities query checks */}
            <div>
              <label className="block text-[11px] font-bold text-gray-500 uppercase tracking-wider mb-2">Amenities</label>
              <div className="grid grid-cols-2 lg:grid-cols-1 gap-2">
                {[
                  { label: 'Wifi', display: 'Wifi / इंटरनेट', icon: '📶' },
                  { label: 'Parking', display: 'Parking / पार्किंग', icon: '🅿️' },
                  { label: 'AC', display: 'AC / एसी', icon: '❄️' },
                  { label: 'Attached Bath', display: 'Attached Bath', icon: '🚽' },
                  { label: 'Security', display: 'Security 🛡️', icon: '🛡️' },
                  { label: 'Washing Machine', display: 'Washing Machine', icon: '🧺' },
                  { label: 'Meals Included', display: 'Meals Included', icon: '🍱' },
                  { label: 'Power Backup', display: 'Power Backup', icon: '⚡' },
                  { label: 'Private Entrance', display: 'Private Entry', icon: '🔑' }
                ].map(item => {
                  const labelSafe = item.label.toLowerCase();
                  const isChecked = selectedAmenities.some(a => a.toLowerCase() === labelSafe);
                  const isPrimary = item.label === 'Wifi' || item.label === 'Parking';
                  return (
                    <button
                      key={item.label}
                      onClick={() => toggleAmenity(item.label)}
                      className={`text-left px-2.5 py-2 text-xs rounded-lg border transition-all cursor-pointer flex items-center gap-1.5 ${
                        isChecked
                          ? 'border-emerald-600 bg-emerald-50 text-emerald-800 font-extrabold ring-1 ring-emerald-500/20'
                          : isPrimary
                          ? 'border-emerald-250 bg-emerald-50/20 text-gray-700 hover:border-emerald-400 hover:bg-emerald-50/40'
                          : 'border-gray-250 bg-white text-gray-650 hover:border-gray-355'
                      }`}
                    >
                      <span className="text-[11px]">{item.icon}</span>
                      <span className="truncate leading-none">{item.display}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Listings Result list */}
        <div className="flex-1 w-full">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 bg-gray-50/50 p-2.5 sm:p-3.5 rounded-2xl border border-gray-150">
            <p className="text-xs text-gray-500 font-semibold">
              Found <span className="font-extrabold text-emerald-700">{filteredListings.length}</span> verified properties
              {selectedCity !== 'All' ? ` in ${selectedCity}` : ''}
              {selectedType !== 'All' ? ` [${selectedType}]` : ''}
            </p>

            {/* View Switcher Controls */}
            <div className="flex items-center gap-1 bg-gray-200/50 p-1 rounded-xl self-end sm:self-auto shrink-0 border border-gray-200">
              <button
                onClick={() => setViewMode('list')}
                className={`px-3 py-1.5 rounded-lg text-[11px] font-extrabold flex items-center gap-1.5 transition-all cursor-pointer ${
                  viewMode === 'list'
                    ? 'bg-white text-emerald-700 shadow-xs ring-1 ring-black/5'
                    : 'text-gray-500 hover:text-gray-850'
                }`}
                id="toggle-view-list-btn"
              >
                <List className="w-3.5 h-3.5" />
                <span>List Grid</span>
              </button>
              <button
                onClick={() => setViewMode('map')}
                className={`px-3 py-1.5 rounded-lg text-[11px] font-extrabold flex items-center gap-1.5 transition-all cursor-pointer ${
                  viewMode === 'map'
                    ? 'bg-white text-emerald-700 shadow-xs ring-1 ring-black/5'
                    : 'text-gray-500 hover:text-gray-850'
                }`}
                id="toggle-view-map-btn"
              >
                <Map className="w-3.5 h-3.5" />
                <span>Interactive Map</span>
              </button>
            </div>
          </div>

          {filteredListings.length === 0 ? (
            <div className="bg-white border rounded-xl py-12 px-4 text-center">
              <span className="text-4xl">🔍</span>
              <h3 className="font-bold text-gray-800 mt-2">No Matching Rentals Found</h3>
              <p className="text-xs text-gray-400 mt-1 max-w-sm mx-auto">
                Try widening your budget, erasing some amenities, or selecting "All Cities" instead.
              </p>
            </div>
          ) : viewMode === 'map' ? (
            <InteractiveMap
              listings={filteredListings}
              rentedIds={rentedIds}
              onViewDetails={setSelectedProperty}
              onRentNow={openAgreementSigning}
            />
          ) : (
            <div className="space-y-6">
              {/* Google Adsense Running Banner */}
              <GoogleAd placement="leaderboard" className="border-emerald-100/40" />

              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5" id="listings-grid">
                {filteredListings.map((prop) => {
                  const isRented = rentedIds.includes(prop.id);
                  return (
                    <div
                      key={prop.id}
                      className={`bg-white rounded-xl border border-gray-150 shadow-xs hover:shadow-md transition-all duration-300 overflow-hidden relative flex flex-col group ${
                        isRented ? 'opacity-85' : ''
                      }`}
                    >
                      {/* Property Image & badging */}
                      <div className="relative aspect-[4/3] bg-gray-100 overflow-hidden shrink-0">
                        <img
                          src={prop.imageUrl}
                          alt={prop.title}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                        />
                        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1.5 items-start">
                          <span className="text-[10px] font-black uppercase bg-emerald-600 text-white px-2.5 py-0.8 rounded-full shadow-xs">
                            {prop.type}
                          </span>
                          {prop.bhk && (
                            <span className="text-[10px] font-bold bg-white/90 backdrop-blur-xs text-emerald-800 border border-emerald-200/50 px-2 py-0.5 rounded-md">
                              {prop.bhk}
                            </span>
                          )}
                        </div>

                        {prop.isVerified && (
                          <div className="absolute top-2.5 right-2.5 bg-emerald-50 text-emerald-700 text-[10px] font-black flex items-center gap-1 px-2.5 py-1 rounded-full border border-emerald-200 shadow-xs">
                            <BadgeCheck className="w-3.5 h-3.5 text-emerald-600 fill-emerald-100" />
                            <span>Verified</span>
                          </div>
                        )}

                        {/* Rent Badge */}
                        <div className="absolute bottom-2.5 left-2.5 bg-gray-900/80 backdrop-blur-xs text-white text-sm font-black px-3 py-1 rounded-lg flex items-center gap-0.5">
                          <IndianRupee className="w-3.5 h-3.5" />
                          <span>{prop.rent.toLocaleString('en-IN')}<span className="text-[10px] font-bold opacity-80">/mo</span></span>
                        </div>
                      </div>

                      {/* Property Details */}
                      <div className="p-4 flex-1 flex flex-col justify-between">
                        <div className="space-y-1.5">
                          <div className="flex gap-1 items-center text-[10px] text-gray-400 font-bold font-mono">
                            <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                            <span>{prop.city}</span>
                          </div>
                          <h3 className="text-sm font-black text-gray-900 tracking-tight leading-tight line-clamp-1 group-hover:text-emerald-700 transition-colors">
                            {prop.title}
                          </h3>
                          <p className="text-xs text-gray-500 line-clamp-2 max-h-8">
                            {prop.description}
                          </p>
                        </div>

                        <div className="mt-4 pt-3.5 border-t border-gray-100 flex items-center justify-between gap-2">
                          {isRented ? (
                            <span className="w-full py-1.8 bg-gray-100 text-gray-500 text-xs font-bold rounded-lg flex items-center justify-center gap-1">
                              <Clock className="w-3.5 h-3.5" /> Already Rented
                            </span>
                          ) : (
                            <>
                              <button
                                onClick={() => setSelectedProperty(prop)}
                                className="px-3.5 py-1.8 border border-gray-200 text-gray-700 hover:bg-gray-50 text-xs font-bold rounded-lg cursor-pointer flex-1 text-center"
                              >
                                Details
                              </button>
                              <button
                                onClick={() => openAgreementSigning(prop)}
                                className="px-3.5 py-1.8 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-xs cursor-pointer flex-1 text-center"
                              >
                                Rent Now
                              </button>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Property Details Modal */}
      {selectedProperty && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 overflow-y-auto animate-fade-in">
          <div className="bg-white rounded-xl shadow-2xl overflow-hidden w-full max-w-lg border border-gray-200 relative my-8">
            <button
              onClick={() => setSelectedProperty(null)}
              className="absolute top-3.5 right-3.5 text-white bg-black/40 hover:bg-black/60 w-8.5 h-8.5 rounded-full flex items-center justify-center font-bold text-xl cursor-pointer z-10"
            >
              ×
            </button>

            {/* Modal Cover Image */}
            <div className="relative h-56 bg-gray-100">
              <img
                src={selectedProperty.imageUrl}
                alt={selectedProperty.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 left-4 flex flex-col gap-1">
                <span className="text-[10px] font-black uppercase bg-emerald-600 text-white px-2.5 py-0.8 rounded-full">
                  {selectedProperty.type}
                </span>
                {selectedProperty.bhk && (
                  <span className="text-[10px] font-black bg-white/95 text-emerald-800 px-2 py-0.5 rounded shadow-xs">
                    {selectedProperty.bhk}
                  </span>
                )}
              </div>
              <div className="absolute bottom-4 left-4 bg-gray-900/80 backdrop-blur-xs text-white text-base font-black px-3.5 py-1 rounded-lg">
                Rent: ₹{selectedProperty.rent.toLocaleString('en-IN')}/mo
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-4">
              <div>
                <h3 className="text-base sm:text-lg font-black text-gray-900 leading-tight">
                  {selectedProperty.title}
                </h3>
                <div className="flex items-center gap-1.5 text-xs text-gray-500 font-semibold mt-1.5">
                  <MapPin className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{selectedProperty.address}</span>
                </div>
              </div>

              {/* Deposit Panel */}
              <div className="grid grid-cols-2 gap-3.5 p-3.5 bg-gray-50 border border-gray-150 rounded-lg">
                <div>
                  <span className="block text-[10px] font-semibold text-gray-400 uppercase">Monthly House Rent</span>
                  <span className="text-sm font-black text-emerald-700">₹{selectedProperty.rent}/mo</span>
                </div>
                <div>
                  <span className="block text-[10px] font-semibold text-gray-400 uppercase">Security Deposit Amount</span>
                  <span className="text-sm font-black text-gray-800">₹{selectedProperty.deposit}</span>
                </div>
              </div>

              {/* Description */}
              <div className="space-y-1">
                <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider">Description</h4>
                <p className="text-xs text-gray-600 leading-relaxed">
                  {selectedProperty.description}
                </p>
              </div>

              {/* Amenities */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider">Property Amenities</h4>
                <div className="flex gap-1.5 flex-wrap">
                  {selectedProperty.amenities.map(a => (
                    <span key={a} className="text-[10px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-100/50 px-2.5 py-1 rounded-md">
                      ✓ {a}
                    </span>
                  ))}
                </div>
              </div>

              {/* Contacts Panel */}
              <div className="pt-4 border-t border-gray-100 flex items-center justify-between gap-3">
                <div className="text-left">
                  <span className="block text-[9px] font-semibold text-gray-400 uppercase">Contact Landlord</span>
                  <span className="text-xs font-extrabold text-gray-800 flex items-center gap-1">
                    {selectedProperty.ownerName}
                    {selectedProperty.isVerified && <BadgeCheck className="w-3.5 h-3.5 text-emerald-600 fill-emerald-100 shrink-0" />}
                  </span>
                  <span className="text-[10px] font-bold text-gray-500 font-mono">+{selectedProperty.ownerPhone}</span>
                </div>

                <div className="flex gap-2 shrink-0">
                  <button
                    onClick={() => handleCallBegin(selectedProperty)}
                    className="p-2.5 cursor-pointer bg-emerald-50 text-emerald-600 hover:bg-emerald-100 rounded-lg transition-colors"
                    title="Call Landlord"
                  >
                    <Phone className="w-4.5 h-4.5" />
                  </button>
                  <button
                    onClick={() => handleChatBegin(selectedProperty)}
                    className="p-2.5 cursor-pointer bg-emerald-50 text-emerald-600 hover:bg-emerald-100 rounded-lg transition-colors"
                    title="WhatsApp Landlord"
                  >
                    <MessageSquare className="w-4.5 h-4.5" />
                  </button>
                  <button
                    onClick={() => openAgreementSigning(selectedProperty)}
                    className="px-5 py-2.5 bg-emerald-650 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg shadow-xs cursor-pointer"
                  >
                    Instant Lease
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Simulated Phone Call Interface */}
      {simulatingCall && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 animate-fade-in">
          <div className="bg-slate-900 text-white rounded-3xl p-6 w-full max-w-xs text-center border border-slate-800 shadow-2xl relative">
            <div className="py-8">
              <div className="w-20 h-20 bg-emerald-600/30 border border-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
                <Phone className="w-9 h-9 text-emerald-400" />
              </div>
              <h3 className="text-lg font-extrabold">{simulatingCall.ownerName}</h3>
              <p className="text-sm text-slate-400 font-mono mt-1">+91 {simulatingCall.ownerPhone}</p>

              <div className="mt-12">
                {activeCallStatus === 'connecting' && (
                  <p className="text-xs text-emerald-400 font-bold font-mono tracking-wider animate-bounce">DIALING...</p>
                )}
                {activeCallStatus === 'talking' && (
                  <div className="space-y-4">
                    <p className="text-xs text-amber-300 font-bold font-mono tracking-wider animate-pulse">CONNECTED / ON CALL</p>
                    <div className="p-4 bg-slate-800/80 rounded-xl text-left border border-slate-700/55">
                      <p className="text-xs text-slate-300 italic">
                        "{simulatingCall.ownerName}: Namaste! Haanji, property rent par available hai. Boht calls aa rhi hain, aap kab dekhne aaenge?"
                      </p>
                    </div>
                  </div>
                )}
                {activeCallStatus === 'hung_up' && (
                  <p className="text-xs text-rose-400 font-bold font-mono tracking-wider uppercase">CALL ENDED</p>
                )}
              </div>
            </div>

            <div className="mt-8 pt-4 border-t border-slate-800/80 flex justify-center">
              <button
                onClick={endCallSimulation}
                className="w-14 h-14 bg-rose-600 hover:bg-rose-700 rounded-full flex items-center justify-center text-white cursor-pointer transition-transform hover:scale-105"
                title="Hang up call"
              >
                <X className="w-5.5 h-5.5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Simulated Live Chat Drawer/Modal */}
      {simulatingChat && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 animate-fade-in">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm border border-gray-100 overflow-hidden flex flex-col h-[520px]">
            {/* Chat Header */}
            <div className="bg-emerald-700 text-white p-4 shrink-0 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center text-white font-bold relative">
                  {simulatingChat.ownerName[0]}
                  <span className="w-2.5 h-2.5 bg-green-400 border border-emerald-700 rounded-full absolute bottom-0 right-0"></span>
                </div>
                <div className="text-left">
                  <h4 className="text-xs font-bold flex items-center gap-1">
                    {simulatingChat.ownerName}
                    <BadgeCheck className="w-3.5 h-3.5 fill-white/10 text-emerald-300 shrink-0" />
                  </h4>
                  <p className="text-[10px] text-emerald-250 leading-none mt-0.5">Online • Direct Owner</p>
                </div>
              </div>
              <button
                onClick={() => setSimulatingChat(null)}
                className="text-white hover:text-gray-200 text-lg font-bold w-7 h-7 flex items-center justify-center rounded-full hover:bg-white/10 cursor-pointer"
              >
                ×
              </button>
            </div>

            {/* Direct WhatsApp Action Redirect Alert */}
            <div className="bg-emerald-50 border-b border-emerald-100 p-3 flex flex-col sm:flex-row items-center justify-between gap-2 shrink-0">
              <div className="text-left font-sans text-[11px] leading-tight text-emerald-800">
                <span className="font-extrabold block">💬 Real WhatsApp Response:</span>
                <span className="text-[10px] text-emerald-650 font-medium">Link with +{simulatingChat.ownerPhone} is ready</span>
              </div>
              <a
                href={getWhatsAppLink(simulatingChat.ownerPhone, simulatingChat.title)}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto text-center bg-emerald-600 hover:bg-emerald-700 text-white px-3.5 py-1.5 text-xs font-black rounded-lg transition-colors shadow-xs no-underline uppercase tracking-tight flex items-center justify-center gap-1 cursor-pointer"
                id="real-whatsapp-launch-btn"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Open WhatsApp App</span>
              </a>
            </div>

            {/* Chat Workspace content */}
            <div className="p-4 flex-1 overflow-y-auto bg-gray-50 flex flex-col gap-3">
              <div className="mx-auto text-center py-2">
                <span className="text-[9px] bg-gray-200/80 px-2 py-0.8 rounded-full text-gray-500 font-bold uppercase tracking-wider">
                  Direct Chat with Owner
                </span>
              </div>

              {chatLog.map((log, index) => (
                <div
                  key={index}
                  className={`max-w-[85%] rounded-xl p-3 text-xs ${
                    log.sender === 'user'
                      ? 'bg-emerald-600 text-white ml-auto'
                      : 'bg-white text-gray-800 border border-gray-150 mr-auto'
                  }`}
                >
                  <p className="leading-relaxed">{log.text}</p>
                </div>
              ))}
            </div>

            {/* Chat Footer */}
            <form onSubmit={handleSendMessage} className="p-3 border-t shrink-0 flex gap-2 bg-white">
              <input
                type="text"
                className="flex-1 text-xs px-3 py-2 rounded-lg border border-gray-200 focus:outline-hidden focus:border-emerald-500"
                placeholder="Ask about water, security deposit..."
                value={chatMessageText}
                onChange={(e) => setChatMessageText(e.target.value)}
              />
              <button
                type="submit"
                className="w-10 h-10 bg-emerald-600 hover:bg-emerald-700 rounded-lg flex items-center justify-center text-white shrink-0 cursor-pointer transition-colors"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Digitized Blockchain-style Lease Agreement Signing */}
      {agreementProperty && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 scrollbar-hide overflow-y-auto animate-fade-in">
          <div className="bg-white rounded-xl shadow-2xl overflow-hidden w-full max-w-md border border-gray-150 my-6">
            <div className="bg-gradient-to-r from-teal-700 to-emerald-800 text-white p-5 text-center relative shrink-0">
              <button
                onClick={() => setAgreementProperty(null)}
                className="absolute top-4 right-4 text-white/80 hover:text-white text-xl font-bold cursor-pointer"
              >
                ×
              </button>
              <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-2 text-white">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="text-base font-black">Digital Lease Agreement</h3>
              <p className="text-[10px] text-emerald-150 mt-1 uppercase tracking-widest leading-none font-bold">Secure Online Tenancy Contract</p>
            </div>

            <div className="p-5.5 space-y-4">
              <div className="p-3 border-l-3 border-emerald-500 bg-emerald-50/50 rounded-r-lg space-y-0.5">
                <span className="block text-[9px] font-bold text-emerald-800 uppercase tracking-wider">Target Rental</span>
                <p className="text-xs font-black text-gray-800">{agreementProperty.title}</p>
                <span className="text-[10px] text-gray-500 block leading-none">{agreementProperty.address}</span>
              </div>

              <div className="space-y-2">
                <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Lease Conditions &amp; Payment</h4>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="p-2.5 bg-gray-50 rounded-lg border border-gray-150">
                    <span className="block text-[9px] text-gray-400">Owner Name</span>
                    <span className="font-extrabold text-gray-800">{agreementProperty.ownerName}</span>
                  </div>
                  <div className="p-2.5 bg-gray-50 rounded-lg border border-gray-150">
                    <span className="block text-[9px] text-gray-400">Your Contact No</span>
                    <span className="font-extrabold text-gray-800">+{userPhone || '8968541628'}</span>
                  </div>
                  <div className="p-2.5 bg-gray-50 rounded-lg border border-gray-150">
                    <span className="block text-[9px] text-gray-400">Monthly Rent</span>
                    <span className="font-extrabold text-emerald-700">₹{agreementProperty.rent}/mo</span>
                  </div>
                  <div className="p-2.5 bg-gray-50 rounded-lg border border-gray-150">
                    <span className="block text-[9px] text-gray-400">Security Deposit</span>
                    <span className="font-extrabold text-gray-800">₹{agreementProperty.deposit}</span>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Agreement Start Date</label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-600" />
                  <input
                    type="date"
                    required
                    className="w-full text-xs pl-10 pr-3 py-2 border border-gray-200 rounded-lg"
                    value={agreementStartDate}
                    onChange={(e) => setAgreementStartDate(e.target.value)}
                  />
                </div>
              </div>

              <div className="p-3 bg-rose-50/50 rounded-lg border border-dashed border-rose-200 flex gap-2">
                <input type="checkbox" required defaultChecked className="mt-1 shrink-0 cursor-pointer accent-emerald-600" id="lease-term-agree" />
                <label htmlFor="lease-term-agree" className="text-[10px] text-gray-600 leading-normal">
                  I agree that by clicking "Sign Digitally", I am authorizing a digital tenancy agreement on EasyRent. I promise to pay rent before the due date.
                </label>
              </div>

              <button
                onClick={handleSignAgreement}
                disabled={completingAgreement}
                className="w-full py-2.8 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg transition-all flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/10 cursor-pointer"
              >
                {completingAgreement ? (
                  <>
                    <Clock className="w-4 h-4 animate-spin" />
                    <span>Sealing Digitized Tenancy...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle className="w-4.5 h-4.5" />
                    <span>Sign Digitally &amp; Book Rental</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Toggle Button */}
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 md:bottom-8">
        <button
          onClick={() => setViewMode(prev => prev === 'list' ? 'map' : 'list')}
          className="flex items-center gap-2.5 bg-slate-900 border border-slate-800 hover:bg-slate-850 text-white font-extrabold px-6 py-3.5 rounded-full shadow-2xl transition-all duration-300 hover:scale-105 active:scale-95 text-xs tracking-wide uppercase select-none cursor-pointer"
          id="floating-view-toggle-btn"
        >
          {viewMode === 'list' ? (
            <>
              <Map className="w-4 h-4 text-emerald-400 animate-pulse" />
              <span>Show Full Map</span>
            </>
          ) : (
            <>
              <List className="w-4 h-4 text-emerald-400" />
              <span>Show Standard List</span>
            </>
          )}
        </button>
      </div>
    </section>
  );
}
