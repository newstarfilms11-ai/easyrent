/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Search, Navigation, MapPin, Sparkles, Locate, Loader2 } from 'lucide-react';

interface HeroProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  setActiveTab: (tab: string) => void;
  availableCities: string[];
}

export default function Hero({
  searchQuery,
  setSearchQuery,
  setActiveTab,
  availableCities
}: HeroProps) {
  const [typedQuery, setTypedQuery] = useState(searchQuery);
  const [detecting, setDetecting] = useState(false);
  const [gpsIndicator, setGpsIndicator] = useState('');

  const triggerSearch = () => {
    setSearchQuery(typedQuery);
    setActiveTab('listings');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      triggerSearch();
    }
  };

  const simulateGpsLocation = () => {
    setDetecting(true);
    setGpsIndicator('Accessing Geolocation...');
    setTimeout(() => {
      // Pick a random city from available
      const randomCity = 'Mumbai'; // Classic Indian default for this site
      setTypedQuery(randomCity);
      setSearchQuery(randomCity);
      setDetecting(false);
      setGpsIndicator('Located Mumbai successfully!');
      setTimeout(() => {
        setGpsIndicator('');
        setActiveTab('listings');
      }, 1000);
    }, 1200);
  };

  return (
    <section className="relative bg-gradient-to-br from-emerald-600 via-emerald-700 to-teal-800 text-white overflow-hidden" id="hero-banner">
      {/* Decorative Blur Orbs */}
      <div className="absolute inset-0 opacity-15 overflow-hidden pointer-events-none">
        <div className="absolute top-2 left-8 w-44 h-44 rounded-full bg-white/20 blur-3xl animate-pulse"></div>
        <div className="absolute bottom-6 right-10 w-56 h-56 rounded-full bg-white/10 blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-11 sm:py-16 relative z-10">
        <div className="max-w-2xl mx-auto text-center">
          <div className="inline-flex items-center gap-1.5 bg-emerald-500/25 border border-emerald-450/30 px-3 py-1 rounded-full text-[10px] sm:text-xs font-semibold mb-3 tracking-wide text-emerald-200">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            No. 1 Trusted Rental Portal in India
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black mb-2 tracking-tight leading-none text-white font-sans">
            Ghar, Dukan, Kamra — <span className="text-emerald-200 block sm:inline">Sab Rent Par!</span>
          </h1>
          <p className="text-xs sm:text-sm text-emerald-100 max-w-lg mx-auto mb-6 leading-relaxed font-medium">
            Find rooms, PGs, houses, shops &amp; garages for rent across India. Affordable, verified listings directly from owners.
          </p>

          {/* Dual Search Input Box */}
          <div className="bg-white rounded-xl p-2.5 shadow-xl flex flex-col sm:flex-row gap-2 max-w-xl mx-auto text-gray-800" id="hero-search-container">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -current -translate-y-1/2 w-4.5 h-4.5 text-gray-400" />
              <input
                type="text"
                className="w-full text-sm pl-10 pr-3 py-2 border-0 bg-transparent text-gray-800 placeholder-gray-400 focus:ring-0 focus:outline-hidden h-10"
                placeholder="Search by city (Mumbai, Delhi, Pune)..."
                value={typedQuery}
                onChange={(e) => setTypedQuery(e.target.value)}
                onKeyDown={handleKeyPress}
              />
            </div>

            <div className="flex gap-2 shrink-0">
              <button
                onClick={simulateGpsLocation}
                disabled={detecting}
                className="inline-flex items-center justify-center rounded-lg text-xs font-semibold px-4 h-11 border border-gray-200 text-gray-600 hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-250 cursor-pointer transition-all gap-1.5 active:scale-95 disabled:opacity-60"
                title="Detect my current city using GPS"
              >
                {detecting ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-600" />
                ) : (
                  <Navigation className="w-3.5 h-3.5 text-emerald-600" />
                )}
                <span>Location</span>
              </button>

              <button
                onClick={triggerSearch}
                className="inline-flex items-center justify-center gap-1.5 rounded-lg text-xs font-bold py-2 px-6 bg-emerald-600 hover:bg-emerald-700 text-white h-11 cursor-pointer transition-all active:scale-95 shadow-md shadow-emerald-800/10"
              >
                <Search className="w-4.5 h-4.5" />
                <span>Search</span>
              </button>
            </div>
          </div>

          {gpsIndicator && (
            <div className="mt-2 text-xs font-bold text-emerald-300 flex items-center justify-center gap-1 animate-pulse">
              <MapPin className="w-3.5 h-3.5" />
              <span>{gpsIndicator}</span>
            </div>
          )}

          {/* Quick city tags query */}
          <div className="mt-4.5 flex gap-2 justify-center items-center flex-wrap text-[10px] sm:text-xs">
            <span className="text-emerald-150 font-semibold">Popular Cities:</span>
            {availableCities.map((city) => (
              <button
                key={city}
                onClick={() => {
                  setTypedQuery(city);
                  setSearchQuery(city);
                  setActiveTab('listings');
                }}
                className={`px-2.5 py-1 rounded-full border bg-white/15 cursor-pointer text-[11px] font-bold transition-all hover:bg-white/35 ${
                  searchQuery.toLowerCase() === city.toLowerCase()
                    ? 'border-emerald-300 text-white bg-emerald-500/40 scale-105'
                    : 'border-white/20 text-emerald-100 hover:border-white/50'
                }`}
              >
                {city}
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
