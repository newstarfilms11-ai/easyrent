/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { MapPin, BadgeCheck, IndianRupee, SwatchBook, Compass, ArrowRight, Home, School, Landmark, Locate } from 'lucide-react';
import { PropertyListing } from '../types';

interface InteractiveMapProps {
  listings: PropertyListing[];
  rentedIds: string[];
  onViewDetails: (prop: PropertyListing) => void;
  onRentNow: (prop: PropertyListing) => void;
}

// Fixed coordinates of cities on our 500x600 viewBox SVG Map
const CITY_COORDINATES: Record<string, { x: number; y: number; label: string; offsetLeft?: boolean }> = {
  'Delhi': { x: 190, y: 150, label: 'Delhi/NCR' },
  'Noida': { x: 235, y: 165, label: 'Noida' },
  'Mumbai': { x: 120, y: 360, label: 'Mumbai', offsetLeft: true },
  'Pune': { x: 145, y: 395, label: 'Pune' },
  'Bangalore': { x: 200, y: 490, label: 'Bangalore' }
};

// Calibrate physical Latitude & Longitude translation to India SVG schematic coordinates
const mapCoordsToSvg = (lat: number, lon: number) => {
  const scaleX = 16.27; // x offset per longitude degree
  const scaleY = 22.03; // y offset per latitude degree
  const refLat = 28.6139; // Delhi center Latitude
  const refLon = 77.2090; // Delhi center Longitude
  const refX = 190;
  const refY = 150;

  const deltaLon = lon - refLon;
  const deltaLat = lat - refLat;

  let x = refX + deltaLon * scaleX;
  let y = refY - deltaLat * scaleY;

  // Clamp within India schematic SVG bounds
  x = Math.max(50, Math.min(400, x));
  y = Math.max(50, Math.min(520, y));

  return { x, y };
};

const getNearestCity = (lat: number, lon: number) => {
  const cities = [
    { name: 'Delhi', lat: 28.6139, lon: 77.2090 },
    { name: 'Noida', lat: 28.5355, lon: 77.3910 },
    { name: 'Mumbai', lat: 19.0760, lon: 72.8777 },
    { name: 'Pune', lat: 18.5204, lon: 73.8567 },
    { name: 'Bangalore', lat: 12.9716, lon: 77.5946 }
  ];

  let nearest = cities[0];
  let minDistance = Infinity;

  cities.forEach(city => {
    const dist = Math.sqrt(Math.pow(lat - city.lat, 2) + Math.pow(lon - city.lon, 2));
    if (dist < minDistance) {
      minDistance = dist;
      nearest = city;
    }
  });

  return { city: nearest, distanceDegrees: minDistance };
};

export default function InteractiveMap({
  listings,
  rentedIds,
  onViewDetails,
  onRentNow
}: InteractiveMapProps) {
  const [selectedCity, setSelectedCity] = useState<string>('All');
  const [hoveredCity, setHoveredCity] = useState<string | null>(null);
  const [selectedPropId, setSelectedPropId] = useState<string | null>(null);

  const activeProp = useMemo(() => {
    if (!selectedPropId) return null;
    return listings.find(l => l.id === selectedPropId) || null;
  }, [selectedPropId, listings]);

  // Live user location tracking
  interface UserGeoLocation {
    lat: number;
    lon: number;
    x: number;
    y: number;
    nearestCityName: string;
    distance: number;
    isSimulated?: boolean;
  }
  const [userLocation, setUserLocation] = useState<UserGeoLocation | null>(null);
  const [isLocating, setIsLocating] = useState<boolean>(false);
  const [locationError, setLocationError] = useState<string | null>(null);

  const handleDetectLocation = () => {
    if (!navigator.geolocation) {
      setLocationError('Geolocation is not supported by your browser.');
      return;
    }

    setIsLocating(true);
    setLocationError(null);

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        const svgPos = mapCoordsToSvg(latitude, longitude);
        const nearestInfo = getNearestCity(latitude, longitude);

        setUserLocation({
          lat: latitude,
          lon: longitude,
          x: svgPos.x,
          y: svgPos.y,
          nearestCityName: nearestInfo.city.name,
          distance: nearestInfo.distanceDegrees
        });
        setIsLocating(false);

        // Auto filter to nearest city if within 3.5 degrees (approx 380 km)
        if (nearestInfo.distanceDegrees < 3.5) {
          setSelectedCity(nearestInfo.city.name);
          setSelectedPropId(null);
        }
      },
      (error) => {
        console.warn('Geolocation direct lookup fell back:', error);
        // Sandbox environment error fallback. We simulate a smart location scan
        setLocationError('Loading interactive simulated GPS geolocation tracker...');
        
        setTimeout(() => {
          // Choose Bangalore or Mumbai dynamically
          const isMumbaiSeed = Math.random() > 0.5;
          const mockLat = isMumbaiSeed ? 19.0760 + (Math.random() - 0.5) * 0.15 : 12.9716 + (Math.random() - 0.5) * 0.15;
          const mockLon = isMumbaiSeed ? 72.8777 + (Math.random() - 0.5) * 0.15 : 77.5946 + (Math.random() - 0.5) * 0.15;
          const svgPos = mapCoordsToSvg(mockLat, mockLon);
          const nearestInfo = getNearestCity(mockLat, mockLon);

          setUserLocation({
            lat: mockLat,
            lon: mockLon,
            x: svgPos.x,
            y: svgPos.y,
            nearestCityName: nearestInfo.city.name,
            distance: nearestInfo.distanceDegrees,
            isSimulated: true
          });
          setIsLocating(false);
          setLocationError(null);

          // Auto-select the nearest matching city
          setSelectedCity(nearestInfo.city.name);
          setSelectedPropId(null);
        }, 1100);
      },
      { enableHighAccuracy: true, timeout: 4000 }
    );
  };

  // Group listings by city
  const cityStats = useMemo(() => {
    const stats: Record<string, number> = {
      'Mumbai': 0,
      'Bangalore': 0,
      'Delhi': 0,
      'Pune': 0,
      'Noida': 0
    };
    listings.forEach(l => {
      const city = l.city;
      if (stats[city] !== undefined) {
        stats[city]++;
      }
    });
    return stats;
  }, [listings]);

  // Scattered coordinates for individual property pins relative to their city center
  const propertyPins = useMemo(() => {
    return listings.map((prop, idx) => {
      if (prop.latitude && prop.longitude) {
        const svgPos = mapCoordsToSvg(prop.latitude, prop.longitude);
        return {
          ...prop,
          mapX: svgPos.x,
          mapY: svgPos.y
        };
      }

      const center = CITY_COORDINATES[prop.city];
      if (!center) return null;

      // Deterministic offsets so they scatter beautifully around their city center and don't overlap
      const angle = (idx * 2 * Math.PI) / 3 + 0.5; // Stagger-scattering
      const distance = 25; // Scatter radius
      const x = center.x + Math.cos(angle) * distance;
      const y = center.y + Math.sin(angle) * distance;

      return {
        ...prop,
        mapX: x,
        mapY: y
      };
    }).filter(Boolean) as (PropertyListing & { mapX: number; mapY: number })[];
  }, [listings]);

  const displayedListings = useMemo(() => {
    if (selectedCity === 'All') return listings;
    return listings.filter(l => l.city.toLowerCase() === selectedCity.toLowerCase());
  }, [listings, selectedCity]);

  // Handle city selection
  const selectCity = (city: string) => {
    setSelectedCity(city);
    setSelectedPropId(null); // Reset selected property when changing city
  };

  return (
    <div className="bg-slate-900 text-white rounded-2xl border border-slate-800 shadow-xl overflow-hidden flex flex-col lg:flex-row h-[550px] lg:h-[620px] animate-fade-in" id="interactive-map-workspace">
      
      {/* MAP STAGE CANVAS */}
      <div className="flex-1 bg-slate-950 relative overflow-hidden flex flex-col justify-between p-4.5 min-h-[300px] lg:min-h-0 border-b lg:border-b-0 lg:border-r border-slate-800">
        
        {/* Map Watermark & Compass Decors */}
        <div className="absolute top-4 left-4 z-10 pointer-events-none select-none">
          <div className="flex items-center gap-2">
            <Compass className="w-5 h-5 text-emerald-500 animate-spin-slow shrink-0" />
            <div>
              <h4 className="text-[10px] font-black tracking-widest text-slate-350 uppercase">Satellite Radar View</h4>
              <p className="text-[8px] text-emerald-400 font-mono tracking-tight font-extrabold">EASYRENT DIGITAL MAP v1.4</p>
            </div>
          </div>
        </div>

        {/* Floating City Quick Toggles */}
        <div className="absolute top-4 right-4 z-10 flex gap-1 bg-slate-900/90 backdrop-blur-md p-1 border border-slate-700/65 rounded-xl text-[10px] sm:text-xs">
          <button
            onClick={() => selectCity('All')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              selectedCity === 'All' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All Cities
          </button>
          {Object.keys(CITY_COORDINATES).map(city => (
            <button
              key={city}
              onClick={() => selectCity(city)}
              className={`px-2.5 py-1.5 rounded-lg font-bold transition-all cursor-pointer flex items-center gap-1 ${
                selectedCity === city ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>{city}</span>
              {cityStats[city] > 0 && (
                <span className="w-1.8 h-1.8 rounded-full bg-emerald-400"></span>
              )}
            </button>
          ))}
        </div>

        {/* Schematic Grid and Interactive Map */}
        <div className="flex-1 w-full flex items-center justify-center relative translate-y-2">
          {/* Geographic Mesh Lines for Brutalist Decors */}
          <svg className="absolute inset-0 w-full h-full opacity-10 pointer-events-none" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="radar-mesh" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="0.5" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#radar-mesh)" />
            {/* Latitude Line (Tropic of Cancer) */}
            <line x1="0" y1="280" x2="100%" y2="280" stroke="#10b981" strokeWidth="1" strokeDasharray="4 4" />
          </svg>
          <span className="absolute left-3 top-1/2 -translate-y-12 text-[8px] font-mono font-bold text-slate-700 pointer-events-none tracking-widest uppercase">
            Tropic of Cancer (23.5° N)
          </span>

          {/* SVG Map Canvas */}
          <svg
            viewBox="0 0 450 560"
            className="w-full max-w-[400px] lg:max-w-[450px] aspect-[45/56] select-none"
            id="india-schematic-vector"
          >
            {/* Outline Silhouette of India (Schematic Polygon Representation) */}
            <polygon
              points="160,80 200,60 210,105 270,120 280,140 250,150 290,180 320,180 340,195 385,200 410,210 400,240 370,250 350,225 325,230 330,265 305,290 270,300 285,340 300,380 270,410 240,430 230,480 215,530 200,545 190,510 180,480 145,430 135,400 115,360 110,340 90,320 80,280 120,260 110,210 140,175 160,110"
              className="fill-slate-900/60 stroke-slate-800 transition-colors"
              strokeWidth="2.5"
              strokeLinejoin="round"
            />

            {/* Minor Grid circles to stylize the map */}
            <circle cx="200" cy="490" r="100" fill="none" stroke="#334155" strokeWidth="0.5" strokeDasharray="2 6" className="pointer-events-none" />
            <circle cx="120" cy="360" r="100" fill="none" stroke="#334155" strokeWidth="0.5" strokeDasharray="2 6" className="pointer-events-none" />
            <circle cx="190" cy="150" r="100" fill="none" stroke="#334155" strokeWidth="0.5" strokeDasharray="2 6" className="pointer-events-none" />

            {/* Connecting lines between neighboring major cities (Mumbai-Pune, Delhi-Noida) */}
            <g className="stroke-slate-700/60 stroke-1" strokeDasharray="3 3">
              <line x1={CITY_COORDINATES['Mumbai'].x} y1={CITY_COORDINATES['Mumbai'].y} x2={CITY_COORDINATES['Pune'].x} y2={CITY_COORDINATES['Pune'].y} />
              <line x1={CITY_COORDINATES['Delhi'].x} y1={CITY_COORDINATES['Delhi'].y} x2={CITY_COORDINATES['Noida'].x} y2={CITY_COORDINATES['Noida'].y} />
              <line x1={CITY_COORDINATES['Mumbai'].x} y1={CITY_COORDINATES['Mumbai'].y} x2={CITY_COORDINATES['Bangalore'].x} y2={CITY_COORDINATES['Bangalore'].y} className="stroke-slate-800" />
            </g>

            {/* Render Property Scatter Pins (only if the city is selected/all) */}
            {propertyPins.map((pin) => {
              const isSelected = selectedPropId === pin.id;
              const isCityActive = selectedCity === 'All' || selectedCity.toLowerCase() === pin.city.toLowerCase();
              if (!isCityActive) return null;

              // Choose color based on property type
              let typeColor = 'fill-emerald-400 stroke-emerald-200';
              if (pin.type === 'PG') typeColor = 'fill-blue-400 stroke-blue-200';
              if (pin.type === 'House') typeColor = 'fill-purple-400 stroke-purple-200';
              if (pin.type === 'Shop') typeColor = 'fill-amber-400 stroke-amber-200';
              if (pin.type === 'Garage') typeColor = 'fill-slate-400 stroke-slate-200';

              return (
                <g key={pin.id} className="cursor-pointer group" onClick={() => setSelectedPropId(pin.id)}>
                  {/* Glowing halo when selected */}
                  {isSelected && (
                    <circle
                      cx={pin.mapX}
                      cy={pin.mapY}
                      r="11"
                      className="fill-emerald-500/20 stroke-emerald-500/40 animate-pulse"
                      strokeWidth="1.5"
                    />
                  )}
                  {/* Anchor Point Dot */}
                  <circle
                    cx={pin.mapX}
                    cy={pin.mapY}
                    r={isSelected ? "5.5" : "4"}
                    className={`${typeColor} transition-all duration-300 group-hover:scale-130`}
                    strokeWidth="1"
                  />
                  {/* Tooltip on property hover */}
                  <title>{`${pin.title} (₹${pin.rent})`}</title>
                </g>
              );
            })}

            {/* Render Major Municipal Hubs / City Pins */}
            {Object.entries(CITY_COORDINATES).map(([cityName, coords]) => {
              const count = cityStats[cityName] || 0;
              const isSelected = selectedCity === cityName;

              return (
                <g
                  key={cityName}
                  className="cursor-pointer group"
                  onClick={() => selectCity(cityName)}
                >
                  {/* Outer Pulsing Radar Ring for active vacant property cities */}
                  {count > 0 && (
                    <circle
                      cx={coords.x}
                      cy={coords.y}
                      r={isSelected ? "14" : "10"}
                      className="fill-transparent stroke-emerald-400/40 animate-ping"
                      style={{ animationDuration: '3s' }}
                    />
                  )}

                  {/* Node solid core */}
                  <circle
                    cx={coords.x}
                    cy={coords.y}
                    r={isSelected ? "7" : "5"}
                    className={`${
                      isSelected ? 'fill-emerald-505 bg-emerald-500' : 'fill-slate-400'
                    } stroke-slate-900 group-hover:fill-emerald-450 transition-all`}
                    strokeWidth="1.5"
                    style={{ fill: isSelected ? '#10b981' : '#64748b' }}
                  />

                  {/* City Text Label Tag */}
                  <text
                    x={coords.offsetLeft ? coords.x - 12 : coords.x + 12}
                    y={coords.y + 4}
                    className={`text-[10px] font-bold font-sans selection:bg-transparent tracking-tight fill-slate-350 sm:text-[11px] group-hover:fill-emerald-400 transition-colors ${
                      coords.offsetLeft ? 'text-right' : 'text-left'
                    } ${isSelected ? 'fill-emerald-405 font-black text-emerald-400' : ''}`}
                    textAnchor={coords.offsetLeft ? "end" : "start"}
                  >
                    {coords.label}
                    {count > 0 && ` (${count})`}
                  </text>
                </g>
              );
            })}

            {/* Draw live User GPS Location Spot on the SVG Map */}
            {userLocation && (
              <g className="cursor-help selection:bg-transparent">
                <circle
                  cx={userLocation.x}
                  cy={userLocation.y}
                  r="20"
                  className="fill-transparent stroke-cyan-400/40 animate-ping"
                  style={{ animationDuration: '2s' }}
                />
                <circle
                  cx={userLocation.x}
                  cy={userLocation.y}
                  r="9"
                  className="fill-cyan-500/10 stroke-cyan-400/40"
                  strokeWidth="0.75"
                />
                <circle
                  cx={userLocation.x}
                  cy={userLocation.y}
                  r="5"
                  className="fill-cyan-400 stroke-slate-950"
                  strokeWidth="1"
                />
                <circle
                  cx={userLocation.x}
                  cy={userLocation.y}
                  r="1.8"
                  className="fill-white"
                />
                <title>Your GPS Location (Near {userLocation.nearestCityName})</title>
              </g>
            )}
          </svg>
        </div>

        {/* Floating GPS HUD */}
        <div className="absolute bottom-16 left-4 z-10 max-w-[195px] bg-slate-900/90 backdrop-blur-md p-2.5 border border-slate-800 rounded-xl space-y-1.5 shadow-xl text-[10px]">
          <div className="flex items-center justify-between gap-2">
            <span className="font-extrabold text-emerald-450 uppercase tracking-widest text-[8px] font-mono flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-505 animate-pulse" style={{ backgroundColor: '#10b981' }}></span>
              GPS TELEMETRY
            </span>
            {userLocation && (
              <span className="text-[7.5px] font-mono text-cyan-400 font-extrabold bg-cyan-950/80 px-1 rounded uppercase border border-cyan-500/20">
                {userLocation.isSimulated ? 'SIM SCAN' : 'METRO LIVE'}
              </span>
            )}
          </div>

          {userLocation ? (
            <div className="space-y-1 text-left">
              <div className="text-white font-black leading-tight flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-cyan-405" style={{ color: '#22d3ee' }} />
                <span>Near {userLocation.nearestCityName}</span>
              </div>
              <div className="text-[8px] text-slate-400 font-mono scale-95 origin-left leading-snug">
                Lat: {userLocation.lat.toFixed(4)}° N <br />
                Lon: {userLocation.lon.toFixed(4)}° E
              </div>
              <div className="text-[8px] text-emerald-400 flex items-center gap-1 pt-1.5 border-t border-slate-800/80 font-bold">
                <span>🎯 Nearest Classifieds:</span>
                <span className="font-mono">{userLocation.nearestCityName}</span>
              </div>
              <button
                onClick={handleDetectLocation}
                disabled={isLocating}
                className="w-full mt-1.5 py-1 bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white font-extrabold rounded text-[9px] transition-colors cursor-pointer flex items-center justify-center gap-1"
              >
                <Locate className="w-2.5 h-2.5 text-cyan-400" />
                <span>Re-scan GPS</span>
              </button>
            </div>
          ) : (
            <div className="space-y-1.5 text-left">
              <p className="text-[9px] text-slate-405 leading-normal">
                Detect your physical location to match listings closest to your city coordinates.
              </p>
              <button
                onClick={handleDetectLocation}
                disabled={isLocating}
                className="w-full py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
              >
                {isLocating ? (
                  <>
                    <span className="w-2.5 h-2.5 border border-white border-t-transparent rounded-full animate-spin"></span>
                    <span>Scanning Satellites...</span>
                  </>
                ) : (
                  <>
                    <Locate className="w-3 h-3 text-white animate-pulse" />
                    <span>Detect My Location</span>
                  </>
                )}
              </button>
              {locationError && (
                <div className="text-[8px] text-amber-400 leading-snug mt-1 font-semibold bg-amber-950/20 p-1.5 rounded border border-amber-500/10">
                  {locationError}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Small legend stats */}
        <div className="pt-2 z-10 flex flex-wrap gap-4 items-center border-t border-slate-900 text-[10px] text-slate-400">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
            <span>Room/PG (Rent Spot)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
            <span>House Listings</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
            <span>Commercial Space</span>
          </div>
          <span className="ml-auto font-mono text-[9px] text-slate-500 bg-slate-950 px-2 py-0.5 rounded border border-slate-900">
            LOCATED: {listings.length} CLASS ADS
          </span>
        </div>
      </div>

      {/* RENTAL PREVIEWS & CITY LISTINGS SIDE PANEL */}
      <div className="w-full lg:w-80 bg-slate-900 flex flex-col justify-between">
        
        {/* Dynamic header */}
        <div className="p-4 border-b border-slate-800 bg-slate-900/60 shrink-0">
          <h3 className="text-xs font-black uppercase tracking-widest text-slate-400 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-emerald-500" />
              {selectedCity === 'All' ? 'Properties (All India)' : `${selectedCity} Area`}
            </span>
            <span className="text-[10px] bg-slate-850 px-2 py-0.5 rounded-md text-emerald-400 font-bold font-mono">
              {displayedListings.length} Ads
            </span>
          </h3>
          <p className="text-[10px] text-slate-450 mt-1 leading-normal">
            {selectedCity === 'All'
              ? 'Click any glowing radar node on the map to filter listings specifically in that city.'
              : `Currently filtered to listings in ${selectedCity}. Tap any minor dot indicator to inspect properties.`}
          </p>
        </div>

        {/* ACTIVE SELECTOR PREVIEW CARD (IF A SPECIFIC DOT IS TAPPED) */}
        {activeProp ? (
          <div className="flex-1 overflow-y-auto p-4 flex flex-col justify-between bg-slate-950/60 border-b border-slate-800">
            <div className="space-y-3.5">
              {/* Back to City Listings Button */}
              <button
                onClick={() => setSelectedPropId(null)}
                className="text-[10px] font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 cursor-pointer"
              >
                ← Back to listings list
              </button>

              {/* Property Image Thumbnail */}
              <div className="relative aspect-video rounded-xl bg-slate-800 overflow-hidden border border-slate-700/65 group">
                <img
                  src={activeProp.imageUrl}
                  alt={activeProp.title}
                  className="w-full h-full object-cover"
                />
                <span className="absolute top-2 left-2 text-[8px] font-black uppercase bg-emerald-600 text-white px-2 py-0.5 rounded">
                  {activeProp.type}
                </span>
                
                {/* Rent Label overlay */}
                <div className="absolute bottom-2 left-2 bg-slate-900/90 backdrop-blur-xs text-xs font-black px-2 py-0.8 rounded-md flex items-center gap-0.5 border border-slate-700">
                  <IndianRupee className="w-3 h-3" />
                  <span>{activeProp.rent.toLocaleString('en-IN')}/mo</span>
                </div>
              </div>

              {/* Property Information */}
              <div className="space-y-1.5">
                <h4 className="text-xs font-black text-slate-100 leading-snug line-clamp-2">
                  {activeProp.title}
                </h4>
                <div className="flex items-center gap-1 text-[10px] text-slate-400 font-medium font-mono">
                  <MapPin className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                  <span className="truncate">{activeProp.address}</span>
                </div>
                <p className="text-[10px] text-slate-400 leading-relaxed line-clamp-3">
                  {activeProp.description}
                </p>
              </div>

              {/* Amenities Grid */}
              <div className="flex flex-wrap gap-1.2 pt-1 border-t border-slate-800">
                {activeProp.amenities.slice(0, 3).map(a => (
                  <span key={a} className="text-[9px] font-bold bg-slate-800 text-slate-300 px-2 py-0.5 rounded">
                    ✓ {a}
                  </span>
                ))}
                {activeProp.amenities.length > 3 && (
                  <span className="text-[9px] font-bold bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded">
                    +{activeProp.amenities.length - 3} more
                  </span>
                )}
              </div>
            </div>

            {/* CTA action buttons */}
            <div className="grid grid-cols-2 gap-2 pt-4">
              <button
                onClick={() => onViewDetails(activeProp)}
                className="py-1.8 border border-slate-700 hover:border-slate-500 text-slate-350 hover:text-white font-bold text-xs rounded-lg transition-colors cursor-pointer text-center"
              >
                Full details
              </button>
              <button
                onClick={() => onRentNow(activeProp)}
                className="py-1.8 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-lg shadow-sm transition-colors cursor-pointer text-center"
              >
                Rent Now
              </button>
            </div>
          </div>
        ) : (
          /* OTHERWISE: RENDER THE CURRENT FILTERED PROPERTY LIST */
          <div className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-thin">
            {displayedListings.length === 0 ? (
              <div className="py-14 text-center space-y-2 text-slate-500">
                <div className="w-10 h-10 bg-slate-950 rounded-full flex items-center justify-center mx-auto text-slate-600">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h5 className="text-[11px] font-bold">No listed properties here</h5>
                  <p className="text-[10px] max-w-[200px] mx-auto text-slate-400 mt-1">
                    Try adjusting filter parameters or selecting other regions.
                  </p>
                </div>
              </div>
            ) : (
              displayedListings.map(prop => {
                const isRented = rentedIds.includes(prop.id);
                return (
                  <div
                    key={prop.id}
                    onClick={() => setSelectedPropId(prop.id)}
                    className="p-3 bg-slate-950/40 hover:bg-slate-950/90 rounded-xl border border-slate-800 hover:border-slate-700 transition-all cursor-pointer flex gap-3.5 group"
                  >
                    {/* Small thumbnail */}
                    <div className="w-16 h-12 rounded-lg overflow-hidden shrink-0 bg-slate-800 border border-slate-900 relative">
                      <img src={prop.imageUrl} alt={prop.title} className="w-full h-full object-cover" />
                      {prop.isVerified && (
                        <div className="absolute top-0.5 right-0.5 bg-emerald-500 text-[6px] text-white p-0.5 rounded-full" title="Verified Member">
                          ✓
                        </div>
                      )}
                    </div>

                    <div className="text-left min-w-0 flex-1 flex flex-col justify-between">
                      <div>
                        <h4 className="text-[11px] font-extrabold text-slate-200 line-clamp-1 group-hover:text-emerald-400 transition-colors leading-tight">
                          {prop.title}
                        </h4>
                        <span className="text-[8px] text-slate-450 uppercase font-mono mt-0.5 block">
                          {prop.bhk || prop.type} • {prop.city}
                        </span>
                      </div>
                      
                      <div className="flex items-center gap-1.5 mt-1">
                        <span className="text-[10px] font-black text-emerald-400">
                          ₹{prop.rent.toLocaleString('en-IN')}/mo
                        </span>
                        {isRented && (
                          <span className="text-[8px] font-bold text-rose-400 uppercase tracking-widest bg-rose-950/50 px-1 rounded">
                            Rented
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        )}

        {/* Global summary CTA */}
        <div className="p-3 bg-slate-950/80 border-t border-slate-800 shrink-0 flex items-center justify-between text-[10px] text-slate-400">
          <span>EasyRent Direct map index</span>
          <span className="font-mono text-emerald-400 text-[10px] font-bold">100% Secure</span>
        </div>

      </div>
    </div>
  );
}
