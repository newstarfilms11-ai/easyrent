/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState } from 'react';
import { ExternalLink, X, Info, ShieldAlert } from 'lucide-react';

interface GoogleAdProps {
  placement?: 'leaderboard' | 'square' | 'sidebar';
  className?: string;
}

const AD_CREATIVES = [
  {
    title: 'Rentomojo Home Appliances',
    description: 'Why buy when you can rent? Rent premium furniture, refrigerators, and smart TVs starting at just ₹199/month. Free delivery and installation!',
    cta: 'Rent Now',
    link: 'https://www.rentomojo.com',
    imageUrl: 'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&w=400&q=80',
    tagline: 'Rent Smart with Rentomojo'
  },
  {
    title: 'Airtel Xstream Fiber Connection',
    description: 'Get blazing fast internet up to 1Gbps, unlimited data, and a free 4K Wi-Fi router + subscription to 17+ OTT channels. Starts at ₹499/mo.',
    cta: 'Apply Online',
    link: 'https://www.airtel.in/broadband',
    imageUrl: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=400&q=80',
    tagline: 'India\'s Safest Wi-Fi'
  },
  {
    title: 'IKEA Modular Living Room Deals',
    description: 'Discover versatile storage cabinets, plush sofa sets, and sleek coffee tables designed for urban rent houses. Flat 15% off on your first order.',
    cta: 'Explore Catalog',
    link: 'https://www.ikea.com/in/en/',
    imageUrl: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=400&q=80',
    tagline: 'Affordable Dream Homemaking'
  },
  {
    title: 'HomeLane Interior Designs',
    description: 'Get end-to-end modular kitchen and wardrobe interiors delivered in 45 days or we pay you rent! Meet our designer virtually today.',
    cta: 'Book Free Demo',
    link: 'https://www.homelane.com',
    imageUrl: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=400&q=80',
    tagline: '45-Day Delivery Guarantee'
  }
];

export default function GoogleAd({ placement = 'leaderboard', className = '' }: GoogleAdProps) {
  const [adIndex, setAdIndex] = useState(() => Math.floor(Math.random() * AD_CREATIVES.length));
  const [isClosed, setIsClosed] = useState(false);
  const [feedbackSent, setFeedbackSent] = useState(false);

  const activeAd = AD_CREATIVES[adIndex];

  if (isClosed) {
    if (feedbackSent) {
      return (
        <div className="bg-gray-100 border border-gray-200 rounded-lg p-3 text-center text-[11px] text-gray-500 font-medium">
          Ad dismissed. Thank you for your feedback! This space will refresh later.
        </div>
      );
    }

    return (
      <div className="bg-gray-50 border border-gray-200 rounded-lg p-3 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-gray-600 font-medium">
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-emerald-600" />
          <span>Google Ads: Why did you close this ad?</span>
        </div>
        <div className="flex gap-2 text-[10px]">
          {['Irrelevant', 'Repetitive', 'Inappropriate'].map((reason) => (
            <button
              key={reason}
              onClick={() => setFeedbackSent(true)}
              className="px-2.5 py-1 bg-white hover:bg-gray-100 border rounded cursor-pointer font-bold text-gray-700 transition-colors"
            >
              {reason}
            </button>
          ))}
          <button
            onClick={() => setIsClosed(false)}
            className="px-2.5 py-1 text-gray-400 hover:text-gray-600 transition-colors cursor-pointer underline"
          >
            Undo
          </button>
        </div>
      </div>
    );
  }

  // Display Leaderboard Mode (Horizontal Banner)
  if (placement === 'leaderboard') {
    return (
      <div className={`relative bg-amber-50/40 border border-amber-200/50 rounded-2xl p-4 overflow-hidden shadow-2xs hover:shadow-xs transition-shadow flex flex-col md:flex-row items-center gap-4 ${className}`} id="google-ad-leaderboard">
        
        {/* Adsense Official Badging info */}
        <div className="absolute top-1 right-2 flex items-center gap-1 selection:bg-transparent text-[8px] font-bold text-gray-400">
          <span>Ads by Google</span>
          <Info className="w-2.5 h-2.5 cursor-pointer text-gray-450 hover:text-blue-500" title="Ad Settings" />
          <button
            onClick={() => setIsClosed(true)}
            className="ml-1 text-gray-400 hover:text-gray-700 font-black p-0.5"
            title="Close Ad"
          >
            <X className="w-3 h-3" />
          </button>
        </div>

        {/* Sponsor Tag */}
        <span className="absolute top-2 left-2 bg-amber-500/10 text-amber-800 text-[8px] font-extrabold uppercase px-1.5 py-0.2 rounded border border-amber-500/20">
          SPONSORED AD
        </span>

        {/* Ad Image Thumbnail */}
        <div className="w-24 h-16 rounded-lg overflow-hidden shrink-0 bg-gray-100 border border-gray-250/70 shadow-3xs hidden sm:block">
          <img src={activeAd.imageUrl} alt="Sponsor" className="w-full h-full object-cover" />
        </div>

        {/* Ad Copy */}
        <div className="flex-1 text-center md:text-left space-y-1 pt-1.5 md:pt-0">
          <div className="flex items-center justify-center md:justify-start gap-1.5">
            <h4 className="text-xs font-black text-gray-900">{activeAd.title}</h4>
            <span className="text-[9px] font-extrabold text-gray-400 font-mono">({activeAd.tagline})</span>
          </div>
          <p className="text-[11px] text-gray-500 leading-normal max-w-2xl">
            {activeAd.description}
          </p>
        </div>

        {/* CTA Button */}
        <a
          href={activeAd.link}
          target="_blank"
          rel="noopener noreferrer"
          className="px-4.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl flex items-center gap-1.5 shadow-sm hover:shadow-md transition-all shrink-0 cursor-pointer text-center"
        >
          <span>{activeAd.cta}</span>
          <ExternalLink className="w-3.5 h-3.5" />
        </a>
      </div>
    );
  }

  // Display Square Banner (Compact vertical widget)
  return (
    <div className={`relative bg-amber-50/40 border border-amber-200/50 rounded-2xl p-4.5 overflow-hidden shadow-2xs space-y-3 ${className}`} id="google-ad-square">
      
      {/* Ad info badge */}
      <div className="flex items-center justify-between">
        <span className="bg-amber-500/10 text-amber-800 text-[8px] font-extrabold uppercase px-1.5 py-0.5 rounded border border-amber-500/20">
          SPONSOR BY GOOGLE
        </span>
        <div className="flex items-center gap-1 text-[8px] font-bold text-gray-400">
          <span>Ads by Google</span>
          <Info className="w-2.5 h-2.5 cursor-pointer hover:text-blue-500" />
          <button onClick={() => setIsClosed(true)} className="ml-0.5 text-gray-400 hover:text-gray-700">
            <X className="w-3 h-3" />
          </button>
        </div>
      </div>

      <div className="aspect-video w-full rounded-xl overflow-hidden bg-gray-100 border shadow-3xs">
        <img src={activeAd.imageUrl} alt="Sponsor Media" className="w-full h-full object-cover" />
      </div>

      <div className="space-y-1">
        <h4 className="text-xs font-black text-gray-900 leading-tight">{activeAd.title}</h4>
        <p className="text-[10px] text-gray-500 leading-normal">
          {activeAd.description}
        </p>
      </div>

      <a
        href={activeAd.link}
        target="_blank"
        rel="noopener noreferrer"
        className="w-full py-1.8 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-[11px] rounded-lg tracking-wider uppercase text-center flex items-center justify-center gap-1 transition-colors cursor-pointer"
      >
        <span>{activeAd.cta}</span>
        <ExternalLink className="w-3 h-3" />
      </a>
    </div>
  );
}
