import React, { useState, useEffect } from 'react';
import {
  QrCode,
  CheckCircle,
  Copy,
  Printer,
  Calendar,
  IndianRupee,
  User,
  Building,
  ArrowRight,
  ShieldCheck,
  AlertCircle,
  Download,
  Info,
  RefreshCw,
  Sparkles
} from 'lucide-react';
import { RentalAgreement } from '../types';

interface QRPaymentSlipProps {
  rentals: RentalAgreement[];
  onPaymentSuccess?: (leaseId: string, amount: number, txRef: string) => void;
}

export default function QRPaymentSlip({ rentals, onPaymentSuccess }: QRPaymentSlipProps) {
  // Preset Values to match user's image exactly by default
  const DEFAULT_UPI_ID = 'newstarfilms11@okhdfcbank';
  const DEFAULT_MERCHANT_NAME = 'NewStar Films';

  // State Management
  const [selectedLease, setSelectedLease] = useState<RentalAgreement | 'custom'>(
    rentals.length > 0 ? rentals[0] : 'custom'
  );

  // Custom Form fields (if custom billing or overriding values)
  const [landlordName, setLandlordName] = useState(DEFAULT_MERCHANT_NAME);
  const [landlordUpi, setLandlordUpi] = useState(DEFAULT_UPI_ID);
  const [tenantName, setTenantName] = useState('Rahul Sharma');
  const [propertyName, setPropertyName] = useState('Premium Single AC Room, Saki Naka');
  const [rentAmount, setRentAmount] = useState<number>(11500);
  const [billingMonth, setBillingMonth] = useState<string>('June 2026');
  
  // Payment Flow States
  const [txReference, setTxReference] = useState('');
  const [enteredUtr, setEnteredUtr] = useState('');
  const [paymentStatus, setPaymentStatus] = useState<'pending' | 'verified' | 'failed'>('pending');
  const [copiedText, setCopiedText] = useState(false);
  const [slipVerifiedAt, setSlipVerifiedAt] = useState<string>('');
  
  // Effect: Update values when selectedLease changes
  useEffect(() => {
    if (selectedLease && selectedLease !== 'custom') {
      const rental = selectedLease as RentalAgreement;
      setLandlordName(rental.ownerName || DEFAULT_MERCHANT_NAME);
      // Generate a realistic upi format based on owner name or keep custom
      setLandlordUpi(DEFAULT_UPI_ID); 
      setPropertyName(rental.propertyTitle);
      setRentAmount(rental.rent);
      setTenantName('Rahul Sharma'); // Active User

      // Calculate next billing month/year
      if (rental.nextDueDate) {
        const parts = rental.nextDueDate.split(' ');
        if (parts.length >= 2) {
          setBillingMonth(`${parts[1]} ${parts[2] || '2026'}`);
        } else {
          setBillingMonth('June 2026');
        }
      } else {
        setBillingMonth('June 2026');
      }
    }
  }, [selectedLease]);

  // Handle unique reference number generation
  const generateReferenceNumber = () => {
    const prefix = 'NSF';
    const timestamp = Date.now().toString().slice(-6);
    const random = Math.floor(Math.random() * 900 + 100);
    return `${prefix}-RENT-${timestamp}-${random}`;
  };

  useEffect(() => {
    setTxReference(generateReferenceNumber());
  }, [selectedLease, rentAmount, billingMonth]);

  // Construct UPI payment URI
  // Schema: upi://pay?pa=recipient@upi&pn=RecipientName&am=Amount&cu=INR&tn=CustomNote
  const encodedPn = encodeURIComponent(landlordName);
  const encodedNote = encodeURIComponent(`Rent ${billingMonth} ${txReference.slice(-8)}`);
  const upiUri = `upi://pay?pa=${landlordUpi}&pn=${encodedPn}&am=${rentAmount}&cu=INR&tn=${encodedNote}`;
  
  // Real high-contrast API QR Code url
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=350x350&data=${encodeURIComponent(upiUri)}`;

  // Copy UPI ID to clipboard
  const handleCopyUpi = () => {
    navigator.clipboard.writeText(landlordUpi);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  // Process the UTR verification
  const handleVerifyPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!enteredUtr.trim()) return;
    if (enteredUtr.length < 8) {
      alert('Please enter a valid Bank UTR / Transaction ID (8-12 digits).');
      return;
    }

    setPaymentStatus('verified');
    setSlipVerifiedAt(new Date().toLocaleString());

    if (selectedLease !== 'custom' && onPaymentSuccess) {
      onPaymentSuccess(selectedLease.id, rentAmount, txReference);
    }
  };

  // Reset verification to update values
  const handleResetVerification = () => {
    setPaymentStatus('pending');
    setEnteredUtr('');
    setTxReference(generateReferenceNumber());
  };

  // Print current page segment (Slip) rather than whole site
  const handlePrintSlip = () => {
    window.print();
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 text-gray-800" id="qr-rent-payment-module">
      
      {/* Module Title Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8 pb-3 border-b border-gray-150">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white shadow-md animate-pulse">
            <QrCode className="w-5.5 h-5.5" />
          </div>
          <div>
            <h2 className="text-xl font-black text-gray-900 tracking-tight leading-none">QR Rent pay Hub</h2>
            <p className="text-xs text-gray-400 mt-1.5">Generate verified instant UPI codes, process monthly payments, and issue certified tax slips.</p>
          </div>
        </div>

        {/* Lease Switch Selector */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-gray-500 whitespace-nowrap">Paying for:</span>
          <select
            className="text-xs font-semibold px-3 py-2 bg-slate-50 border border-gray-200 rounded-lg text-gray-700 focus:outline-hidden focus:border-emerald-500"
            value={selectedLease === 'custom' ? 'custom' : (selectedLease as RentalAgreement).id}
            onChange={(e) => {
              const val = e.target.value;
              if (val === 'custom') {
                setSelectedLease('custom');
              } else {
                const found = rentals.find(r => r.id === val);
                if (found) setSelectedLease(found);
              }
            }}
          >
            {rentals.map((r) => (
              <option key={r.id} value={r.id}>
                {r.propertyTitle} (₹{r.rent}/mo)
              </option>
            ))}
            <option value="custom">✍️ Custom Receipt (Manual input)</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* LEFT COMPONENT COLUMN: Controls & Input Parameters (Lg Span 5) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white rounded-2xl border border-gray-150 p-5 shadow-xs space-y-4">
            <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              Payment Slip Generator
            </h3>

            {/* Custom Input options if Owner name, etc override */}
            <div className="space-y-3.5 pt-1.5">
              
              {selectedLease === 'custom' && (
                <>
                  <div>
                    <label className="block text-[11px] font-bold text-gray-650 mb-1">Landlord / Merchant Name</label>
                    <input
                      type="text"
                      className="w-full text-xs px-3 py-1.8 bg-white border border-gray-205 rounded-lg text-gray-800 focus:outline-hidden focus:border-emerald-500"
                      value={landlordName}
                      onChange={(e) => setLandlordName(e.target.value)}
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-gray-650 mb-1">Landlord UPI Address (Receiver PA)</label>
                    <div className="relative">
                      <input
                        type="text"
                        className="w-full text-xs px-3 py-1.8 bg-white border border-gray-205 rounded-lg text-gray-800 focus:outline-hidden focus:border-emerald-505 font-mono"
                        value={landlordUpi}
                        onChange={(e) => setLandlordUpi(e.target.value)}
                      />
                      <span className="absolute right-3.5 top-2 text-[10px] text-gray-400 font-bold">UPI ID</span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-gray-650 mb-1">Tenant Full Name</label>
                    <input
                      type="text"
                      className="w-full text-xs px-3 py-1.8 bg-white border border-gray-205 rounded-lg text-gray-800 focus:outline-hidden"
                      value={tenantName}
                      onChange={(e) => setTenantName(e.target.value)}
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-gray-650 mb-1">Property Accommodation Title</label>
                    <input
                      type="text"
                      className="w-full text-xs px-3 py-1.8 bg-white border border-gray-205 rounded-lg text-gray-800 focus:outline-hidden"
                      value={propertyName}
                      onChange={(e) => setPropertyName(e.target.value)}
                    />
                  </div>
                </>
              )}

              {/* Common mutable fields */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-gray-500 uppercase">Rent payable (₹)</label>
                  <div className="relative mt-1">
                    <span className="absolute left-3 top-2.5 text-xs text-gray-400 font-bold">₹</span>
                    <input
                      type="number"
                      className="w-full text-xs pl-6.5 pr-3 py-2.2 bg-white border border-gray-205 rounded-lg text-gray-800 focus:outline-hidden focus:border-emerald-500 font-extrabold"
                      value={rentAmount}
                      onChange={(e) => setRentAmount(Math.max(1, Number(e.target.value)))}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-gray-500 uppercase">Rent Month Cycle</label>
                  <input
                    type="text"
                    placeholder="e.g. June 2026"
                    className="w-full text-xs px-3 py-2.2 bg-white border border-gray-205 lg:mt-1 rounded-lg text-gray-800 focus:outline-hidden focus:border-emerald-500 font-bold"
                    value={billingMonth}
                    onChange={(e) => setBillingMonth(e.target.value)}
                  />
                </div>
              </div>

              {/* Static specs */}
              <div className="p-3 bg-slate-50 border border-slate-150 rounded-xl space-y-1.5 text-xs">
                <div className="flex justify-between text-[11px]">
                  <span className="text-gray-400 font-medium">Merchant Account:</span>
                  <span className="font-extrabold text-gray-700">{landlordName}</span>
                </div>
                <div className="flex justify-between text-[11px]">
                  <span className="text-gray-400 font-medium">Receiver UPI VPA:</span>
                  <span className="font-mono text-[10px] text-gray-600 truncate max-w-[150px]">{landlordUpi}</span>
                </div>
                <div className="flex justify-between text-[11px] border-t border-slate-200 pt-1.5 font-bold">
                  <span className="text-gray-600">Secure Slip Reference:</span>
                  <span className="text-emerald-700 font-mono text-[9.5px] uppercase">{txReference}</span>
                </div>
              </div>

            </div>
          </div>

          {/* Secure Bank UTR Ledger verification */}
          <div className="bg-gradient-to-br from-emerald-700 via-emerald-800 to-teal-900 rounded-2xl p-5 text-white shadow-sm space-y-4">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5.5 h-5.5 text-emerald-400" />
              <h3 className="font-bold text-xs uppercase tracking-widest text-emerald-100">Step 2: Settlement Verification</h3>
            </div>

            {paymentStatus === 'pending' ? (
              <form onSubmit={handleVerifyPayment} className="space-y-3">
                <p className="text-[11px] text-emerald-100 leading-normal">
                  After scanning and executing the transaction on your GPay, PhonePe, Paytm, or BHIM app, please enter your <strong>12-digit Bank Transaction ID (UTR or Ref Number)</strong> to secure and verify your rent record instantly.
                </p>
                <div>
                  <label className="block text-[10.5px] font-bold text-emerald-250 mb-1">Enter Transaction ID / Bank Ref No *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 613589416528"
                    className="w-full text-xs font-mono font-bold bg-white/10 hover:bg-white/15 focus:bg-white border border-white/20 focus:border-white text-white focus:text-gray-900 placeholder-white/40 focus:placeholder-gray-400 px-3 py-2.5 rounded-lg outline-hidden tracking-widest text-center"
                    value={enteredUtr}
                    onChange={(e) => setEnteredUtr(e.target.value.replace(/[^a-zA-Z0-9-]/g, ''))}
                  />
                  <span className="text-[9px] text-emerald-200 mt-0.5 block leading-tight">Must match the UTR receipt from your payment app.</span>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-white hover:bg-emerald-50 text-emerald-850 font-black rounded-lg text-xs transition-colors shadow-md cursor-pointer flex items-center justify-center gap-1.5"
                >
                  Confirm &amp; generate Slip
                </button>
              </form>
            ) : (
              <div className="space-y-3.5 bg-white/5 p-4 rounded-xl border border-white/10 text-left animate-fade-in text-xs">
                <div className="flex items-center gap-2 text-emerald-300 font-extrabold text-[13px]">
                  <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
                  <span>TRANSACTION VERIFIED ✓</span>
                </div>
                <p className="text-[11px] text-emerald-100 leading-relaxed">
                  The payment slip has been cryptographically signed and archived on easyrent.in's direct tenancy database successfully. Your landlord will receive instant ledger credit.
                </p>
                <div className="border-t border-white/10 pt-2 text-[10.5px] font-mono text-emerald-150 space-y-1">
                  <div>BANK UTR: <span className="font-bold text-white tracking-widest">{enteredUtr}</span></div>
                  <div>SECURE REF: <span className="text-white font-bold">{txReference}</span></div>
                  <div>TIMESTAMP: <span className="text-white">{slipVerifiedAt}</span></div>
                </div>

                <div className="flex gap-2.5 pt-1">
                  <button
                    onClick={handlePrintSlip}
                    className="flex-1 py-1.8 bg-emerald-500 hover:bg-emerald-600 text-white font-extrabold rounded-md text-[11px] flex items-center justify-center gap-1 transition-all cursor-pointer shadow-xs"
                  >
                    <Printer className="w-3.5 h-3.5" /> Print receipt
                  </button>
                  <button
                    onClick={handleResetVerification}
                    className="px-2.5 py-1.8 bg-white/10 hover:bg-white/15 text-emerald-100 hover:text-white rounded-md text-[11px] font-semibold transition-all cursor-pointer"
                  >
                    Pay Next Rent
                  </button>
                </div>
              </div>
            )}
          </div>

          <div className="p-4 bg-amber-50 border border-amber-150 rounded-xl flex items-start gap-2.5">
            <Info className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <span className="text-[11px] font-bold text-amber-900 block">UPI Autopay Guarantee</span>
              <p className="text-[10px] text-amber-705 leading-relaxed">
                Paying direct on UPI prevents arbitrary bank processing commissions. Zero gateway charge is completely applicable to both landords and renters.
              </p>
            </div>
          </div>

        </div>

        {/* RIGHT COLUMN: Pixel-Perfect Visual UPI & Slip Card Interface (Lg Span 7) */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Card Wrapper for QR Generation exactly matching the uploaded visual assets */}
          <div className="bg-slate-100 rounded-3xl p-6 md:p-8 flex flex-col items-center justify-center border border-slate-200/65 shadow-md relative overflow-hidden" id="printed-slip-card">
            
            {/* Background design elements to make it extremely premium */}
            <div className="absolute top-0 left-0 right-0 h-40 bg-gradient-to-b from-blue-100/30 to-transparent pointer-events-none"></div>
            <div className="absolute -left-12 -top-12 w-48 h-48 rounded-full bg-emerald-500/5 blur-3xl pointer-events-none"></div>

            {/* Print Friendly Header */}
            <div className="flex items-center gap-2 mb-4 relative z-10">
              {/* Custom SVG logo representing a star badge in a double oval circular crest (matches NewStar Films upload) */}
              <div className="w-10 h-10 rounded-full border border-gray-300/60 bg-white flex items-center justify-center shadow-xs overflow-hidden">
                <div className="w-[84%] h-[84%] bg-slate-900 rounded-full flex items-center justify-center relative border border-amber-500">
                  <span className="text-amber-400 font-black text-xs font-serif italic">NSF</span>
                  <div className="absolute -top-0.5 text-[5px] text-white">★</div>
                </div>
              </div>
              <div className="text-left font-sans">
                <span className="text-base font-black text-slate-850 tracking-tight block leading-none">{landlordName}</span>
                <span className="text-[9px] font-mono tracking-widest text-gray-500 uppercase block mt-1">Unified Rent Gateway</span>
              </div>
            </div>

            {/* THE VISUAL PHONE/SLIP SCREEN CARD (Pure white with 2rem curved border) */}
            <div className="w-full max-w-[340px] bg-white rounded-[2rem] shadow-xl p-5 border border-slate-150 flex flex-col items-center justify-center transition-all hover:scale-101 relative z-10">
              
              {/* Mini Top Banner details */}
              <div className="w-full text-center pb-3 mb-4.5 border-b border-dashed border-gray-150">
                <span className="text-[10px] font-black tracking-widest text-emerald-600 bg-emerald-50 border border-emerald-100 rounded-full px-3 py-0.5">
                  RENT INVOICE • {billingMonth.toUpperCase()}
                </span>
                <p className="text-lg font-black text-gray-900 mt-2">₹{rentAmount.toLocaleString('en-IN')}.00</p>
                <span className="text-[9.5px] text-gray-400 font-mono block mt-0.5">REF: {txReference.slice(0, 18)}...</span>
              </div>

              {/* The Actual QR Code Image Wrapper */}
              <div className="relative w-56 h-56 md:w-60 md:h-60 bg-white rounded-2xl p-2.5 border border-gray-150 flex items-center justify-center shadow-inner group">
                <img
                  src={qrUrl}
                  alt="UPI QR Payment QR Code"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-contain"
                />
                
                {/* Absolutely Centered Google Pay / GPay design Logo Overlay (Perfect match to screenshot overlay) */}
                <div className="absolute inset-0 m-auto w-11 h-11 bg-white rounded-full flex items-center justify-center shadow-md animate-pulse border border-slate-100">
                  <div className="w-8.5 h-8.5 bg-[#f8f9fa] rounded-full flex items-center justify-center overflow-hidden">
                    {/* Visual Stylised Google Pay Colors overlapping ring */}
                    <div className="relative w-6.5 h-6.5 flex items-center justify-center scale-90">
                      {/* Stylized custom GPay multi-color clover SVG logo */}
                      <svg viewBox="0 0 40 40" className="w-full h-full">
                        {/* Blue pill */}
                        <path d="M 12 10 L 28 10 A 5 5 0 0 1 33 15 L 33 15 A 5 5 0 0 1 28 20 L 12 20 A 5 5 0 0 1 7 15 L 7 15 A 5 5 0 0 1 12 10 Z" fill="#4285F4" transform="rotate(-45 20 20) translate(-3, -3)" />
                        {/* Green pill */}
                        <path d="M 12 10 L 28 10 A 5 5 0 0 1 33 15 L 33 15 A 5 5 0 0 1 28 20 L 12 20 A 5 5 0 0 1 7 15 L 7 15 A 5 5 0 0 1 12 10 Z" fill="#34A853" transform="rotate(45 20 20) translate(3, -3)" />
                        {/* Yellow pill */}
                        <path d="M 12 10 L 28 10 A 5 5 0 0 1 33 15 L 33 15 A 5 5 0 0 1 28 20 L 12 20 A 5 5 0 0 1 7 15 L 7 15 A 5 5 0 0 1 12 10 Z" fill="#FBBC05" transform="rotate(135 20 20) translate(3, 3)" />
                        {/* Red pill */}
                        <path d="M 12 10 L 28 10 A 5 5 0 0 1 33 15 L 33 15 A 5 5 0 0 1 28 20 L 12 20 A 5 5 0 0 1 7 15 L 7 15 A 5 5 0 0 1 12 10 Z" fill="#EA4335" transform="rotate(225 20 20) translate(-3, 3)" />
                      </svg>
                    </div>
                  </div>
                </div>
              </div>

              {/* UPI ID bottom anchor */}
              <div className="w-full text-center mt-5 mb-1 bg-slate-50 border border-slate-100 rounded-xl py-2 px-1 relative">
                <p className="text-[11px] font-mono font-black text-gray-800 break-all select-all flex items-center justify-center gap-1">
                  <span>UPI ID: {landlordUpi}</span>
                  <button
                    onClick={handleCopyUpi}
                    className="p-1 hover:bg-emerald-100 text-emerald-700 rounded transition-colors"
                    title="Copy UPI Address"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </p>
                {copiedText && (
                  <span className="absolute -top-7 left-1/3 text-[9px] bg-emerald-600 text-white font-extrabold px-2.5 py-0.5 rounded shadow-sm animate-bounce">
                    Copied ✓
                  </span>
                )}
              </div>
            </div>

            {/* Custom caption text below the card matching "Scan to pay with any UPI app" */}
            <p className="text-xs text-gray-500 font-medium text-center mt-6 tracking-wide font-sans leading-none pb-1 relative z-10">
              Scan to pay with any UPI app
            </p>

            {/* Brand Logo support icons */}
            <div className="flex gap-4.5 mt-3 justify-center items-center opacity-65 relative z-10 scale-90">
              <span className="text-[9px] font-black text-gray-400 font-mono tracking-wider">GPAY</span>
              <span className="text-gray-300">•</span>
              <span className="text-[9px] font-black text-gray-400 font-mono tracking-wider">PHONEPE</span>
              <span className="text-gray-300">•</span>
              <span className="text-[9px] font-black text-gray-400 font-mono tracking-wider">PAYTM</span>
              <span className="text-gray-300">•</span>
              <span className="text-[9px] font-black text-gray-400 font-mono tracking-wider">BHIM</span>
            </div>

          </div>

          {/* PRINT-FRIENDLY COMPREHENSIVE CERTIFIED RENTAL RECEIPT SLIP SLATE */}
          {paymentStatus === 'verified' && (
            <div className="bg-white border rounded-2xl p-6 shadow-sm font-sans space-y-4 text-left border-gray-200" id="official-tax-receipt-slip">
              <div className="flex justify-between items-start border-b border-gray-200 pb-3">
                <div>
                  <h4 className="text-xs font-black text-slate-800 tracking-wider uppercase">Official Monthly Rent Receipt</h4>
                  <p className="text-[10px] text-gray-400 font-mono mt-0.5">{txReference}</p>
                </div>
                <div className="bg-emerald-105 border border-emerald-300 text-emerald-800 text-[10px] font-black uppercase tracking-wide px-3 py-1 rounded-sm">
                  ✓ PAID &amp; SETTLED
                </div>
              </div>

              <div className="grid grid-cols-2 gap-y-3 gap-x-4 text-xs">
                <div>
                  <span className="text-gray-400 text-[10px] uppercase font-bold block leading-none mb-1">Landlord / Owner</span>
                  <span className="font-extrabold text-slate-800">{landlordName}</span>
                </div>
                <div>
                  <span className="text-gray-400 text-[10px] uppercase font-bold block leading-none mb-1">Tenant Name</span>
                  <span className="font-extrabold text-slate-800">{tenantName}</span>
                </div>
                <div>
                  <span className="text-gray-400 text-[10px] uppercase font-bold block leading-none mb-1">Accommodation</span>
                  <span className="font-semibold text-gray-600 truncate block">{propertyName}</span>
                </div>
                <div>
                  <span className="text-gray-400 text-[10px] uppercase font-bold block leading-none mb-1">Rent Cycle Month</span>
                  <span className="font-extrabold text-slate-800">{billingMonth}</span>
                </div>
                <div>
                  <span className="text-gray-400 text-[10px] uppercase font-bold block leading-none mb-1">Rent Settled</span>
                  <span className="font-extrabold text-emerald-700 text-sm">₹{rentAmount.toLocaleString('en-IN')}.00</span>
                </div>
                <div>
                  <span className="text-gray-400 text-[10px] uppercase font-bold block leading-none mb-1">Settlement Bank UTR</span>
                  <span className="font-mono text-xs font-bold text-slate-800 tracking-wider">{enteredUtr}</span>
                </div>
              </div>

              <div className="border-t border-gray-150 pt-4 flex justify-between items-center text-[10px]">
                <div className="text-gray-400">
                  <p>Electronically generated on easyrent.in</p>
                  <p className="mt-0.5 font-mono text-[9px] text-gray-350">{slipVerifiedAt}</p>
                </div>
                
                {/* Visual signature/seal */}
                <div className="text-center relative">
                  <div className="w-16 h-12 border border-emerald-500/30 rounded-lg flex items-center justify-center bg-emerald-50/20 text-[9px] font-bold text-emerald-700 rotate-2">
                    E-SIGNED
                  </div>
                  <span className="text-[8px] text-gray-400 block mt-1">Authorized Seal</span>
                </div>
              </div>

              <div className="flex gap-3 justify-end pt-2">
                <button
                  onClick={handlePrintSlip}
                  className="px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-bold hover:bg-slate-850 flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Download as Invoice</span>
                </button>
              </div>

            </div>
          )}

        </div>

      </div>

    </div>
  );
}
