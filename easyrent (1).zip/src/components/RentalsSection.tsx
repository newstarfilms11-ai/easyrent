/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  CalendarRange,
  MapPin,
  Clock,
  Phone,
  MessageSquare,
  Banknote,
  AlertCircle,
  FileText,
  Trash2,
  CheckCircle,
  CheckCircle2,
  Building2,
  TrendingDown,
  ArrowRight,
  QrCode
} from 'lucide-react';
import { RentalAgreement } from '../types';

interface RentalsSectionProps {
  rentals: RentalAgreement[];
  terminateRental: (id: string) => void;
  setActiveTab?: (tab: string) => void;
}

export default function RentalsSection({ rentals, terminateRental, setActiveTab }: RentalsSectionProps) {
  const [payingLease, setPayingLease] = useState<RentalAgreement | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [successReceipt, setSuccessReceipt] = useState<string | null>(null);

  const simulateRentPayment = (lease: RentalAgreement) => {
    setPayingLease(lease);
    setSuccessReceipt(null);
  };

  const handleProcessPayment = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setSuccessReceipt(`GPAY-${Math.floor(Math.random() * 900000 + 100000)}`);
    }, 1500);
  };

  return (
    <section className="max-w-7xl mx-auto px-4 py-8 text-gray-800" id="rentals-agreements-page">
      <div className="flex items-center gap-2 mb-6 pb-2 border-b border-gray-100">
        <div className="w-8 h-8 bg-emerald-50 rounded-lg flex items-center justify-center text-emerald-600 shrink-0">
          <CalendarRange className="w-4.5 h-4.5" />
        </div>
        <div>
          <h2 className="text-base sm:text-lg font-black text-gray-900 leading-none">My Rental agreements</h2>
          <p className="text-[11px] text-gray-500 mt-0.5">Manage your digital rents, lease summaries, and UPI monthly payouts.</p>
        </div>
      </div>

      {/* Dynamic Rent QR Code generator Banner */}
      <div className="bg-gradient-to-r from-emerald-500 via-emerald-650 to-teal-700 rounded-2xl p-5 mb-6 text-white shadow-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 relative overflow-hidden text-left">
        <div className="space-y-1 relative z-10">
          <span className="text-[9px] bg-white/20 uppercase tracking-widest font-black px-2.5 py-0.8 rounded-full">
            Fast QR Payments Activated
          </span>
          <h3 className="text-base font-bold pt-1">Direct Landlord UPI Pay Slips</h3>
          <p className="text-[11.5px] text-emerald-100 max-w-xl">
            Scan with Google Play, PhonePe, or Paytm. Generate official rental payment slips instantly as custom tax-compliant PDFs.
          </p>
        </div>
        {setActiveTab && (
          <button
            onClick={() => setActiveTab('payments')}
            className="px-4 py-2 bg-white hover:bg-slate-50 text-emerald-800 font-extrabold rounded-lg text-xs transition-colors shrink-0 z-10 shadow-sm cursor-pointer flex items-center gap-1.5"
          >
            <span>Launch QR Generator</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {rentals.length === 0 ? (
        <div className="bg-white border rounded-2xl py-12 px-6 text-center shadow-xs">
          <span className="text-4xl">🔑</span>
          <h3 className="font-extrabold text-gray-800 mt-2">No Active Tenancy Contracts</h3>
          <p className="text-xs text-gray-400 mt-1 max-w-sm mx-auto">
            Browse our verified Room, PG, or House listings and click "Rent Now" to instantly sign a legal digitized contract.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="rentals-list">
          {rentals.map((lease) => (
            <div
              key={lease.id}
              className="bg-white border border-gray-150 rounded-2xl p-5 shadow-xs flex flex-col md:flex-row gap-5 relative overflow-hidden"
            >
              {/* Cover thumbnail */}
              <div className="w-full md:w-32 h-28 bg-gray-100 rounded-lg overflow-hidden shrink-0">
                <img
                  src={lease.imageUrl || 'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=300&q=80'}
                  alt={lease.propertyTitle}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Lease Metadata */}
              <div className="flex-1 flex flex-col justify-between space-y-3">
                <div className="space-y-1">
                  <span className="text-[9px] uppercase tracking-wider font-extrabold text-emerald-700 bg-emerald-50 border border-emerald-100 px-2 py-0.5 rounded-md">
                    Active Lease • Room / House
                  </span>
                  <h3 className="text-sm font-black text-gray-900 tracking-tight leading-tight line-clamp-1 mt-1">
                    {lease.propertyTitle}
                  </h3>
                  <div className="flex gap-1 items-center text-[10px] text-gray-500 font-bold">
                    <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span className="truncate">{lease.city}</span>
                  </div>
                </div>

                {/* Billing specs */}
                <div className="grid grid-cols-3 gap-2 py-2 border-y border-gray-100 bg-gray-50/50 rounded-lg p-2 text-[10px] sm:text-xs">
                  <div>
                    <span className="block text-[8px] text-gray-400 font-bold uppercase leading-none mb-1">Monthly rent</span>
                    <span className="font-extrabold text-emerald-700">₹{lease.rent}</span>
                  </div>
                  <div>
                    <span className="block text-[8px] text-gray-400 font-bold uppercase leading-none mb-1">Deposit Paid</span>
                    <span className="font-extrabold text-gray-700">₹{lease.deposit}</span>
                  </div>
                  <div>
                    <span className="block text-[8px] text-gray-400 font-bold uppercase leading-none mb-1">Lease Start</span>
                    <span className="font-semibold text-gray-600 truncate block">{lease.startDate}</span>
                  </div>
                </div>

                {/* Due Date & Action */}
                <div className="flex justify-between items-center pt-1.5 shrink-0 gap-2">
                  <div className="text-left">
                    <span className="block text-[8px] text-gray-400 uppercase leading-none mb-1 font-bold">Next rent due on</span>
                    <p className="text-[10px] text-rose-600 font-extrabold flex items-center gap-1 leading-none">
                      <Clock className="w-3.5 h-3.5" />
                      {lease.nextDueDate}
                    </p>
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        if (setActiveTab) {
                          setActiveTab('payments');
                        } else {
                          simulateRentPayment(lease);
                        }
                      }}
                      className="px-4 py-2 bg-emerald-605 hover:bg-emerald-700 bg-emerald-600 text-white rounded-lg text-xs font-bold leading-none cursor-pointer flex items-center gap-1.5 transition-colors"
                    >
                      <QrCode className="w-3.5 h-3.5 animate-pulse" /> Pay via QR / UPI
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Are you sure you want to terminate your lease agreement for "${lease.propertyTitle}"? Your deposit of ₹${lease.deposit} will be processed for refund.`)) {
                          terminateRental(lease.id);
                        }
                      }}
                      className="p-1.8 hover:bg-rose-50 text-gray-400 hover:text-rose-600 border border-gray-150 hover:border-rose-200 rounded-lg transition-colors cursor-pointer"
                      title="Terminate Tenancy Contract"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* UPI Rent Pay Dialog Modal */}
      {payingLease && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 animate-fade-in">
          <div className="bg-white rounded-xl shadow-2xl overflow-hidden w-full max-w-sm border border-gray-150 relative">
            <button
              onClick={() => setPayingLease(null)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 font-bold text-lg cursor-pointer"
            >
              ×
            </button>

            {!successReceipt ? (
              <div className="p-6 space-y-5">
                <div className="text-center mb-2">
                  <div className="w-12 h-12 bg-emerald-50 rounded-full flex items-center justify-center mx-auto mb-2 text-emerald-600">
                    <FileText className="w-6 h-6" />
                  </div>
                  <h3 className="text-base font-black">Transfer Monthly Rent</h3>
                  <p className="text-[10px] text-gray-500 font-bold uppercase tracking-wider mt-0.5">{payingLease.propertyTitle}</p>
                </div>

                <div className="p-4 bg-gray-50 border border-gray-150 rounded-lg space-y-1.5 text-xs text-left">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Monthly Rent Fee:</span>
                    <span className="font-extrabold text-gray-800">₹{payingLease.rent}.00</span>
                  </div>
                  <div className="flex justify-between text-gray-400">
                    <span>GST Processing charge:</span><span>₹0.00 (Promo)</span>
                  </div>
                  <div className="flex justify-between border-t pt-1.5 font-bold text-emerald-700">
                    <span>Total UPI Bill:</span><span>₹{payingLease.rent}.00</span>
                  </div>
                </div>

                <div className="p-3 bg-emerald-50/50 rounded-lg border border-dashed border-emerald-200 flex gap-2">
                  <AlertCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <p className="text-[10px] text-gray-600 leading-normal">
                    Proceeding will trigger an API callback transaction to Landlord <span className="font-bold">{payingLease.ownerName}</span>. Rent maps paid instantly in index logs.
                  </p>
                </div>

                <button
                  onClick={handleProcessPayment}
                  disabled={isProcessing}
                  className="w-full py-2.8 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg transition-transform flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  {isProcessing ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Connecting UPI gateway...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4.5 h-4.5" />
                      <span>Transmit Rent ₹{payingLease.rent}</span>
                    </>
                  )}
                </button>
              </div>
            ) : (
              <div className="p-6 text-center space-y-4">
                <div className="w-16 h-16 bg-emerald-50 rounded-full flex items-center justify-center mx-auto text-emerald-600 animate-pulse">
                  <CheckCircle className="w-10 h-10" />
                </div>
                <div>
                  <h3 className="text-base font-black">Rent Paid successfully!</h3>
                  <p className="text-[11px] text-gray-500 mt-1">
                    Monthly rent of ₹{payingLease.rent} has been transferred directly to <span className="font-bold">{payingLease.ownerName}</span>'s unified bank account via secure UPI.
                  </p>
                </div>

                <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg text-left text-[11px] font-mono whitespace-pre space-y-0.5">
                  <div className="flex justify-between">
                    <span>TRANSACTION ID:</span><span>{successReceipt}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>BENEFICIARY:</span><span>{payingLease.ownerName.toUpperCase()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>DATE &amp; TIME:</span><span>{new Date().toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between font-bold text-emerald-700 pt-1 border-t mt-1">
                    <span>STATUS:</span><span>SETTLED (SUCCESS)</span>
                  </div>
                </div>

                <button
                  onClick={() => setPayingLease(null)}
                  className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg cursor-pointer"
                >
                  Back to Rentals list
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </section>
  );
}
