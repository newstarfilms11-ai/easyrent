/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState, useRef } from 'react';
import {
  User,
  ShieldCheck,
  Mail,
  Phone,
  MapPin,
  Building2,
  Award,
  Trash2,
  Edit3,
  Camera,
  Check,
  X,
  FileText,
  AlertCircle,
  Sparkles,
  Info
} from 'lucide-react';
import { PropertyListing, UserProfile } from '../types';

interface ProfileSectionProps {
  user: UserProfile;
  setUser: (user: UserProfile) => void;
  listings: PropertyListing[];
  onDeleteListing: (id: string) => void;
  setActiveTab: (tab: string) => void;
}

const PRESET_AVATARS = [
  { name: 'Executive Male', url: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150&q=80' },
  { name: 'Executive Female', url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&h=150&q=80' },
  { name: 'Stylish Male', url: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?auto=format&fit=crop&w=150&h=150&q=80' },
  { name: 'Stylish Female', url: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=150&h=150&q=80' },
  { name: 'Host Landlord', url: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&h=150&q=80' },
  { name: 'Support Rep', url: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&h=150&q=80' }
];

export default function ProfileSection({
  user,
  setUser,
  listings,
  onDeleteListing,
  setActiveTab
}: ProfileSectionProps) {
  // Toggle editing mode
  const [isEditing, setIsEditing] = useState(false);

  // Editing form states in separate tracking state
  const [editName, setEditName] = useState(user.name);
  const [editUsername, setEditUsername] = useState(user.username || '');
  const [editBio, setEditBio] = useState(user.bio || '');
  const [editPhone, setEditPhone] = useState(user.phone);
  const [editEmail, setEditEmail] = useState(user.email);
  const [editRole, setEditRole] = useState(user.role);
  const [editAvatarUrl, setEditAvatarUrl] = useState(user.avatarUrl || '');

  // File loading states
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isConvertingFile, setIsConvertingFile] = useState(false);
  const [validationError, setValidationError] = useState('');

  // My listings (if admin easyrent317@gmail.com, show all system listings for moderation; otherwise client's listings)
  const myRegisteredListings = user.role === 'Admin' || user.email === 'easyrent317@gmail.com'
    ? listings
    : listings.filter((item) => item.ownerPhone === user.phone);

  const startEditing = () => {
    setEditName(user.name);
    setEditUsername(user.username || '');
    setEditBio(user.bio || '');
    setEditPhone(user.phone);
    setEditEmail(user.email);
    setEditRole(user.role);
    setEditAvatarUrl(user.avatarUrl || '');
    setValidationError('');
    setIsEditing(true);
  };

  const handleCancel = () => {
    setIsEditing(false);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();

    // Username validation: alphanumeric & underscores
    const cleanUsername = editUsername.trim().toLowerCase().replace(/[^a-z0-9_]/g, '');
    if (!editName.trim()) {
      setValidationError('Please specify a valid full name.');
      return;
    }
    if (!cleanUsername) {
      setValidationError('Please specify a valid alphanumeric username.');
      return;
    }

    const updatedUser: UserProfile = {
      ...user,
      name: editName.trim(),
      username: cleanUsername,
      phone: editPhone.trim(),
      email: editEmail.trim(),
      role: editRole,
      bio: editBio.trim(),
      avatarUrl: editAvatarUrl
    };

    setUser(updatedUser);
    setIsEditing(false);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setValidationError('');

    if (file.size > 2 * 1024 * 1024) {
      setValidationError('File is too large! Please choose an image smaller than 2MB.');
      return;
    }

    setIsConvertingFile(true);
    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') {
        setEditAvatarUrl(reader.result);
      }
      setIsConvertingFile(false);
    };
    reader.onerror = () => {
      setValidationError('Failed to read image file.');
      setIsConvertingFile(false);
    };
    reader.readAsDataURL(file);
  };

  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    if (e.target.value.length <= 250) {
      setEditBio(e.target.value);
    }
  };

  return (
    <section className="max-w-7xl mx-auto px-4 py-8 text-gray-800" id="profile-management-panel">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Side: Profile card (Interactive View/Edit Mode) */}
        <div className="bg-white border border-gray-150 rounded-3xl p-6.5 shadow-sm h-fit relative">
          
          {/* Header Actions */}
          {!isEditing && (
            <button
              onClick={startEditing}
              className="absolute top-4 right-4 bg-gray-50 hover:bg-emerald-50 text-gray-500 hover:text-emerald-700 p-2 rounded-xl border border-gray-200 hover:border-emerald-200 transition-all text-xs font-bold leading-none cursor-pointer flex items-center gap-1.5 shadow-2xs"
              id="edit-profile-btn"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Edit Profile</span>
            </button>
          )}

          {/* VIEW MODE CONTAINER */}
          {!isEditing ? (
            <div className="space-y-6.5" id="profile-view-rendered">
              
              {/* Profile Avatar & Primary Identifiers */}
              <div className="text-center pt-2">
                <div className="relative inline-block group">
                  {user.avatarUrl ? (
                    <img
                      src={user.avatarUrl}
                      alt={user.name}
                      referrerPolicy="no-referrer"
                      className="w-22 h-22 sm:w-24 sm:h-24 rounded-full object-cover mx-auto ring-4 ring-emerald-50 border border-gray-150"
                    />
                  ) : (
                    <div className="w-22 h-22 sm:w-24 sm:h-24 bg-gradient-to-tr from-emerald-50 via-emerald-100 to-teal-50 rounded-full flex items-center justify-center mx-auto border-2 border-emerald-200 text-emerald-700 font-extrabold text-3xl shadow-2xs">
                      {user.name ? user.name[0].toUpperCase() : 'U'}
                    </div>
                  )}

                  {user.isPremium && (
                    <span className="absolute bottom-0 right-1/2 translate-x-12 bg-amber-400 text-amber-950 font-black text-[9px] uppercase tracking-wider px-2 py-0.5 rounded-full border-2 border-white shadow-xs">
                      PRO
                    </span>
                  )}
                </div>

                <div className="mt-3.5 space-y-1">
                  <h3 className="text-base sm:text-lg font-black text-gray-950 leading-tight">
                    {user.name}
                  </h3>
                  
                  {user.username && (
                    <p className="text-[11px] font-bold text-emerald-650 bg-emerald-50/70 border border-emerald-100/50 px-2.5 py-0.6 rounded-full inline-block font-mono">
                      @{user.username}
                    </p>
                  )}
                  
                  <div className="pt-1">
                    {user.role === 'Admin' || user.email === 'easyrent317@gmail.com' ? (
                      <span className="text-[9px] text-amber-950 font-black uppercase mt-1.5 tracking-widest px-2.5 py-1 rounded-md bg-amber-400 border border-amber-300 shadow-xs font-mono inline-block animate-pulse">
                        ⭐ SYSTEM MASTER ADMINISTRATOR
                      </span>
                    ) : (
                      <span className="text-[9px] text-gray-400 font-extrabold uppercase mt-1.5 tracking-wider px-2.5 py-0.5 rounded-md bg-gray-50 border border-gray-200/60 font-mono inline-block">
                        {user.role} Classified Member
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Bio block */}
              <div className="bg-slate-50 rounded-2xl p-4.5 border border-gray-150/60 relative overflow-hidden">
                <div className="absolute top-1 right-2 text-3xl font-serif text-emerald-200/50 selection:bg-transparent pointer-events-none">
                  “
                </div>
                <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Short Bio</h4>
                <p className="text-xs text-gray-600 leading-relaxed font-medium italic">
                  {user.bio || 'This user has not written an introduction bio yet. Contact them directly on WhatsApp for rental negotiations.'}
                </p>
              </div>

              {/* Details table */}
              <div className="space-y-4 pt-4.5 border-t border-gray-150/80 text-xs">
                <div className="flex gap-3 items-start">
                  <Mail className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="block text-[8px] text-gray-400 font-bold uppercase tracking-wide">Verified Email Address</span>
                    <span className="font-extrabold text-gray-700">{user.email}</span>
                  </div>
                </div>

                <div className="flex gap-3 items-start">
                  <Phone className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="block text-[8px] text-gray-400 font-bold uppercase tracking-wide">WhatsApp Phone Number</span>
                    <span className="font-extrabold text-gray-700 font-mono">+{user.phone}</span>
                  </div>
                </div>

                <div className="flex gap-3 items-start">
                  <Award className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="block text-[8px] text-gray-400 font-bold uppercase tracking-wide">Ad Posting Privileges</span>
                    <span className="font-extrabold text-gray-700">
                      {user.isPremium ? 'Unlimited Ads Boosted' : '1 Active Standard Ad'}
                    </span>
                  </div>
                </div>
              </div>

              {!user.isPremium && (
                <div className="p-4 bg-gradient-to-br from-amber-50 to-orange-50/50 rounded-2xl border border-amber-200/50 space-y-2.5 shadow-3xs">
                  <div className="flex gap-2 items-start text-amber-900">
                    <Sparkles className="w-4.5 h-4.5 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-xs font-black">Upgrade to Broker Pro</h4>
                      <p className="text-[10px] text-amber-700/90 leading-relaxed font-semibold mt-0.5">
                        Double listing positions, get immediate Blue Verification ticks, and unlock automated tenant chat callbacks.
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => setActiveTab('pricing')}
                    className="w-full py-2 bg-amber-500 hover:bg-amber-600 text-amber-950 font-black text-[10px] uppercase tracking-wider rounded-xl cursor-pointer transition-colors"
                  >
                    Go Premium for Free/Paid Custom Plans
                  </button>
                </div>
              )}
            </div>
          ) : (
            
            /* EDIT MODE CONTAINER */
            <form onSubmit={handleSave} className="space-y-5 animate-fade-in" id="profile-edit-form">
              <div className="flex items-center justify-between border-b pb-2">
                <span className="text-xs font-black text-gray-800 uppercase tracking-widest flex items-center gap-1">
                  <Edit3 className="w-4 h-4 text-emerald-600" />
                  Configure Profile
                </span>
                <button
                  type="button"
                  onClick={handleCancel}
                  className="text-gray-400 hover:text-gray-600 p-1"
                  title="Close editor"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {validationError && (
                <div className="p-2.5 bg-rose-50 border border-rose-150 rounded-xl text-rose-600 text-[11px] flex gap-2 items-center font-bold">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{validationError}</span>
                </div>
              )}

              {/* Profile pic upload & selection panel */}
              <div className="space-y-3">
                <label className="block text-[10px] font-extrabold text-gray-400 uppercase tracking-wider">Profile Picture</label>
                
                <div className="flex items-center gap-4">
                  {/* Current Preview */}
                  <div className="relative shrink-0">
                    {editAvatarUrl ? (
                      <img
                        src={editAvatarUrl}
                        alt="Preview"
                        className="w-16 h-16 rounded-full object-cover ring-2 ring-emerald-500 border"
                      />
                    ) : (
                      <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center border font-extrabold text-xl text-gray-400 uppercase">
                        {editName ? editName[iChar() ? 0 : 0] : '?'}
                      </div>
                    )}
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="absolute -bottom-1 -right-1 bg-emerald-600 hover:bg-emerald-700 text-white p-1.5 rounded-full border border-white shadow-xs cursor-pointer"
                      title="Upload custom picture"
                    >
                      <Camera className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Manual file select */}
                  <div className="flex-1 text-left space-y-1">
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      disabled={isConvertingFile}
                      className="px-3 py-1.5 border border-gray-250 hover:border-emerald-500 text-gray-700 font-bold hover:text-emerald-700 text-[10px] rounded-lg transition-colors cursor-pointer"
                    >
                      {isConvertingFile ? 'Analyzing image...' : 'Upload Image File'}
                    </button>
                    <p className="text-[9px] text-gray-400 leading-normal">
                      PNG, JPG up to 2MB. Saved client-side in secure applet container storage.
                    </p>
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileChange}
                      accept="image/*"
                      className="hidden"
                    />
                  </div>
                </div>

                {/* Quick Avatar Presets Grid */}
                <div className="space-y-1.5">
                  <label className="block text-[9px] font-bold text-gray-500">Or Pick a Professional Avatar Preset:</label>
                  <div className="grid grid-cols-6 gap-2">
                    {PRESET_AVATARS.map((av, index) => (
                      <button
                        type="button"
                        key={index}
                        onClick={() => setEditAvatarUrl(av.url)}
                        className={`relative aspect-square rounded-full overflow-hidden border-2 transition-transform cursor-pointer hover:scale-105 ${
                          editAvatarUrl === av.url ? 'border-emerald-600 shadow-xs' : 'border-transparent'
                        }`}
                        title={av.name}
                      >
                        <img src={av.url} alt={av.name} className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Username Input Field */}
              <div>
                <label className="block text-[10px] font-extrabold text-gray-400 uppercase tracking-wider mb-1">Set Handle Username *</label>
                <div className="relative rounded-lg shadow-2xs">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400 text-xs font-bold pointer-events-none">
                    @
                  </span>
                  <input
                    type="text"
                    required
                    maxLength={20}
                    className="w-full text-xs font-mono pl-7 pr-3 py-2 border rounded-lg border-gray-250 text-gray-800 placeholder-gray-400 focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                    placeholder="sharma_rahul99"
                    value={editUsername}
                    onChange={(e) => setEditUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                  />
                </div>
                <span className="text-[9px] text-gray-400 mt-1 block">
                  Lowercase letters, numbers, and underscores only. Easy search name for tenants.
                </span>
              </div>

              {/* Bio Input Section */}
              <div>
                <div className="flex justify-between items-baseline mb-1">
                  <label className="block text-[10px] font-extrabold text-gray-400 uppercase tracking-wider">Short Bio Description</label>
                  <span className="text-[9px] font-bold text-gray-400">{editBio.length}/250</span>
                </div>
                <textarea
                  rows={3}
                  className="w-full text-xs px-3 py-2 rounded-lg border border-gray-250 text-gray-800 placeholder-gray-400 focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                  placeholder="Tell tenants or landlords about yourself, your preferences, water setups, occupation or when you are available."
                  value={editBio}
                  onChange={handleTextareaChange}
                />
              </div>

              <div className="space-y-3.5 pt-1.5">
                {/* Full name */}
                <div>
                  <label className="block text-[10px] font-extrabold text-gray-400 uppercase tracking-wider mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    className="w-full text-xs px-3 py-2 rounded-lg border border-gray-250 text-gray-800 focus:outline-hidden focus:border-emerald-500"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                  />
                </div>

                {/* Email and Phone */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-extrabold text-gray-400 uppercase tracking-wider mb-1">Phone *</label>
                    <input
                      type="tel"
                      required
                      placeholder="8968541628"
                      className="w-full text-xs px-3 py-2 rounded-lg border border-gray-250 text-gray-800 font-mono focus:outline-hidden focus:border-emerald-500"
                      value={editPhone}
                      onChange={(e) => setEditPhone(e.target.value.replace(/[^0-9]/g, ''))}
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-extrabold text-gray-400 uppercase tracking-wider mb-1">Role *</label>
                    <select
                      className="w-full text-xs px-3 py-2 bg-white border border-gray-250 rounded-lg text-gray-850 focus:outline-hidden"
                      value={editRole}
                      onChange={(e) => setEditRole(e.target.value as any)}
                    >
                      <option value="Tenant">Tenant / Rent Searcher</option>
                      <option value="Owner">Owner / Landlord</option>
                      <option value="Broker">Broker / Real-estate Agent</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-extrabold text-gray-400 uppercase tracking-wider mb-1">Email *</label>
                  <input
                    type="email"
                    required
                    className="w-full text-xs px-3 py-2 rounded-lg border border-gray-250 text-gray-800 focus:outline-hidden"
                    value={editEmail}
                    onChange={(e) => setEditEmail(e.target.value)}
                  />
                </div>
              </div>

              {/* Form submittals buttons */}
              <div className="pt-4 border-t flex gap-3.5">
                <button
                  type="button"
                  onClick={handleCancel}
                  className="flex-1 py-2 text-center rounded-xl text-xs font-bold border border-gray-200 hover:bg-gray-50 text-gray-650 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl flex items-center justify-center gap-1 shadow-sm cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>Save Profile</span>
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Right Side: Host operations & Listing manager */}
        <div className="lg:col-span-2 space-y-6.5">
          {/* Quick Metrics */}
          <div className="grid grid-cols-3 gap-4.5">
            <div className="p-4.5 bg-white border border-gray-150 rounded-2xl shadow-2xs text-center space-y-1">
              <span className="block text-[8px] sm:text-[9px] font-extrabold text-gray-450 uppercase tracking-wider">Posted properties</span>
              <span className="text-xl sm:text-2xl font-black text-emerald-700 tracking-tight block">{myRegisteredListings.length}</span>
            </div>
            <div className="p-4.5 bg-white border border-gray-150 rounded-2xl shadow-2xs text-center space-y-1">
              <span className="block text-[8px] sm:text-[9px] font-extrabold text-gray-450 uppercase tracking-wider">Acquired Rent Leads</span>
              <span className="text-xl sm:text-2xl font-black text-gray-800 tracking-tight block">
                {myRegisteredListings.length > 0 ? myRegisteredListings.length * 4 + 3 : 0}
              </span>
            </div>
            <div className="p-4.5 bg-white border border-gray-150 rounded-2xl shadow-2xs text-center space-y-1">
              <span className="block text-[8px] sm:text-[9px] font-extrabold text-gray-450 uppercase tracking-wider">Multiplier Privileges</span>
              <span className="text-xl sm:text-2xl font-black text-emerald-600 tracking-tight block">
                {user.isPremium ? '10x Active' : '1x Search'}
              </span>
            </div>
          </div>

          {/* Properties lists */}
          <div className="bg-white border border-gray-150 rounded-2xl p-5.5 shadow-2xs">
            <h3 className="text-sm font-black text-gray-900 border-b pb-2.5 mb-4.5 flex items-center justify-between">
              <span className="flex items-center gap-1.5 font-sans">
                <FileText className="w-4 h-4 text-emerald-650" />
                {user.role === 'Admin' || user.email === 'easyrent317@gmail.com'
                  ? 'Master System Listing Directory (Admin moderation)'
                  : 'My Listed Classified Advertisements'}
              </span>
              <button
                onClick={() => setActiveTab('post-ad')}
                className="text-[9px] bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold px-3.5 py-1.8 uppercase tracking-widest rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
              >
                + Post Classified ad
              </button>
            </h3>

            {myRegisteredListings.length === 0 ? (
              <div className="py-14 text-center space-y-3.5">
                <div className="w-12 h-12 bg-slate-50 border border-dashed rounded-full flex items-center justify-center mx-auto text-gray-400">
                  <Building2 className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-gray-700">No active property classifieds found</h4>
                  <p className="text-[11px] text-gray-400 font-medium max-w-sm mx-auto leading-relaxed">
                    If you are a flat owner, commercial broker, or offering PG occupancy, click "+ Post Classified ad" above to advertise instantly with EasyRent.
                  </p>
                </div>
              </div>
            ) : (
              <div className="divide-y divide-gray-100">
                {myRegisteredListings.map((prop) => (
                  <div key={prop.id} className="py-4 flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3.5 min-w-0">
                      <div className="w-13 h-10.5 bg-gray-100 rounded-lg overflow-hidden shrink-0 border shadow-2xs">
                        <img src={prop.imageUrl} alt={prop.title} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                      </div>
                      <div className="text-left min-w-0">
                        <h4 className="text-xs font-bold text-gray-950 truncate max-w-xs sm:max-w-md">{prop.title}</h4>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-[9px] font-extrabold text-emerald-800 bg-emerald-50 px-1.5 py-0.2 rounded font-mono">
                            ₹{prop.rent}/mo
                          </span>
                          <span className="text-[8px] font-bold text-gray-400 uppercase font-mono">
                            {prop.type} • {prop.city}
                          </span>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        if (confirm(`Are you absolutely sure you want to delete listing classified "${prop.title}"?`)) {
                          onDeleteListing(prop.id);
                        }
                      }}
                      className="p-2.2 hover:bg-rose-50 text-gray-400 hover:text-rose-600 rounded-xl border border-transparent hover:border-rose-150 transition-colors cursor-pointer"
                      title="Delete Classified permanently"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

      </div>
    </section>
  );

  function iChar(): boolean {
    return true;
  }
}
