/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Building2, Search, CreditCard, LogIn, LogOut, ShieldAlert, CheckCircle2, User, Plus, QrCode } from 'lucide-react';
import { UserProfile } from '../types';
import { loginWithGoogle, logoutFromFirebase, loginWithEmail, registerWithEmail } from '../lib/firebase';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  user: UserProfile;
  setUser: (user: UserProfile) => void;
}

export default function Header({
  activeTab,
  setActiveTab,
  searchQuery,
  setSearchQuery,
  user,
  setUser
}: HeaderProps) {
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [formData, setFormData] = useState({
    name: user.name,
    phone: user.phone,
    email: user.email,
    password: '',
    role: user.role
  });
  const [alertMsg, setAlertMsg] = useState('');

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone) {
      setAlertMsg('Name and Phone are completely mandatory.');
      return;
    }

    const inputEmail = (formData.email || '').trim().toLowerCase();
    
    if (!inputEmail || !formData.password) {
      setAlertMsg('Email and Password are required for Firebase Auth.');
      return;
    }

    try {
      let firebaseUser;
      if (isRegistering) {
        firebaseUser = await registerWithEmail(inputEmail, formData.password);
      } else {
        firebaseUser = await loginWithEmail(inputEmail, formData.password);
      }
      
      const isAdmin = inputEmail === 'easyrent317@gmail.com';

      setUser({
        name: formData.name || firebaseUser.email || 'User',
        phone: formData.phone,
        email: inputEmail,
        role: isAdmin ? 'Admin' : (formData.role as 'Tenant' | 'Owner' | 'Broker' | 'Admin'),
        isPremium: isAdmin ? true : user.isPremium,
        username: isAdmin ? 'easyrent_admin' : (user.username || formData.name.toLowerCase().replace(/[^a-z0-9_]/g, '') || `user_${Math.floor(Math.random() * 1000)}`),
        avatarUrl: isAdmin ? 'https://images.unsplash.com/photo-15472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&h=150&q=80' : user.avatarUrl,
        bio: isAdmin ? 'Global Site Administrator of easyrent.in - managing properties under active brokerage.' : (user.bio || 'Looking for fantastic housing or property vacancies with EasyRent.')
      });

      setShowLoginModal(false);
      setAlertMsg('');
    } catch (e: any) {
      console.error("Auth error", e);
      setAlertMsg(`Auth failed: ${e.message || e}`);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      setAlertMsg('');
      const firebaseUser = await loginWithGoogle();
      if (firebaseUser) {
        const inputEmail = firebaseUser.email || '';
        const isAdmin = inputEmail === 'easyrent317@gmail.com';
        setUser({
          name: firebaseUser.displayName || 'Google User',
          phone: firebaseUser.phoneNumber || '9900990099',
          email: inputEmail,
          role: isAdmin ? 'Admin' : 'Tenant',
          isPremium: isAdmin ? true : false,
          username: firebaseUser.displayName ? firebaseUser.displayName.toLowerCase().replace(/[^a-z0-9_]/g, '') : `user_${firebaseUser.uid.substring(0, 5)}`,
          avatarUrl: firebaseUser.photoURL || 'https://images.unsplash.com/photo-15472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&h=150&q=80',
          bio: isAdmin ? 'Global Site Administrator of easyrent.in - managing properties under active brokerage.' : 'EasyRent user logged in via verified Google credentials.'
        });
        setShowLoginModal(false);
      }
    } catch (e: any) {
      console.error(e);
      setAlertMsg(`Google Auth failed: ${e.message || e}`);
    }
  };

  const logoutUser = () => {
    logoutFromFirebase().catch(e => console.error("Firebase logout error:", e));
    setUser({
      name: 'Guest Guest',
      phone: '8968541628',
      email: 'guest@easyrent.com',
      role: 'Tenant',
      isPremium: false
    });
    setActiveTab('home');
  };

  return (
    <nav className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-xs" id="easyrent-navbar">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <button
            onClick={() => setActiveTab('home')}
            className="flex items-center gap-2 cursor-pointer focus:outline-hidden group"
            id="logo-button"
          >
            <div className="w-8.5 h-8.5 bg-emerald-600 rounded-lg flex items-center justify-center transition-transform group-hover:scale-105 shadow-xs">
              <Building2 className="w-5 h-5 text-white" />
            </div>
            <div className="text-left">
              <span className="text-xl font-extrabold text-emerald-700 tracking-tight leading-none block">EasyRent.in</span>
              <span className="text-[9px] uppercase tracking-wider text-emerald-500 font-extrabold block leading-none">Powered by easyrent.in</span>
            </div>
          </button>

          {/* Quick Central City Search (Desktop) */}
          <div className="hidden md:flex items-center gap-2 flex-1 max-w-sm mx-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                className="w-full text-xs font-medium pl-9 pr-3 py-1.8 rounded-lg border border-gray-200 bg-gray-50 focus:bg-white text-gray-800 placeholder-gray-400 outline-hidden focus:border-emerald-500 transition-all focus:ring-1 focus:ring-emerald-500"
                placeholder="Search by city (e.g., Mumbai, Bangalore)..."
                value={searchQuery}
                aria-label="Search listings by city"
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  if (activeTab !== 'listings') setActiveTab('listings');
                }}
              />
            </div>
          </div>

          {/* Nav Links (Desktop) */}
          <div className="hidden md:flex items-center gap-3">
            <button
              onClick={() => setActiveTab('listings')}
              className={`text-sm font-semibold px-3 py-2 rounded-md transition-colors cursor-pointer ${
                activeTab === 'listings' ? 'text-emerald-700 bg-emerald-50' : 'text-gray-600 hover:text-emerald-600'
              }`}
            >
              Listings
            </button>
            <button
              onClick={() => setActiveTab('pricing')}
              className={`text-sm font-semibold px-3 py-2 rounded-md transition-all gap-1.5 flex items-center cursor-pointer ${
                activeTab === 'pricing' ? 'text-emerald-700 bg-emerald-50' : 'text-gray-600 hover:text-emerald-600'
              }`}
            >
              <CreditCard className="w-4 h-4" />
              Pricing
            </button>
            <button
              onClick={() => setActiveTab('rentals')}
              className={`text-sm font-semibold px-3 py-2 rounded-md transition-colors cursor-pointer ${
                activeTab === 'rentals' ? 'text-emerald-700 bg-emerald-50' : 'text-gray-600 hover:text-emerald-600'
              }`}
            >
              Rentals {user.isPremium && <span className="ml-1 text-[9px] font-bold bg-amber-400 text-amber-900 rounded-full px-1.5 py-0.2">PRO</span>}
            </button>
            <button
              onClick={() => setActiveTab('payments')}
              className={`text-sm font-semibold px-3 py-2.5 rounded-md transition-all gap-1.5 flex items-center cursor-pointer ${
                activeTab === 'payments' ? 'text-emerald-700 bg-emerald-50' : 'text-gray-600 hover:text-emerald-600'
              }`}
              id="qr-pay-header-button"
            >
              <QrCode className="w-4 h-4 text-emerald-650 animate-pulse" />
              <span>QR Pay</span>
            </button>
            <button
              onClick={() => setActiveTab('post-ad')}
              className={`text-sm font-semibold px-3 py-2 rounded-md transition-colors flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'post-ad' ? 'text-emerald-700 bg-emerald-50' : 'text-gray-600 hover:text-emerald-600'
              }`}
            >
              <Plus className="w-4 h-4 text-emerald-605" />
              <span>Post Ad</span>
            </button>

            <span className="w-[1px] h-6 bg-gray-200 mx-1"></span>

            {/* Profile Action & Login */}
            {user.name !== 'Guest Guest' ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveTab('profile')}
                  className={`flex items-center gap-1.5 text-sm font-bold pl-2 pr-3 py-1.5 rounded-lg cursor-pointer border ${
                    activeTab === 'profile'
                      ? 'border-emerald-300 text-emerald-700 bg-emerald-50'
                      : 'border-gray-200 hover:bg-gray-50 text-gray-700'
                  }`}
                >
                  {user.avatarUrl ? (
                    <img
                      src={user.avatarUrl}
                      alt={user.name}
                      referrerPolicy="no-referrer"
                      className="w-5 h-5 rounded-full object-cover border border-gray-150"
                    />
                  ) : (
                    <User className="w-4 h-4 text-emerald-600" />
                  )}
                  <span className="max-w-[70px] truncate">{user.name.split(' ')[0]}</span>
                </button>
                <button
                  onClick={logoutUser}
                  title="Logout"
                  className="p-1.8 rounded-lg text-gray-400 hover:bg-rose-50 hover:text-rose-600 cursor-pointer transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex gap-1.5">
                <button
                  onClick={() => {
                    setIsRegistering(false);
                    setShowLoginModal(true);
                  }}
                  className="px-3.5 py-1.8 text-sm font-bold text-emerald-600 hover:bg-emerald-50 rounded-lg cursor-pointer transition-colors"
                >
                  Login
                </button>
                <button
                  onClick={() => {
                    setIsRegistering(true);
                    setShowLoginModal(true);
                  }}
                  className="px-3.5 py-1.8 text-sm font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg shadow-xs cursor-pointer transition-colors"
                >
                  Register
                </button>
              </div>
            )}
          </div>

          {/* Quick Account indicator on small screens */}
          <div className="flex md:hidden items-center gap-1.5">
            {user.name !== 'Guest Guest' ? (
              <button
                onClick={() => setActiveTab('profile')}
                className={`w-9 h-9 flex items-center justify-center rounded-full border border-gray-200 overflow-hidden ${
                  activeTab === 'profile' ? 'bg-emerald-50 text-emerald-700 border-emerald-300' : 'bg-gray-50 text-gray-600'
                }`}
              >
                {user.avatarUrl ? (
                  <img
                    src={user.avatarUrl}
                    alt={user.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <User className="w-4.5 h-4.5" />
                )}
              </button>
            ) : (
              <button
                onClick={() => {
                  setIsRegistering(false);
                  setShowLoginModal(true);
                }}
                className="text-xs font-bold bg-emerald-50 hover:bg-emerald-100 text-emerald-700 px-3 py-1.5 rounded-lg border border-emerald-200 transition-colors"
              >
                Sign In
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Interactive Authentication Modal */}
      {showLoginModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 animate-fade-in">
          <div className="bg-white rounded-xl shadow-2xl p-6 w-full max-w-sm border border-gray-100 relative">
            <button
              onClick={() => setShowLoginModal(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 font-bold text-lg cursor-pointer"
            >
              ×
            </button>
            <div className="text-center mb-5">
              <div className="w-12 h-12 bg-emerald-50 rounded-full flex items-center justify-center mx-auto mb-2 text-emerald-600">
                <Building2 className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-gray-900">
                {isRegistering ? 'Create EasyRent Account' : 'Welcome back to EasyRent'}
              </h3>
              <p className="text-xs text-gray-500 mt-1">
                {isRegistering
                  ? 'List properties for free, receive calls directly'
                  : 'Manage rentals, trace payments, connect instantly'}
              </p>
            </div>

            {alertMsg && (
              <div className="mb-4 p-2.5 bg-rose-50 rounded-lg flex items-start gap-1.5 text-xs text-rose-600 border border-rose-150">
                <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{alertMsg}</span>
              </div>
            )}

            <form onSubmit={handleAuthSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-gray-750 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  placeholder="Rahul Sharma"
                  className="w-full text-xs px-3 py-2 rounded-lg border border-gray-200 text-gray-800 placeholder-gray-400 focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-750 mb-1">WhatsApp / Phone Number</label>
                <input
                  type="tel"
                  required
                  placeholder="8968541628"
                  pattern="[0-9]{10}"
                  maxLength={10}
                  className="w-full text-xs px-3 py-2 rounded-lg border border-gray-200 text-gray-800 placeholder-gray-400 focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                />
                <span className="text-[10px] text-gray-400 mt-0.5 block">10-digit mobile number</span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-750 mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  placeholder="rahul@gmail.com"
                  className="w-full text-xs px-3 py-2 rounded-lg border border-gray-200 text-gray-800 placeholder-gray-400 focus:outline-hidden focus:border-emerald-500"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-750 mb-1">Password</label>
                <input
                  type="password"
                  required
                  placeholder="******"
                  className="w-full text-xs px-3 py-2 rounded-lg border border-gray-200 text-gray-800 placeholder-gray-400 focus:outline-hidden focus:border-emerald-500"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-750 mb-1">Primary Role</label>
                <select
                  className="w-full text-xs px-3 py-2 rounded-lg border border-gray-200 text-gray-800 bg-white"
                  value={formData.role}
                  onChange={(e) => setFormData({ ...formData, role: e.target.value as any })}
                >
                  <option value="Tenant">Looking for Rent (Tenant)</option>
                  <option value="Owner">Property Owner (Listing Host)</option>
                  <option value="Broker">Broker / Agent (Premium Partner)</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-xs transition-colors cursor-pointer"
              >
                {isRegistering ? 'Register & Begin' : 'Secure Login'}
              </button>
            </form>

            <div className="relative py-2.5 flex items-center justify-center">
              <span className="absolute bg-white px-2 text-[10px] text-gray-400 font-extrabold uppercase tracking-widest">or connect via Google</span>
              <span className="w-full border-t border-gray-150"></span>
            </div>

            <button
              type="button"
              onClick={handleGoogleLogin}
              className="w-full py-2 bg-slate-50 hover:bg-slate-100 text-gray-700 font-bold rounded-lg text-xs border border-gray-200 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <svg className="w-4 h-4 shrink-0 font-sans" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l3.66-2.85z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.85c.87-2.6 3.3-4.53 6.13-4.53z" />
              </svg>
              <span>Continue with Google</span>
            </button>

            <div className="mt-4 pt-3 border-t border-gray-100 text-center">
              <span className="text-[11px] text-gray-400">
                {isRegistering ? 'Already have an account?' : 'New provider?'}
                <button
                  onClick={() => setIsRegistering(!isRegistering)}
                  className="text-emerald-600 ml-1 hover:underline font-semibold"
                >
                  {isRegistering ? 'Sign In Instead' : 'Register Free Account'}
                </button>
              </span>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
