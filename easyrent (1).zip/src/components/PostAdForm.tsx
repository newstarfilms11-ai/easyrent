/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState } from 'react';
import {
  Sparkles,
  ShieldCheck,
  Building2,
  CheckCircle2,
  UploadCloud,
  ChevronRight,
  ChevronLeft,
  DollarSign,
  Plus,
  Compass,
  ArrowRight,
  MapPin,
  Maximize2
} from 'lucide-react';
import { PropertyListing, PropertyType } from '../types';
import { PRESET_IMAGES, BHK_OPTIONS } from '../data/defaultListings';

interface PostAdFormProps {
  onAddListing: (newListing: PropertyListing) => void;
  setActiveTab: (tab: string) => void;
  userPhone: string;
  userName: string;
}

export default function PostAdForm({
  onAddListing,
  setActiveTab,
  userPhone,
  userName
}: PostAdFormProps) {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Sync details from profile changes
  React.useEffect(() => {
    if (userName) setOwnerName(userName);
  }, [userName]);

  React.useEffect(() => {
    if (userPhone) setOwnerPhone(userPhone);
  }, [userPhone]);

  // Form State
  const [title, setTitle] = useState('');
  const [type, setType] = useState<PropertyType>('Room');
  const [city, setCity] = useState('Mumbai');
  const [address, setAddress] = useState('');
  const [rent, setRent] = useState<number | ''>('');
  const [deposit, setDeposit] = useState<number | ''>('');
  const [description, setDescription] = useState('');
  const [selectedAmenities, setSelectedAmenities] = useState<string[]>([]);
  const [selectedPresetImage, setSelectedPresetImage] = useState(PRESET_IMAGES[0].url);
  const [customFileText, setCustomFileText] = useState('');
  const [ownerName, setOwnerName] = useState(userName || '');
  const [ownerPhone, setOwnerPhone] = useState(userPhone || '');
  const [bhk, setBhk] = useState('1 BHK');
  const [plan, setPlan] = useState<'free' | 'boost' | 'broker'>('free');

  // Geographic mapping coordinate states
  const [latitude, setLatitude] = useState<number | ''>(19.0760);
  const [longitude, setLongitude] = useState<number | ''>(72.8777);

  // Reset coordinates whenever city list selection changes to plot natively on the schematic map
  React.useEffect(() => {
    const DEFAULT_CITY_LAT_LNG: Record<string, { lat: number; lng: number }> = {
      Mumbai: { lat: 19.0760, lng: 72.8777 },
      Delhi: { lat: 28.6139, lng: 77.2090 },
      Bangalore: { lat: 12.9716, lng: 77.5946 },
      Pune: { lat: 18.5204, lng: 73.8567 },
      Noida: { lat: 28.5355, lng: 77.3910 }
    };
    const center = DEFAULT_CITY_LAT_LNG[city];
    if (center) {
      setLatitude(center.lat);
      setLongitude(center.lng);
    }
  }, [city]);

  const amenitiesList = [
    'WiFi',
    'AC',
    'Parking',
    'Attached Bath',
    'Power Backup',
    'Security',
    'Meals Included',
    'Washing Machine',
    'Refrigerator',
    'Geyser',
    'Kitchenette',
    'Gated Community'
  ];

  const handleNext = () => {
    setErrorMsg(null);
    if (step === 1) {
      if (!title.trim() || !address.trim() || rent === '' || deposit === '') {
        setErrorMsg('Please fill out all mandatory fields in Step 1 (Classified Title, Landmark Address, Rent, and Deposit).');
        return;
      }
      if (Number(rent) < 1) {
        setErrorMsg('Please enter a valid monthly rent amount greater than 0.');
        return;
      }
      if (Number(deposit) < 0) {
        setErrorMsg('Security deposit cannot be negative. Enter 0 if no deposit is required.');
        return;
      }
    }
    if (step === 2) {
      if (!ownerName.trim() || !ownerPhone.trim() || !description.trim()) {
        setErrorMsg('Please provide owner details (Landlord Name, WhatsApp Mobile) and property description.');
        return;
      }
      const digitsOnly = ownerPhone.replace(/\D/g, '');
      if (digitsOnly.length < 10) {
        setErrorMsg('Please enter a valid 10-digit WhatsApp mobile number.');
        return;
      }
    }
    setStep(prev => prev + 1);
  };

  const handleBack = () => {
    setErrorMsg(null);
    setStep(prev => prev - 1);
  };

  const toggleAmenity = (amenity: string) => {
    setSelectedAmenities(prev =>
      prev.includes(amenity) ? prev.filter(a => a !== amenity) : [...prev, amenity]
    );
  };

  const handleFileUploadSimulate = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setCustomFileText(file.name);
      // Generate a simulated mock preview or pick a matching category photo
      const matchingPreset = PRESET_IMAGES.find(p => p.name.toLowerCase().includes(type.toLowerCase())) || PRESET_IMAGES[0];
      setSelectedPresetImage(matchingPreset.url);
    }
  };

  const handleSubmit = (e: React.MouseEvent) => {
    e.preventDefault();
    setLoading(true);

    setTimeout(() => {
      const newListing: PropertyListing = {
        id: `prop-${Math.floor(Math.random() * 100000)}`,
        title,
        type,
        city,
        address,
        rent: Number(rent),
        deposit: Number(deposit),
        description,
        amenities: selectedAmenities.length > 0 ? selectedAmenities : ['WiFi', 'Power Backup'],
        imageUrl: selectedPresetImage,
        ownerName,
        ownerPhone,
        isVerified: plan !== 'free',
        isFeatured: plan === 'boost' || plan === 'broker',
        createdAt: new Date().toISOString(),
        bhk: type === 'Room' || type === 'PG' ? bhk : undefined,
        latitude: latitude !== '' ? Number(latitude) : undefined,
        longitude: longitude !== '' ? Number(longitude) : undefined
      };

      onAddListing(newListing);
      setLoading(false);
      setSuccess(true);
    }, 1500);
  };

  const resetFormAndGoListings = () => {
    setSuccess(false);
    setActiveTab('listings');
  };

  if (success) {
    return (
      <div className="max-w-xl mx-auto px-4 py-11 text-center animate-fade-in" id="post-success-view">
        <div className="bg-white border rounded-2xl p-8 shadow-sm space-y-5">
          <div className="w-18 h-18 bg-emerald-50 rounded-full flex items-center justify-center mx-auto text-emerald-600 animate-bounce">
            <CheckCircle2 className="w-10 h-10" />
          </div>
          <div className="space-y-1.5">
            <h2 className="text-xl sm:text-2xl font-black text-gray-900">Your Property Classified is Live!</h2>
            <p className="text-xs sm:text-sm text-gray-500">
              Listing has been successfully broadcast to EasyRent search networks.
            </p>
          </div>

          <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-xl space-y-2 text-left">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-emerald-800">{title}</span>
              <span className="font-extrabold text-emerald-700">₹{rent}/mo</span>
            </div>
            <p className="text-[10px] text-emerald-650 leading-relaxed font-semibold">
              ✓ Boost Status: {plan === 'free' ? 'Standard Classified Listing' : 'Highlighted Featured ad activated'}
            </p>
          </div>

          <button
            onClick={resetFormAndGoListings}
            className="w-full py-2.8 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg transition-transform hover:scale-101 flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <span>Browse Directory Listings</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto px-4 py-6" id="post-ad-page">
      {/* Step Header */}
      <div className="mb-6 text-center space-y-1.5">
        <div className="inline-flex items-center gap-1 shadow-xs bg-emerald-50 border border-emerald-100 px-3 py-1 rounded-full text-[10px] sm:text-xs font-semibold text-emerald-700">
          <Sparkles className="w-3.5 h-3.5" />
          List Property classified for millions of Tenants
        </div>
        <h2 className="text-lg sm:text-xl font-extrabold text-gray-900">Classified Listing Wizard</h2>
        <div className="flex justify-center items-center gap-2 pt-2 text-[11px] font-bold text-gray-400">
          <span className={step === 1 ? 'text-emerald-650' : 'text-gray-600'}>1. Basic Info</span>
          <ChevronRight className="w-3 h-3" />
          <span className={step === 2 ? 'text-emerald-650' : 'text-gray-600'}>2. Details</span>
          <ChevronRight className="w-3 h-3" />
          <span className={step === 3 ? 'text-emerald-650' : 'text-gray-600'}>3. Cover Photo</span>
          <ChevronRight className="w-3 h-3" />
          <span className={step === 4 ? 'text-emerald-650' : 'text-gray-600'}>4. Submit Plan</span>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-150 p-5.5 sm:p-7 shadow-xs">
        {/* Validation Error Banner HUD */}
        {errorMsg && (
          <div className="mb-4 p-3.5 bg-rose-50 border border-rose-100 rounded-xl text-rose-800 text-[11px] font-medium leading-normal animate-fade-in flex items-start gap-2">
            <span className="text-rose-500 font-black shrink-0 mt-0.5">⚠️</span>
            <div className="flex-1 text-left">
              <span className="font-extrabold block text-rose-900 mb-0.5">Validation Check Unsuccessful</span>
              <span>{errorMsg}</span>
            </div>
            <button
              onClick={() => setErrorMsg(null)}
              className="text-rose-400 hover:text-rose-600 font-bold px-1 text-sm select-none cursor-pointer"
            >
              ×
            </button>
          </div>
        )}

        {/* STEP 1: Basic Information */}
        {step === 1 && (
          <div className="space-y-4 animate-fade-in">
            <h3 className="text-base font-bold text-gray-800 border-b border-gray-100 pb-2">Property Primary Information</h3>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">Catchy Classified Title *</label>
              <input
                type="text"
                required
                className="w-full text-xs px-3 py-2 rounded-lg border border-gray-200 text-gray-800 placeholder-gray-400 focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                placeholder="e.g., Cozy 1 BHK Ground Floor near Koramangala block 3"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </div>

            <div className="grid grid-cols-2 gap-3.5">
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Rental Type *</label>
                <select
                  className="w-full text-xs px-3 py-1.8 bg-white border border-gray-200 text-gray-800 rounded-lg focus:outline-hidden"
                  value={type}
                  onChange={(e) => setType(e.target.value as PropertyType)}
                >
                  <option value="Room">Room/कमरा</option>
                  <option value="PG">PG / Paying Guest</option>
                  <option value="House">House/मकान</option>
                  <option value="Shop">Shop/दुकान</option>
                  <option value="Garage">Garage/गैराज</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">City Locality *</label>
                <select
                  className="w-full text-xs px-3 py-1.8 bg-white border border-gray-200 text-gray-800 rounded-lg focus:outline-hidden"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                >
                  <option value="Mumbai">Mumbai</option>
                  <option value="Delhi">Delhi</option>
                  <option value="Bangalore">Bangalore</option>
                  <option value="Pune">Pune</option>
                  <option value="Noida">Noida</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">
                Full Property / Landlord Address *
              </label>
              <textarea
                required
                rows={3}
                className="w-full text-xs px-3 py-2.5 rounded-lg border border-gray-250 text-gray-800 placeholder-gray-400 focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                placeholder="Floor No, Building Name, Sector, Landmark Address..."
                value={address}
                onChange={(e) => setAddress(e.target.value)}
              />
            </div>

            <div className="grid grid-cols-2 gap-3.5">
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Classified Rent (₹/mo) *</label>
                <input
                  type="number"
                  required
                  min={500}
                  className="w-full text-xs px-3 py-2 rounded-lg border border-gray-200 text-gray-800 placeholder-gray-400 focus:outline-hidden focus:border-emerald-500"
                  placeholder="e.g., 12000"
                  value={rent}
                  onChange={(e) => setRent(e.target.value === '' ? '' : Number(e.target.value))}
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Security Deposit (₹) *</label>
                <input
                  type="number"
                  required
                  min={0}
                  className="w-full text-xs px-3 py-2 rounded-lg border border-gray-200 text-gray-800 placeholder-gray-400 focus:outline-hidden focus:border-emerald-500"
                  placeholder="e.g., 25000"
                  value={deposit}
                  onChange={(e) => setDeposit(e.target.value === '' ? '' : Number(e.target.value))}
                />
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: Description & Amenities */}
        {step === 2 && (
          <div className="space-y-4 animate-fade-in">
            <h3 className="text-base font-bold text-gray-800 border-b border-gray-100 pb-2">Property Features &amp; Host Details</h3>

            <div className="grid grid-cols-2 gap-3.5">
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Landlord / Owner Name *</label>
                <input
                  type="text"
                  required
                  className="w-full text-xs px-3 py-2 rounded-lg border border-gray-200 text-gray-800"
                  placeholder="Rahul Sharma"
                  value={ownerName}
                  onChange={(e) => setOwnerName(e.target.value)}
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">WhatsApp Mobile *</label>
                <input
                  type="tel"
                  required
                  maxLength={10}
                  className="w-full text-xs px-3 py-2 rounded-lg border border-gray-200 text-gray-800 text-mono"
                  placeholder="8968541628"
                  value={ownerPhone}
                  onChange={(e) => setOwnerPhone(e.target.value)}
                />
              </div>
            </div>

            {(type === 'Room' || type === 'PG') && (
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">BHK Room Occupancy Spec</label>
                <select
                  className="w-full text-xs px-3 py-1.8 bg-white border border-gray-200 text-gray-800 rounded-lg focus:outline-hidden"
                  value={bhk}
                  onChange={(e) => setBhk(e.target.value)}
                >
                  {BHK_OPTIONS.map(opt => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">Classified Description (India rules) *</label>
              <textarea
                required
                rows={3}
                className="w-full text-xs px-3 py-2 rounded-lg border border-gray-200 text-gray-800 placeholder-gray-400 focus:outline-hidden focus:border-emerald-500"
                placeholder="Write specific points about water connectivity, local metro distance, kitchen/food settings, etc."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-750 mb-1.5">Offered Amenities</label>
              <div className="grid grid-cols-2 gap-2 text-xs">
                {amenitiesList.map(amenity => {
                  const isChecked = selectedAmenities.includes(amenity);
                  return (
                    <button
                      type="button"
                      key={amenity}
                      onClick={() => toggleAmenity(amenity)}
                      className={`text-left px-3 py-1.8 rounded-lg border transition-colors cursor-pointer ${
                        isChecked
                          ? 'border-emerald-500 bg-emerald-50/50 text-emerald-800 font-bold'
                          : 'border-gray-200 bg-white text-gray-600 hover:border-gray-300'
                      }`}
                    >
                      {isChecked ? '✓' : '+'} {amenity}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* STEP 3: Visual Cover & Media Upload */}
        {step === 3 && (
          <div className="space-y-4 animate-fade-in relative" id="wizard-media-form">
            <h3 className="text-base font-bold text-gray-800 border-b border-gray-100 pb-2">Cover Photo Classified</h3>

            {/* Simulated drag & drop cover container */}
            <div className="mt-1 flex flex-col items-center justify-center border-2 border-dashed border-gray-200 rounded-xl p-5.5 text-center hover:border-emerald-500 transition-colors bg-gray-50/50 relative">
              <UploadCloud className="w-9 h-9 text-gray-400 mb-2" />
              <div className="text-xs text-gray-600 space-y-0.5">
                <span className="font-bold text-emerald-600 hover:underline cursor-pointer block">Click to upload photo</span>
                <span className="text-gray-400 text-[10px] block">PNG, JPG up to 5MB (Self-running browser mock)</span>
              </div>
              <input
                type="file"
                accept="image/*"
                className="absolute inset-0 opacity-0 cursor-pointer"
                onChange={handleFileUploadSimulate}
              />
              {customFileText && (
                <div className="mt-3 text-[11px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-100 px-3 py-1 rounded-full">
                  ✓ File selected: {customFileText}
                </div>
              )}
            </div>

            {/* Premium Preset selectors fallback */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-gray-700">Or Pick a Luxury Cover Preset (Instantly loaded):</label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {PRESET_IMAGES.map((preset) => (
                  <button
                    type="button"
                    key={preset.name}
                    onClick={() => {
                      setSelectedPresetImage(preset.url);
                      setCustomFileText('');
                    }}
                    className={`relative aspect-[4/3] rounded-lg overflow-hidden border cursor-pointer ${
                      selectedPresetImage === preset.url
                        ? 'border-emerald-600 ring-2 ring-emerald-500/25 ring-offset-1'
                        : 'border-transparent'
                    }`}
                  >
                    <img src={preset.url} alt={preset.name} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                    <span className="absolute bottom-0 inset-x-0 bg-black/50 text-white text-[9px] py-0.5 truncate font-bold text-center">
                      {preset.name.split(' ')[0]}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* STEP 4: Advertising Monetization Boost */}
        {step === 4 && (
          <div className="space-y-4 animate-fade-in">
            <h3 className="text-base font-bold text-gray-800 border-b border-gray-100 pb-2">Listing Highlight &amp; Verification plans</h3>

            <div className="space-y-2.5">
              {/* Option A: Free */}
              <button
                type="button"
                onClick={() => setPlan('free')}
                className={`w-full p-4 rounded-xl border text-left flex gap-3 cursor-pointer transition-colors ${
                  plan === 'free'
                    ? 'border-emerald-600 bg-emerald-50/40 text-emerald-950'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="w-5 h-5 rounded-full border border-gray-400 flex items-center justify-center shrink-0 mt-0.5">
                  {plan === 'free' && <div className="w-3 h-3 bg-emerald-600 rounded-full"></div>}
                </div>
                <div>
                  <h4 className="text-xs font-black">Standard Classified (Free)</h4>
                  <p className="text-[10px] text-gray-500 mt-0.5">List classified for 30 days. Shown in standard filter index. Standard customer help desk.</p>
                </div>
              </button>

              {/* Option B: Boost */}
              <button
                type="button"
                onClick={() => setPlan('boost')}
                className={`w-full p-4 rounded-xl border text-left flex gap-3 cursor-pointer transition-colors ${
                  plan === 'boost'
                    ? 'border-emerald-600 bg-emerald-50/40 text-emerald-950'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="w-5 h-5 rounded-full border border-gray-400 flex items-center justify-center shrink-0 mt-0.5">
                  {plan === 'boost' && <div className="w-3 h-3 bg-emerald-600 rounded-full"></div>}
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-center">
                    <h4 className="text-xs font-black text-amber-900 flex items-center gap-1">
                      Featured Top Boost (Popular) <span className="text-[8px] bg-amber-400 text-amber-900 px-1.5 py-0.2 rounded-full font-bold">5x LEADS</span>
                    </h4>
                    <span className="text-xs font-black text-emerald-700">₹299</span>
                  </div>
                  <p className="text-[10px] text-gray-500 mt-0.5">Classified floats on TOP of Mumbai/Bangalore listings. Multi-color verified badge included. Direct Leads delivered to SMS/WhatsApp.</p>
                </div>
              </button>

              {/* Option C: Broker Premium */}
              <button
                type="button"
                onClick={() => setPlan('broker')}
                className={`w-full p-4 rounded-xl border text-left flex gap-3 cursor-pointer transition-colors ${
                  plan === 'broker'
                    ? 'border-emerald-650 bg-emerald-50/40 text-emerald-950'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="w-5 h-5 rounded-full border border-gray-400 flex items-center justify-center shrink-0 mt-0.5">
                  {plan === 'broker' && <div className="w-3 h-3 bg-emerald-600 rounded-full"></div>}
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-center">
                    <h4 className="text-xs font-black text-emerald-800">Broker Unlimited Package</h4>
                    <span className="text-xs font-black text-emerald-700">₹999<span className="text-[10px] opacity-70">/mo</span></span>
                  </div>
                  <p className="text-[10px] text-gray-500 mt-0.5">Perfect for agents or bulk owners. Unlimited listings, priority verified blue badge, direct client-landlord chatbot setup.</p>
                </div>
              </button>
            </div>
          </div>
        )}

        {/* STEP BUTTONS */}
        <div className="mt-8 pt-4.5 border-t border-gray-150 flex items-center justify-between">
          {step > 1 ? (
            <button
              onClick={handleBack}
              className="px-4.5 py-1.8 border border-gray-200 rounded-lg text-xs font-semibold hover:bg-gray-50 flex items-center gap-1 cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" /> Back
            </button>
          ) : (
            <div></div> // Spacer
          )}

          {step < 4 ? (
            <button
              onClick={handleNext}
              className="px-5 py-1.8 bg-emerald-650 hover:bg-emerald-750 text-white rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer ml-auto"
            >
              Continue <ChevronRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={handleSubmit}
              disabled={loading}
              className="px-6 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-black flex items-center gap-1 cursor-pointer shadow-xs ml-auto"
            >
              {loading ? 'Publishing Classified...' : 'Publish Listing classified ✓'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
